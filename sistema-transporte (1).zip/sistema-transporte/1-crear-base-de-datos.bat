@echo off
chcp 65001 >nul
setlocal
title Rutas Unillanos - Crear base de datos
cd /d "%~dp0"

echo ============================================================
echo   Rutas Unillanos - Crear la base de datos en PostgreSQL
echo ============================================================
echo.

set "PSQL="
where psql >nul 2>nul && set "PSQL=psql"
if not defined PSQL (
  for /d %%d in ("C:\Program Files\PostgreSQL\*") do (
    if exist "%%d\bin\psql.exe" set "PSQL=%%d\bin\psql.exe"
  )
)
if not defined PSQL (
  echo No se encontro psql. Instale PostgreSQL o cree la base "transporte_db" desde pgAdmin
  echo ^(clic derecho en Databases ^> Create ^> Database^) y luego ejecute 2-iniciar-sistema.bat
  echo.
  pause
  exit /b 1
)

echo Se usara: %PSQL%
echo Escriba la contrasena del usuario "postgres" cuando la pida.
echo.
"%PSQL%" -U postgres -h localhost -c "CREATE DATABASE transporte_db;"
if errorlevel 1 (
  echo.
  echo Si el mensaje dice que la base de datos ya existe, no hay problema: continue con 2-iniciar-sistema.bat
) else (
  echo.
  echo Base de datos "transporte_db" creada. Ahora ejecute 2-iniciar-sistema.bat
)
echo.
pause
