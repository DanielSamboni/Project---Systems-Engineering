@echo off
chcp 65001 >nul
setlocal
title Rutas Unillanos - Servidor (PostgreSQL)
cd /d "%~dp0"

echo ============================================================
echo   Rutas Unillanos - Iniciar el sistema con PostgreSQL
echo ============================================================
echo.

set "JMAYOR="
for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JV=%%~v"
if defined JV for /f "delims=." %%m in ("%JV%") do set "JMAYOR=%%m"
if not defined JMAYOR set "JMAYOR=0"
if %JMAYOR% LSS 21 (
  echo Se necesita Java 21 o superior. Version detectada:
  java -version
  echo.
  echo Descargue el JDK 21 desde https://adoptium.net e intente de nuevo.
  pause
  exit /b 1
)

for /f "usebackq delims=" %%p in (`powershell -NoProfile -Command "$s = Read-Host 'Contrasena del usuario postgres' -AsSecureString; [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s))"`) do set "DB_PASSWORD=%%p"

echo.
echo Iniciando... la primera vez descarga dependencias (requiere internet y puede tardar unos minutos).
echo Cuando aparezca "Started SistemaTransporteApplication" abra http://localhost:8080
echo Para detener el servidor presione Ctrl+C.
echo.
call "%~dp0mvnw.cmd" spring-boot:run
pause
