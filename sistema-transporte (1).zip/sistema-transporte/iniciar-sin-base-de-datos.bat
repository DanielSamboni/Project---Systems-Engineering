@echo off
chcp 65001 >nul
setlocal
title Rutas Unillanos - Servidor (modo demostracion H2)
cd /d "%~dp0"

echo ============================================================
echo   Rutas Unillanos - Modo demostracion SIN PostgreSQL
echo   Usa una base de datos en memoria: los datos se pierden al cerrar.
echo ============================================================
echo.

set "JMAYOR="
for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JV=%%~v"
if defined JV for /f "delims=." %%m in ("%JV%") do set "JMAYOR=%%m"
if not defined JMAYOR set "JMAYOR=0"
if %JMAYOR% LSS 21 (
  echo Se necesita Java 21 o superior. Descargue el JDK 21 desde https://adoptium.net
  pause
  exit /b 1
)

echo Cuando aparezca "Started SistemaTransporteApplication" abra http://localhost:8080
echo Para detener el servidor presione Ctrl+C.
echo.
call "%~dp0mvnw.cmd" spring-boot:run "-Dspring-boot.run.profiles=h2"
pause
