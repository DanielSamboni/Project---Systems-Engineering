package edu.unillanos.transporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("h2")
class SistemaTransporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
