package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Coordenada;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta.Estimacion;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta.Muestra;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta.ParadaRef;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

class CalculadoraEtaTest {

    // Trazado recto norte-sur de ~2.2 km (0.02 grados de latitud).
    private final List<Coordenada> trazado = List.of(new Coordenada(4.10, -73.60), new Coordenada(4.11, -73.60),
            new Coordenada(4.12, -73.60));
    private final List<ParadaRef> paradas = List.of(
            new ParadaRef(1L, "Inicio", new Coordenada(4.10, -73.60)),
            new ParadaRef(2L, "Medio", new Coordenada(4.11, -73.60)),
            new ParadaRef(3L, "Final", new Coordenada(4.12, -73.60)));

    @Test
    void estimaLlegadaAParadaSeleccionada() {
        Coordenada bus = new Coordenada(4.10, -73.60);

        Estimacion e = CalculadoraEta.estimar(trazado, paradas, bus, 3L, 18).orElseThrow();

        assertThat(e.distanciaMetros()).isCloseTo(2224, within(15.0));
        assertThat(e.minutos()).isEqualTo(8); // 2.22 km a 18 km/h ≈ 7.4 min
        assertThat(e.yaPaso()).isFalse();
    }

    @Test
    void indicaQueElBusYaPasoPorLaParada() {
        Coordenada bus = new Coordenada(4.115, -73.60);

        Estimacion e = CalculadoraEta.estimar(trazado, paradas, bus, 1L, 18).orElseThrow();

        assertThat(e.yaPaso()).isTrue();
    }

    @Test
    void sinParadaSeleccionadaUsaLaPrimeraNoSuperada() {
        Coordenada bus = new Coordenada(4.105, -73.60);

        Estimacion e = CalculadoraEta.estimar(trazado, paradas, bus, null, 18).orElseThrow();

        assertThat(e.paradaId()).isEqualTo(2L);
        assertThat(e.paradaElegidaPorSistema()).isTrue();
    }

    @Test
    void proyectaPosicionesQueNoEstanExactamenteSobreElTrazado() {
        Coordenada busDesviado = new Coordenada(4.11, -73.6005);

        double progreso = Geo.progresoSobreTrazado(trazado, busDesviado);

        assertThat(progreso).isCloseTo(1112, within(15.0));
    }

    @Test
    void simplificarConservaLosGirosYEliminaPuntosRedundantes() {
        List<Coordenada> conRedundantes = List.of(new Coordenada(4.10, -73.60), new Coordenada(4.105, -73.60),
                new Coordenada(4.11, -73.60), new Coordenada(4.11, -73.605), new Coordenada(4.11, -73.61));

        List<Coordenada> simple = Geo.simplificar(conRedundantes, 5);

        assertThat(simple).extracting(Coordenada::getLat, Coordenada::getLng).containsExactly(
                org.assertj.core.groups.Tuple.tuple(4.10, -73.60),
                org.assertj.core.groups.Tuple.tuple(4.11, -73.60),
                org.assertj.core.groups.Tuple.tuple(4.11, -73.61));
    }

    @Test
    void velocidadObservadaDescartaValoresIrreales() {
        Instant t0 = Instant.parse("2026-10-05T12:00:00Z");
        List<Muestra> quieto = List.of(new Muestra(new Coordenada(4.10, -73.60), t0),
                new Muestra(new Coordenada(4.10, -73.60), t0.plusSeconds(10)));
        List<Muestra> enMovimiento = List.of(new Muestra(new Coordenada(4.10, -73.60), t0),
                new Muestra(new Coordenada(4.101, -73.60), t0.plusSeconds(10))); // ~111 m en 10 s = 40 km/h

        assertThat(CalculadoraEta.velocidadKmh(quieto, 18)).isEqualTo(18);
        assertThat(CalculadoraEta.velocidadKmh(enMovimiento, 18)).isCloseTo(40, within(1.0));
    }
}
