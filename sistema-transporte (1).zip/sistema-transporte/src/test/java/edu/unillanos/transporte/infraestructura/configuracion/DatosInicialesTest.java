package edu.unillanos.transporte.infraestructura.configuracion;

import edu.unillanos.transporte.aplicacion.puerto.persistencia.RutaRepository;
import edu.unillanos.transporte.dominio.modelo.Coordenada;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("h2")
class DatosInicialesTest {

    private static final String RUTA = "Grama – Catama";

    @Autowired
    private DatosIniciales datosIniciales;

    @Autowired
    private RutaRepository rutas;

    @Autowired
    private TransactionTemplate tx;

    @Test
    void reemplazaLosTrazadosAproximadosDeVersionesAnteriores() {
        tx.executeWithoutResult(s -> {
            Ruta ruta = rutas.findByNombreIgnoreCase(RUTA).orElseThrow();
            ruta.getTrazado().clear();
            ruta.getTrazado().addAll(List.of(new Coordenada(4.07, -73.58), new Coordenada(4.10, -73.60),
                    new Coordenada(4.15, -73.63)));
        });

        datosIniciales.run();

        int puntos = tx.execute(s -> rutas.findByNombreIgnoreCase(RUTA).orElseThrow().getTrazado().size());
        assertThat(puntos).isGreaterThan(20);
    }

    @Test
    void cargaLasRutasConTrazadosSobreLasVias() {
        tx.executeWithoutResult(s -> rutas.findAll().forEach(r -> {
            assertThat(r.getTrazado()).as(r.getNombre()).hasSizeGreaterThan(20);
            assertThat(r.getParadas()).as(r.getNombre()).hasSizeGreaterThanOrEqualTo(4);
        }));
    }
}
