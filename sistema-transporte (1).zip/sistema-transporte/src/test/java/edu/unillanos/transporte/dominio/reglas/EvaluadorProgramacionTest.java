package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Salida;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class EvaluadorProgramacionTest {

    // 2026-10-05 es lunes; 2026-10-10 sábado; 2026-10-11 domingo.
    private final List<Salida> barrio = List.of(
            Salida.puntual(TipoDia.HABIL, LocalTime.of(5, 20)),
            Salida.puntual(TipoDia.HABIL, LocalTime.of(12, 0)),
            Salida.puntual(TipoDia.HABIL, LocalTime.of(17, 0)));

    private final List<Salida> centro = List.of(
            Salida.frecuencia(TipoDia.HABIL, LocalTime.of(6, 0), LocalTime.of(7, 0), 20));

    @Test
    void frecuenciaGeneraTodasLasSalidasDeLaFranja() {
        assertThat(centro.getFirst().horasDeSalida())
                .containsExactly(LocalTime.of(6, 0), LocalTime.of(6, 20), LocalTime.of(6, 40), LocalTime.of(7, 0));
    }

    @Test
    void proximaSalidaElMismoDia() {
        LocalDateTime ahora = LocalDateTime.of(2026, 10, 5, 9, 0);

        assertThat(EvaluadorProgramacion.proximaSalida(barrio, ahora))
                .contains(LocalDateTime.of(2026, 10, 5, 12, 0));
    }

    @Test
    void proximaSalidaSaltaElFinDeSemanaSinServicio() {
        LocalDateTime sabadoNoche = LocalDateTime.of(2026, 10, 10, 20, 0);

        assertThat(EvaluadorProgramacion.proximaSalida(barrio, sabadoNoche))
                .contains(LocalDateTime.of(2026, 10, 12, 5, 20));
    }

    @Test
    void detectaSalidaEnCursoSegunDuracionDelTrayecto() {
        assertThat(EvaluadorProgramacion.salidaEnCurso(barrio, LocalDateTime.of(2026, 10, 5, 12, 30), 50))
                .contains(LocalDateTime.of(2026, 10, 5, 12, 0));
        assertThat(EvaluadorProgramacion.salidaEnCurso(barrio, LocalDateTime.of(2026, 10, 5, 13, 0), 50))
                .isEmpty();
    }

    @Test
    void validaQueLaHoraCorrespondaAUnaSalidaProgramada() {
        assertThat(EvaluadorProgramacion.esSalidaValida(centro, LocalDateTime.of(2026, 10, 5, 6, 40))).isTrue();
        assertThat(EvaluadorProgramacion.esSalidaValida(centro, LocalDateTime.of(2026, 10, 5, 6, 45))).isFalse();
        assertThat(EvaluadorProgramacion.esSalidaValida(centro, LocalDateTime.of(2026, 10, 11, 6, 40))).isFalse();
    }
}
