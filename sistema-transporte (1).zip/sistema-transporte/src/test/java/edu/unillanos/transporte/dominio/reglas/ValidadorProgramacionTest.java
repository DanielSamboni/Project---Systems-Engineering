package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.Rol;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.dominio.modelo.Salida;
import edu.unillanos.transporte.dominio.modelo.Turno;
import edu.unillanos.transporte.dominio.modelo.Usuario;
import edu.unillanos.transporte.dominio.modelo.Vehiculo;
import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion.Conflicto;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ValidadorProgramacionTest {

    @Test
    void rutaCompletaNoTieneConflictos() {
        List<Conflicto> c = ValidadorProgramacion.validarRuta("Centro", Modalidad.CENTRO, 3, 4,
                List.of(Salida.frecuencia(TipoDia.HABIL, LocalTime.of(6, 0), LocalTime.of(18, 0), 20)));

        assertThat(c).isEmpty();
    }

    @Test
    void senalaLosCamposIncompletos() {
        List<Conflicto> c = ValidadorProgramacion.validarRuta(" ", Modalidad.BARRIO, 1, 0, List.of());

        assertThat(c).extracting(Conflicto::campo).contains("nombre", "paradas", "trazado", "salidas");
    }

    @Test
    void detectaFranjasSolapadasEnElMismoTipoDeDia() {
        List<Conflicto> c = ValidadorProgramacion.validarRuta("Centro", Modalidad.CENTRO, 2, 2, List.of(
                Salida.frecuencia(TipoDia.SABADO, LocalTime.of(5, 20), LocalTime.of(8, 0), 20),
                Salida.frecuencia(TipoDia.SABADO, LocalTime.of(8, 0), LocalTime.of(17, 30), 30),
                Salida.frecuencia(TipoDia.HABIL, LocalTime.of(5, 20), LocalTime.of(8, 0), 20)));

        assertThat(c).singleElement().extracting(Conflicto::campo).isEqualTo("salidas[1]");
    }

    @Test
    void exigeHorariosPuntualesEnRutasDeBarrio() {
        List<Conflicto> c = ValidadorProgramacion.validarRuta("Grama", Modalidad.BARRIO, 2, 2,
                List.of(Salida.frecuencia(TipoDia.HABIL, LocalTime.of(6, 0), LocalTime.of(7, 0), 20)));

        assertThat(c).extracting(Conflicto::mensaje).anyMatch(m -> m.contains("puntuales"));
    }

    @Test
    void detectaHorasPuntualesDuplicadas() {
        List<Conflicto> c = ValidadorProgramacion.validarRuta("Grama", Modalidad.BARRIO, 2, 2, List.of(
                Salida.puntual(TipoDia.HABIL, LocalTime.of(5, 20)),
                Salida.puntual(TipoDia.HABIL, LocalTime.of(5, 20)),
                Salida.puntual(TipoDia.SABADO, LocalTime.of(5, 20))));

        assertThat(c).hasSize(1);
    }

    @Test
    void detectaConductorYVehiculoConTurnosSolapados() {
        Ruta ruta = new Ruta("Centro", Modalidad.CENTRO, null);
        Usuario conductor = conId(new Usuario("c1", "x", "Conductor", Rol.CONDUCTOR), 1L);
        Usuario otroConductor = conId(new Usuario("c2", "x", "Otro", Rol.CONDUCTOR), 2L);
        Vehiculo bus = new Vehiculo("WTK101", null, true);
        bus.setId(10L);
        Vehiculo otroBus = new Vehiculo("WTK102", null, true);
        otroBus.setId(11L);

        Turno existente = new Turno(ruta, conductor, bus, TipoDia.HABIL, LocalTime.of(6, 0), LocalTime.of(12, 0));
        existente.setId(100L);

        Turno mismoConductor = new Turno(ruta, conductor, otroBus, TipoDia.HABIL, LocalTime.of(11, 0), LocalTime.of(14, 0));
        Turno mismoBus = new Turno(ruta, otroConductor, bus, TipoDia.HABIL, LocalTime.of(7, 0), LocalTime.of(9, 0));
        Turno consecutivo = new Turno(ruta, conductor, bus, TipoDia.HABIL, LocalTime.of(12, 0), LocalTime.of(18, 0));
        Turno otroDia = new Turno(ruta, conductor, bus, TipoDia.SABADO, LocalTime.of(6, 0), LocalTime.of(12, 0));

        assertThat(ValidadorProgramacion.validarTurno(mismoConductor, List.of(existente)))
                .extracting(Conflicto::campo).containsExactly("conductor");
        assertThat(ValidadorProgramacion.validarTurno(mismoBus, List.of(existente)))
                .extracting(Conflicto::campo).containsExactly("vehiculo");
        assertThat(ValidadorProgramacion.validarTurno(consecutivo, List.of(existente))).isEmpty();
        assertThat(ValidadorProgramacion.validarTurno(otroDia, List.of(existente))).isEmpty();
    }

    private static Usuario conId(Usuario u, Long id) {
        u.setId(id);
        return u;
    }
}
