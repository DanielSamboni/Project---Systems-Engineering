package edu.unillanos.transporte.infraestructura.academico;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoCarnet;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Réplica simulada de la base de datos del Sistema Académico Institucional.
 * En producción esta información vive en el sistema externo de Registro y Control.
 */
@Entity
@Table(name = "sa_carnets")
@Getter
@Setter
@NoArgsConstructor
public class CarnetInstitucional {

    @Id
    @Column(length = 30)
    private String codigo;

    @Column(nullable = false, unique = true, length = 30)
    private String documento;

    @Column(nullable = false, length = 120)
    private String nombre;

    @Column(nullable = false, length = 30)
    private String vinculo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private EstadoCarnet estado;

    private LocalDate vigenteHasta;

    public CarnetInstitucional(String codigo, String documento, String nombre, String vinculo,
                               EstadoCarnet estado, LocalDate vigenteHasta) {
        this.codigo = codigo;
        this.documento = documento;
        this.nombre = nombre;
        this.vinculo = vinculo;
        this.estado = estado;
        this.vigenteHasta = vigenteHasta;
    }
}
