package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.aplicacion.dto.AdminDtos.ActualizarVehiculoRequest;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.CrearConductorRequest;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.CrearTurnoRequest;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.CrearVehiculoRequest;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.UsuarioDto;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.VehiculoDto;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.TurnoDto;
import edu.unillanos.transporte.aplicacion.puerto.CifradorClaves;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecorridoRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RutaRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.TurnoRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.UsuarioRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.VehiculoRepository;
import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;
import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Enums.Rol;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.dominio.modelo.Turno;
import edu.unillanos.transporte.dominio.modelo.Usuario;
import edu.unillanos.transporte.dominio.modelo.Vehiculo;
import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion;
import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion.Conflicto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** CU-05: asignación de vehículos y conductores a los turnos de cada ruta (RF-13). */
@Service
@Transactional
public class AsignacionService {

    private static final List<EstadoRecorrido> ACTIVOS = List.of(EstadoRecorrido.EN_CURSO, EstadoRecorrido.PAUSADO);

    private final TurnoRepository turnos;
    private final RutaRepository rutas;
    private final UsuarioRepository usuarios;
    private final VehiculoRepository vehiculos;
    private final RecorridoRepository recorridos;
    private final CifradorClaves cifrador;

    public AsignacionService(TurnoRepository turnos, RutaRepository rutas, UsuarioRepository usuarios,
                             VehiculoRepository vehiculos, RecorridoRepository recorridos, CifradorClaves cifrador) {
        this.turnos = turnos;
        this.rutas = rutas;
        this.usuarios = usuarios;
        this.vehiculos = vehiculos;
        this.recorridos = recorridos;
        this.cifrador = cifrador;
    }

    @Transactional(readOnly = true)
    public List<TurnoDto> turnos() {
        return turnos.findAllByOrderByTipoDiaAscHoraInicioAsc().stream().map(TurnoDto::de).toList();
    }

    public TurnoDto crearTurno(CrearTurnoRequest req) {
        Turno turno = construirTurno(req);
        validarSinSolapamientos(turno);
        return TurnoDto.de(turnos.save(turno));
    }

    /** Modifica la asignación de vehículo, conductor, ruta u horario de un turno existente. */
    public TurnoDto actualizarTurno(Long id, CrearTurnoRequest req) {
        Turno existente = turnos.findById(id).orElseThrow(() -> new NoEncontradoException("Turno", id));
        Turno propuesto = construirTurno(req);
        propuesto.setId(id);
        validarSinSolapamientos(propuesto);
        existente.setRuta(propuesto.getRuta());
        existente.setConductor(propuesto.getConductor());
        existente.setVehiculo(propuesto.getVehiculo());
        existente.setTipoDia(propuesto.getTipoDia());
        existente.setHoraInicio(propuesto.getHoraInicio());
        existente.setHoraFin(propuesto.getHoraFin());
        return TurnoDto.de(existente);
    }

    private Turno construirTurno(CrearTurnoRequest req) {
        Ruta ruta = rutas.findById(req.rutaId()).orElseThrow(() -> new NoEncontradoException("Ruta", req.rutaId()));
        Usuario conductor = usuarios.findById(req.conductorId())
                .filter(u -> u.getRol() == Rol.CONDUCTOR && u.isActivo())
                .orElseThrow(() -> new NoEncontradoException("Conductor activo", req.conductorId()));
        Vehiculo vehiculo = vehiculos.findById(req.vehiculoId())
                .filter(Vehiculo::isActivo)
                .orElseThrow(() -> new NoEncontradoException("Vehículo activo", req.vehiculoId()));
        return new Turno(ruta, conductor, vehiculo, req.tipoDia(), req.horaInicio(), req.horaFin());
    }

    private void validarSinSolapamientos(Turno turno) {
        List<Conflicto> conflictos = ValidadorProgramacion.validarTurno(turno, turnos.findAll());
        if (!conflictos.isEmpty()) {
            throw new ReglaNegocioException("No se puede asignar el turno", conflictos);
        }
    }

    public VehiculoDto actualizarVehiculo(Long id, ActualizarVehiculoRequest req) {
        Vehiculo v = vehiculos.findById(id).orElseThrow(() -> new NoEncontradoException("Vehículo", id));
        if (!req.activo() && v.isActivo() && recorridos.existsByVehiculoIdAndEstadoIn(id, ACTIVOS)) {
            throw new ReglaNegocioException("El vehículo " + v.getPlaca() + " está en un recorrido en curso; finalícelo antes de retirarlo.");
        }
        v.setDescripcion(req.descripcion());
        v.setTieneGps(req.tieneGps());
        v.setTieneLector(req.tieneLector());
        v.setActivo(req.activo());
        return VehiculoDto.de(v);
    }

    public UsuarioDto crearConductor(CrearConductorRequest req) {
        String username = req.username().trim().toLowerCase();
        if (usuarios.findByUsername(username).isPresent()) {
            throw new ReglaNegocioException("Ya existe un usuario «" + username + "».");
        }
        Usuario u = new Usuario(username, cifrador.cifrar(req.clave()), req.nombre().trim(), Rol.CONDUCTOR);
        u.setDocumento(req.documento());
        return UsuarioDto.de(usuarios.save(u));
    }

    public UsuarioDto cambiarConductorActivo(Long id, boolean activo) {
        Usuario u = usuarios.findById(id).filter(x -> x.getRol() == Rol.CONDUCTOR)
                .orElseThrow(() -> new NoEncontradoException("Conductor", id));
        if (!activo && recorridos.findFirstByConductorIdAndEstadoIn(id, ACTIVOS).isPresent()) {
            throw new ReglaNegocioException("El conductor tiene un recorrido en curso; finalícelo antes de desactivarlo.");
        }
        u.setActivo(activo);
        return UsuarioDto.de(u);
    }

    public void eliminarTurno(Long id) {
        if (!turnos.existsById(id)) {
            throw new NoEncontradoException("Turno", id);
        }
        if (recorridos.existsByTurnoId(id)) {
            throw new ReglaNegocioException("El turno ya tiene recorridos registrados y no puede eliminarse.");
        }
        turnos.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<VehiculoDto> vehiculos() {
        return vehiculos.findAllByOrderByPlaca().stream().map(VehiculoDto::de).toList();
    }

    public VehiculoDto crearVehiculo(CrearVehiculoRequest req) {
        String placa = req.placa().replace("-", "").toUpperCase();
        if (vehiculos.findAll().stream().anyMatch(v -> v.getPlaca().equals(placa))) {
            throw new ReglaNegocioException("Ya existe un vehículo con la placa " + placa + ".");
        }
        Vehiculo v = new Vehiculo(placa, req.descripcion(), req.tieneGps());
        v.setTieneLector(req.tieneLector());
        return VehiculoDto.de(vehiculos.save(v));
    }

    @Transactional(readOnly = true)
    public List<UsuarioDto> conductores() {
        return usuarios.findByRolOrderByNombreCompleto(Rol.CONDUCTOR).stream().map(UsuarioDto::de).toList();
    }
}
