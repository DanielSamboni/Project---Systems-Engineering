package edu.unillanos.transporte.aplicacion.dto;

import edu.unillanos.transporte.dominio.modelo.Abordaje;
import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Enums.MetodoLectura;
import edu.unillanos.transporte.dominio.modelo.Enums.ModoValidacion;
import edu.unillanos.transporte.dominio.modelo.Enums.ResultadoAcceso;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoNovedad;
import edu.unillanos.transporte.dominio.modelo.Recorrido;
import edu.unillanos.transporte.dominio.modelo.Turno;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.CoordenadaDto;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.ParadaDto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public final class ConductorDtos {

    private ConductorDtos() {
    }

    public record TurnoDto(Long id, Long rutaId, String ruta, Long conductorId, String conductor, Long vehiculoId,
                           String placa, boolean vehiculoTieneGps, TipoDia tipoDia, LocalTime horaInicio,
                           LocalTime horaFin) {
        public static TurnoDto de(Turno t) {
            return new TurnoDto(t.getId(), t.getRuta().getId(), t.getRuta().getNombre(), t.getConductor().getId(),
                    t.getConductor().getNombreCompleto(), t.getVehiculo().getId(), t.getVehiculo().getPlaca(),
                    t.getVehiculo().isTieneGps(), t.getTipoDia(), t.getHoraInicio(), t.getHoraFin());
        }
    }

    public record IniciarRecorridoRequest(@NotNull Long turnoId, boolean confirmarSegundoVehiculo) {
    }

    public record RecorridoDto(Long id, Long rutaId, String ruta, Long vehiculoId, String placa,
                               boolean vehiculoTieneGps, EstadoRecorrido estado, Instant inicio, Instant fin,
                               CoordenadaDto ultimaPosicion, Instant ultimaPosicionEn, List<CoordenadaDto> trazado,
                               List<ParadaDto> paradas) {
        public static RecorridoDto de(Recorrido r) {
            return new RecorridoDto(r.getId(), r.getRuta().getId(), r.getRuta().getNombre(), r.getVehiculo().getId(),
                    r.getVehiculo().getPlaca(), r.getVehiculo().isTieneGps(), r.getEstado(), r.getInicio(), r.getFin(),
                    CoordenadaDto.de(r.getUltimaPosicion()), r.getUltimaPosicionEn(),
                    r.getRuta().getTrazado().stream().map(CoordenadaDto::de).toList(),
                    r.getRuta().getParadas().stream().map(ParadaDto::de).toList());
        }
    }

    public record PosicionRequest(@NotNull Double lat, @NotNull Double lng, Instant capturadaEn) {
    }

    public record ResultadoPosiciones(int aceptadas, int descartadas) {
    }

    public record NovedadRequest(@NotNull TipoNovedad tipo, @Size(max = 200) String detalle) {
    }

    public record ResultadoNovedad(Long id, int pasajerosNotificados) {
    }

    // CU-03

    public record ValidarAccesoRequest(@NotBlank @Size(max = 30) String identificador, @NotNull MetodoLectura metodo) {
    }

    public record ResultadoValidacion(ResultadoAcceso resultado, String indicador, String nombre, String motivo,
                                      ModoValidacion modo, LocalDateTime fechaHora) {
    }

    public record CarnetVigenteDto(String codigo, String documento, String nombre) {
    }

    public record AbordajeOfflineRequest(@NotBlank @Size(max = 30) String identificador, @NotNull MetodoLectura metodo,
                                         @NotNull LocalDateTime fechaHora, @NotNull ResultadoAcceso resultado,
                                         @Size(max = 120) String motivo, @Size(max = 120) String nombre) {
    }

    public record AbordajeDto(Long id, String ruta, String placa, String identificador, String nombre,
                              LocalDateTime fechaHora, ResultadoAcceso resultado, String motivo, MetodoLectura metodo,
                              ModoValidacion modo) {
        public static AbordajeDto de(Abordaje a) {
            return new AbordajeDto(a.getId(), a.getRuta().getNombre(), a.getVehiculo().getPlaca(),
                    a.getIdentificadorLeido(), a.getNombrePortador(), a.getFechaHora(), a.getResultado(),
                    a.getMotivo(), a.getMetodo(), a.getModo());
        }
    }
}
