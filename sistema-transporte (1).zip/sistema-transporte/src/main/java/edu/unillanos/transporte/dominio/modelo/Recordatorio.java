package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "recordatorios")
@Getter
@Setter
@NoArgsConstructor
public class Recordatorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Usuario pasajero;

    @ManyToOne(optional = false)
    private Ruta ruta;

    @Column(nullable = false)
    private LocalDateTime salidaProgramada;

    @Column(nullable = false)
    private int minutosAntes = 15;

    private boolean notificado = false;

    private boolean activo = true;
}
