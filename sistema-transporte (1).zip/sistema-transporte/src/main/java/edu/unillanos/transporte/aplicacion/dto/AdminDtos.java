package edu.unillanos.transporte.aplicacion.dto;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.Rol;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Usuario;
import edu.unillanos.transporte.dominio.modelo.Vehiculo;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.NovedadDto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public final class AdminDtos {

    private AdminDtos() {
    }

    public record UsuarioDto(Long id, String username, String nombre, Rol rol, String documento, boolean activo) {
        public static UsuarioDto de(Usuario u) {
            return new UsuarioDto(u.getId(), u.getUsername(), u.getNombreCompleto(), u.getRol(), u.getDocumento(), u.isActivo());
        }
    }

    public record CrearConductorRequest(
            @NotBlank @Pattern(regexp = "[a-zA-Z0-9._-]{4,60}", message = "Entre 4 y 60 caracteres: letras, números, punto, guion")
            String username,
            @NotBlank @Size(max = 120) String nombre,
            @NotBlank @Pattern(regexp = "\\d{5,15}", message = "Solo números (5 a 15 dígitos)") String documento,
            @NotBlank @Size(min = 8, max = 72, message = "La contraseña inicial debe tener al menos 8 caracteres") String clave) {
    }

    public record VehiculoDto(Long id, String placa, String descripcion, boolean tieneGps, boolean tieneLector,
                              boolean activo) {
        public static VehiculoDto de(Vehiculo v) {
            return new VehiculoDto(v.getId(), v.getPlaca(), v.getDescripcion(), v.isTieneGps(), v.isTieneLector(), v.isActivo());
        }
    }

    public record CrearVehiculoRequest(@NotBlank @Pattern(regexp = "[A-Za-z]{3}-?\\d{3}", message = "Placa con formato ABC123")
                                       String placa, @Size(max = 60) String descripcion, boolean tieneGps, boolean tieneLector) {
    }

    public record ActualizarVehiculoRequest(@Size(max = 60) String descripcion, boolean tieneGps, boolean tieneLector,
                                            boolean activo) {
    }

    public record CrearTurnoRequest(@NotNull Long rutaId, @NotNull Long conductorId, @NotNull Long vehiculoId,
                                    @NotNull TipoDia tipoDia, @NotNull LocalTime horaInicio, @NotNull LocalTime horaFin) {
    }

    public record EstadoSistemaAcademico(boolean disponible) {
    }

    // Supervisión del servicio en vivo

    public record BusFlota(Long recorridoId, Long rutaId, String ruta, Modalidad modalidad, String placa, String conductor,
                           EstadoRecorrido estado, boolean tieneGps, Double lat, Double lng, Instant ultimaPosicionEn,
                           Long antiguedadSeg, boolean desactualizada, Instant inicio, long abordajes) {
    }

    public record ResumenFlota(int busesEnRuta, int sinSenal, long abordajesHoy, long novedadesHoy, long rutasEnServicio) {
    }

    public record EstadoFlota(ResumenFlota resumen, List<BusFlota> buses, List<NovedadFlota> novedades, Instant consultadoEn) {
    }

    public record NovedadFlota(NovedadDto novedad, String ruta, int pasajerosNotificados) {
    }

    // RF-14 e indicadores de éxito (Tabla 6 del documento)

    public record FilaRuta(Long rutaId, String ruta, Modalidad modalidad, long aprobados, long denegados) {
    }

    public record FilaConteo(String etiqueta, long aprobados, long denegados) {
    }

    public record Indicadores(double adopcionApp, long portadoresDistintos, long portadoresConApp,
                              long novedadesDifundidas, long pasajerosNotificados, long recorridosRealizados) {
    }

    public record ReporteUso(LocalDate desde, LocalDate hasta, long aprobados, long denegados,
                             double porcentajeLecturaAutomatica, long registradosEnContingencia,
                             List<FilaRuta> porRuta, List<FilaConteo> porFranja, List<FilaConteo> porDia,
                             List<FilaConteo> porDiaSemana, Indicadores indicadores) {
    }
}
