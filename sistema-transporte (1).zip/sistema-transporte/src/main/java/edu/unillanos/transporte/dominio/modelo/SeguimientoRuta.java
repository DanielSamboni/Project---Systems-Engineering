package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Pasajero que sigue una ruta y por tanto recibe sus novedades. */
@Entity
@Table(name = "seguimientos_ruta", uniqueConstraints = @UniqueConstraint(columnNames = {"pasajero_id", "ruta_id"}))
@Getter
@Setter
@NoArgsConstructor
public class SeguimientoRuta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Usuario pasajero;

    @ManyToOne(optional = false)
    private Ruta ruta;

    public SeguimientoRuta(Usuario pasajero, Ruta ruta) {
        this.pasajero = pasajero;
        this.ruta = ruta;
    }
}
