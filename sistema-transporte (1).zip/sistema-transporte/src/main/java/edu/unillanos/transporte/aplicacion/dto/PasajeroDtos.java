package edu.unillanos.transporte.aplicacion.dto;

import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoNovedad;
import edu.unillanos.transporte.dominio.modelo.Notificacion;
import edu.unillanos.transporte.dominio.modelo.Recordatorio;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public final class PasajeroDtos {

    private PasajeroDtos() {
    }

    // CU-01

    public enum EstadoServicio { EN_SERVICIO, SIN_SENAL, SIN_SERVICIO }

    public record BusEnVivo(Long recorridoId, String placa, double lat, double lng, Instant actualizadaEn,
                            long antiguedadSeg, boolean desactualizada, String estadoRecorrido) {
    }

    public record EstimacionDto(Long paradaId, String parada, int minutos, double distanciaMetros, boolean yaPaso,
                                boolean paradaElegidaPorSistema, String placa) {
    }

    public record NovedadDto(Long id, TipoNovedad tipo, String detalle, Instant reportadaEn, String placa) {
    }

    public record EstadoEnVivo(Long rutaId, String ruta, EstadoServicio estado, String mensaje, List<BusEnVivo> buses,
                               LocalDateTime salidaReferencia, LocalDateTime proximaSalida,
                               EstimacionDto estimacion, List<NovedadDto> novedades, Instant consultadoEn) {
    }

    // CU-02

    public record Bloque(String nombre, String descripcion, List<LocalTime> horas) {
    }

    public record HorariosRuta(Long rutaId, String ruta, Modalidad modalidad, LocalDateTime ultimaPublicacion,
                               String avisoActualizacion, List<Bloque> habiles, List<Bloque> sabados,
                               LocalDate hoy, List<LocalTime> salidasHoy, LocalDateTime proximaSalida,
                               boolean siguiendo) {
    }

    public record CrearRecordatorioRequest(@NotNull Long rutaId, @NotNull LocalDate fecha, @NotNull LocalTime hora,
                                           @Min(1) @Max(120) Integer minutosAntes) {
    }

    public record RecordatorioDto(Long id, Long rutaId, String ruta, LocalDateTime salidaProgramada, int minutosAntes,
                                  boolean notificado) {
        public static RecordatorioDto de(Recordatorio r) {
            return new RecordatorioDto(r.getId(), r.getRuta().getId(), r.getRuta().getNombre(),
                    r.getSalidaProgramada(), r.getMinutosAntes(), r.isNotificado());
        }
    }

    // Notificaciones push (simuladas)

    public record NotificacionDto(Long id, String categoria, String titulo, String mensaje, Instant creadaEn,
                                  boolean leida) {
        public static NotificacionDto de(Notificacion n) {
            return new NotificacionDto(n.getId(), n.getCategoria(), n.getTitulo(), n.getMensaje(), n.getCreadaEn(), n.isLeida());
        }
    }

    public record Bandeja(long noLeidas, List<NotificacionDto> notificaciones) {
    }
}
