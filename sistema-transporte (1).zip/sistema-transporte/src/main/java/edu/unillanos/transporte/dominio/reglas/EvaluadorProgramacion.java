package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Salida;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

/** Responde preguntas sobre la programación: próxima salida y salida en curso. */
public final class EvaluadorProgramacion {

    private static final int DIAS_BUSQUEDA = 8;

    private EvaluadorProgramacion() {
    }

    public static List<LocalTime> horasDelDia(List<Salida> salidas, TipoDia dia) {
        return salidas.stream()
                .filter(s -> s.getTipoDia() == dia)
                .flatMap(s -> s.horasDeSalida().stream())
                .distinct()
                .sorted()
                .toList();
    }

    public static List<LocalTime> horasDeLaFecha(List<Salida> salidas, LocalDate fecha) {
        return TipoDia.de(fecha).map(d -> horasDelDia(salidas, d)).orElse(List.of());
    }

    public static Optional<LocalDateTime> proximaSalida(List<Salida> salidas, LocalDateTime ahora) {
        for (int i = 0; i < DIAS_BUSQUEDA; i++) {
            LocalDate fecha = ahora.toLocalDate().plusDays(i);
            for (LocalTime hora : horasDeLaFecha(salidas, fecha)) {
                LocalDateTime candidata = fecha.atTime(hora);
                if (candidata.isAfter(ahora)) {
                    return Optional.of(candidata);
                }
            }
        }
        return Optional.empty();
    }

    /** Última salida que ya partió y cuyo trayecto, según la duración estimada, aún no termina. */
    public static Optional<LocalDateTime> salidaEnCurso(List<Salida> salidas, LocalDateTime ahora, int duracionMin) {
        LocalDateTime limite = ahora.minusMinutes(duracionMin);
        Optional<LocalDateTime> resultado = Optional.empty();
        for (LocalDate fecha : List.of(ahora.toLocalDate().minusDays(1), ahora.toLocalDate())) {
            for (LocalTime hora : horasDeLaFecha(salidas, fecha)) {
                LocalDateTime salida = fecha.atTime(hora);
                if (!salida.isAfter(ahora) && salida.isAfter(limite)) {
                    resultado = Optional.of(salida);
                }
            }
        }
        return resultado;
    }

    public static boolean esSalidaValida(List<Salida> salidas, LocalDateTime fechaHora) {
        return horasDeLaFecha(salidas, fechaHora.toLocalDate()).contains(fechaHora.toLocalTime());
    }
}
