package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Recorrido;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.NovedadRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.PosicionGpsRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecorridoRepository;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta.Estimacion;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta.Muestra;
import edu.unillanos.transporte.dominio.reglas.CalculadoraEta.ParadaRef;
import edu.unillanos.transporte.dominio.reglas.EvaluadorProgramacion;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.BusEnVivo;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.EstadoEnVivo;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.EstadoServicio;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.EstimacionDto;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.NovedadDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/** CU-01: posición en vivo de los buses de una ruta y tiempo estimado de llegada (RF-02, RF-04). */
@Service
@Transactional(readOnly = true)
public class UbicacionService {

    private static final List<EstadoRecorrido> ACTIVOS = List.of(EstadoRecorrido.EN_CURSO, EstadoRecorrido.PAUSADO);
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("EEEE dd/MM 'a las' HH:mm",
            java.util.Locale.forLanguageTag("es-CO"));
    private static final Duration VENTANA_NOVEDADES = Duration.ofHours(2);

    private final RutaService rutaService;
    private final RecorridoRepository recorridos;
    private final PosicionGpsRepository posiciones;
    private final NovedadRepository novedades;
    private final Clock reloj;
    private final double velocidadPorDefecto;
    private final long antiguedadMaximaSeg;

    public UbicacionService(RutaService rutaService, RecorridoRepository recorridos, PosicionGpsRepository posiciones,
                            NovedadRepository novedades, Clock reloj,
                            @Value("${app.velocidad-promedio-kmh}") double velocidadPorDefecto,
                            @Value("${app.antiguedad-maxima-posicion-seg}") long antiguedadMaximaSeg) {
        this.rutaService = rutaService;
        this.recorridos = recorridos;
        this.posiciones = posiciones;
        this.novedades = novedades;
        this.reloj = reloj;
        this.velocidadPorDefecto = velocidadPorDefecto;
        this.antiguedadMaximaSeg = antiguedadMaximaSeg;
    }

    public EstadoEnVivo estadoEnVivo(Long rutaId, Long paradaId) {
        Ruta ruta = rutaService.buscarPublicada(rutaId);
        Instant ahoraInstante = Instant.now(reloj);
        LocalDateTime ahora = LocalDateTime.now(reloj);

        List<Recorrido> activos = recorridos.findByRutaIdAndEstadoIn(rutaId, ACTIVOS);
        List<Recorrido> conPosicion = activos.stream()
                .filter(r -> r.getUltimaPosicion() != null)
                .sorted(Comparator.comparing(Recorrido::getUltimaPosicionEn).reversed())
                .toList();
        List<BusEnVivo> buses = conPosicion.stream().map(r -> aBus(r, ahoraInstante)).toList();

        LocalDateTime proxima = EvaluadorProgramacion.proximaSalida(ruta.getSalidas(), ahora).orElse(null);
        Optional<LocalDateTime> enCurso = EvaluadorProgramacion.salidaEnCurso(ruta.getSalidas(), ahora, ruta.getDuracionEstimadaMin());
        List<NovedadDto> recientes = novedades
                .findByRecorridoRutaIdAndReportadaEnAfterOrderByReportadaEnDesc(rutaId, ahoraInstante.minus(VENTANA_NOVEDADES))
                .stream()
                .map(n -> new NovedadDto(n.getId(), n.getTipo(), n.getDetalle(), n.getReportadaEn(), n.getRecorrido().getVehiculo().getPlaca()))
                .toList();

        EstadoServicio estado;
        String mensaje;
        LocalDateTime referencia = enCurso.orElse(null);
        EstimacionDto estimacion = null;

        if (!buses.isEmpty()) {
            estado = EstadoServicio.EN_SERVICIO;
            boolean todasDesactualizadas = buses.stream().allMatch(BusEnVivo::desactualizada);
            mensaje = todasDesactualizadas
                    ? "Se muestra la última posición conocida; el dato no está actualizado."
                    : buses.size() + " bus(es) transmitiendo su ubicación.";
            estimacion = estimar(ruta, conPosicion, paradaId);
        } else if (!activos.isEmpty() || enCurso.isPresent()) {
            // 5b: el bus circula pero no reporta posición (GPS averiado o sin instalar). Nunca se declara "sin servicio".
            estado = EstadoServicio.SIN_SENAL;
            if (referencia != null) {
                mensaje = "El vehículo está en ruta sin señal de ubicación. Salida programada a las " + HORA.format(referencia) + ".";
            } else {
                referencia = LocalDateTime.ofInstant(activos.getFirst().getInicio(), reloj.getZone());
                mensaje = "El vehículo está en ruta sin señal de ubicación. Recorrido iniciado a las " + HORA.format(referencia) + ".";
            }
        } else {
            // 5a: no hay salida programada en este momento.
            estado = EstadoServicio.SIN_SERVICIO;
            mensaje = proxima == null
                    ? "No hay servicio activo y no hay salidas programadas próximamente."
                    : "No hay servicio activo en este momento. Próxima salida: " + FECHA_HORA.format(proxima) + ".";
        }
        return new EstadoEnVivo(ruta.getId(), ruta.getNombre(), estado, mensaje, buses, referencia, proxima,
                estimacion, recientes, ahoraInstante);
    }

    private BusEnVivo aBus(Recorrido r, Instant ahora) {
        long antiguedad = Math.max(0, Duration.between(r.getUltimaPosicionEn(), ahora).toSeconds());
        boolean desactualizada = antiguedad > antiguedadMaximaSeg || r.getEstado() == EstadoRecorrido.PAUSADO;
        return new BusEnVivo(r.getId(), r.getVehiculo().getPlaca(), r.getUltimaPosicion().getLat(),
                r.getUltimaPosicion().getLng(), r.getUltimaPosicionEn(), antiguedad, desactualizada, r.getEstado().name());
    }

    private EstimacionDto estimar(Ruta ruta, List<Recorrido> conPosicion, Long paradaId) {
        List<ParadaRef> paradas = ruta.getParadas().stream()
                .map(p -> new ParadaRef(p.getId(), p.getNombre(), p.getUbicacion())).toList();
        List<Recorrido> candidatos = paradaId == null ? conPosicion.subList(0, 1) : conPosicion;

        EstimacionDto mejor = null;
        for (Recorrido r : candidatos) {
            double velocidad = CalculadoraEta.velocidadKmh(posiciones.findTop5ByRecorridoIdOrderByCapturadaEnDesc(r.getId())
                    .stream().map(p -> new Muestra(p.getCoordenada(), p.getCapturadaEn())).toList(), velocidadPorDefecto);
            Optional<Estimacion> e = CalculadoraEta.estimar(ruta.getTrazado(), paradas, r.getUltimaPosicion(), paradaId, velocidad);
            if (e.isEmpty()) {
                continue;
            }
            EstimacionDto dto = new EstimacionDto(e.get().paradaId(), e.get().paradaNombre(), e.get().minutos(),
                    Math.round(e.get().distanciaMetros()), e.get().yaPaso(), e.get().paradaElegidaPorSistema(),
                    r.getVehiculo().getPlaca());
            if (mejor == null || (mejor.yaPaso() && !dto.yaPaso()) || (!dto.yaPaso() && dto.minutos() < mejor.minutos())) {
                mejor = dto;
            }
        }
        return mejor;
    }
}
