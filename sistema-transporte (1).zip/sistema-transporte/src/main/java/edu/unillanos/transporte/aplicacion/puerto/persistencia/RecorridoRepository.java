package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Recorrido;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface RecorridoRepository extends JpaRepository<Recorrido, Long> {

    List<Recorrido> findByRutaIdAndEstadoIn(Long rutaId, Collection<EstadoRecorrido> estados);

    Optional<Recorrido> findFirstByConductorIdAndEstadoIn(Long conductorId, Collection<EstadoRecorrido> estados);

    boolean existsByVehiculoIdAndEstadoIn(Long vehiculoId, Collection<EstadoRecorrido> estados);

    boolean existsByTurnoId(Long turnoId);

    List<Recorrido> findByEstadoIn(Collection<EstadoRecorrido> estados);

    long countByInicioBetween(Instant desde, Instant hasta);
}
