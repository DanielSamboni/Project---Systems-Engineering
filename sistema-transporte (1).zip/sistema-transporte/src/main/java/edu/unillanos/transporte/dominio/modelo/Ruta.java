package edu.unillanos.transporte.dominio.modelo;

import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "rutas")
@Getter
@Setter
@NoArgsConstructor
public class Ruta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 80)
    private String nombre;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Modalidad modalidad;

    @Column(length = 255)
    private String descripcion;

    @Column(nullable = false)
    private int duracionEstimadaMin = 60;

    private boolean activa = true;

    private boolean publicada = false;

    private LocalDateTime ultimaPublicacion;

    private LocalDateTime vigenteDesde;

    @ElementCollection
    @CollectionTable(name = "ruta_trazado", joinColumns = @JoinColumn(name = "ruta_id"))
    @OrderColumn(name = "orden")
    private List<Coordenada> trazado = new ArrayList<>();

    @OneToMany(mappedBy = "ruta", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("orden ASC")
    private List<Parada> paradas = new ArrayList<>();

    @OneToMany(mappedBy = "ruta", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("tipoDia ASC, horaInicio ASC")
    private List<Salida> salidas = new ArrayList<>();

    public Ruta(String nombre, Modalidad modalidad, String descripcion) {
        this.nombre = nombre;
        this.modalidad = modalidad;
        this.descripcion = descripcion;
    }

    public void reemplazarParadas(List<Parada> nuevas) {
        paradas.clear();
        nuevas.forEach(p -> {
            p.setRuta(this);
            paradas.add(p);
        });
    }

    public void reemplazarSalidas(List<Salida> nuevas) {
        salidas.clear();
        nuevas.forEach(s -> {
            s.setRuta(this);
            salidas.add(s);
        });
    }
}
