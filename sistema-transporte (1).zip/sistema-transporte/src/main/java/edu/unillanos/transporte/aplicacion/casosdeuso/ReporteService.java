package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.aplicacion.dto.AdminDtos.FilaConteo;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.FilaRuta;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.Indicadores;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.ReporteUso;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.AbordajeRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.NovedadRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecorridoRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.UsuarioRepository;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;
import edu.unillanos.transporte.dominio.modelo.Abordaje;
import edu.unillanos.transporte.dominio.modelo.Enums.MetodoLectura;
import edu.unillanos.transporte.dominio.modelo.Enums.ModoValidacion;
import edu.unillanos.transporte.dominio.modelo.Enums.ResultadoAcceso;
import edu.unillanos.transporte.dominio.modelo.Enums.Rol;
import edu.unillanos.transporte.dominio.modelo.Novedad;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** RF-14: reportes de uso por ruta, franja horaria y día que sustentan la programación. */
@Service
@Transactional(readOnly = true)
public class ReporteService {

    private static final Locale ES = Locale.forLanguageTag("es-CO");

    private final AbordajeRepository abordajes;
    private final NovedadRepository novedades;
    private final RecorridoRepository recorridos;
    private final UsuarioRepository usuarios;
    private final Clock reloj;

    public ReporteService(AbordajeRepository abordajes, NovedadRepository novedades, RecorridoRepository recorridos,
                          UsuarioRepository usuarios, Clock reloj) {
        this.abordajes = abordajes;
        this.novedades = novedades;
        this.recorridos = recorridos;
        this.usuarios = usuarios;
        this.reloj = reloj;
    }

    /**
     * Indicadores de la Tabla 6 que el sistema puede medir por sí mismo. La reducción del tiempo de espera y de las
     * salidas perdidas requieren encuestas antes y después de la implantación, por eso no se calculan aquí.
     */
    private Indicadores indicadores(List<Abordaje> lista, LocalDate desde, LocalDate hasta) {
        Set<String> identificadoresConApp = usuarios.findByRolOrderByNombreCompleto(Rol.PASAJERO).stream()
                .flatMap(u -> Stream.of(u.getCodigoCarnet(), u.getDocumento()))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        Set<String> portadores = lista.stream()
                .filter(a -> a.getResultado() == ResultadoAcceso.APROBADO)
                .map(Abordaje::getIdentificadorLeido)
                .collect(Collectors.toSet());
        long conApp = portadores.stream().filter(identificadoresConApp::contains).count();
        double adopcion = portadores.isEmpty() ? 0 : Math.round(conApp * 1000.0 / portadores.size()) / 10.0;

        Instant inicio = desde.atStartOfDay(reloj.getZone()).toInstant();
        Instant fin = hasta.plusDays(1).atStartOfDay(reloj.getZone()).toInstant();
        List<Novedad> delPeriodo = novedades.findByReportadaEnBetween(inicio, fin);
        long notificados = delPeriodo.stream().mapToLong(Novedad::getPasajerosNotificados).sum();
        return new Indicadores(adopcion, portadores.size(), conApp, delPeriodo.size(), notificados,
                recorridos.countByInicioBetween(inicio, fin));
    }

    public ReporteUso reporteUso(LocalDate desde, LocalDate hasta) {
        if (hasta.isBefore(desde)) {
            throw new ReglaNegocioException("La fecha final debe ser posterior a la inicial.");
        }
        List<Abordaje> lista = abordajes.findByFechaHoraBetween(desde.atStartOfDay(), hasta.plusDays(1).atStartOfDay());
        long aprobados = lista.stream().filter(a -> a.getResultado() == ResultadoAcceso.APROBADO).count();
        long automaticos = lista.stream().filter(a -> a.getMetodo() != MetodoLectura.MANUAL).count();
        double porcentajeAutomatico = lista.isEmpty() ? 0 : Math.round(automaticos * 1000.0 / lista.size()) / 10.0;
        long contingencia = lista.stream().filter(a -> a.getModo() == ModoValidacion.CONTINGENCIA).count();

        List<FilaRuta> porRuta = lista.stream()
                .collect(Collectors.groupingBy(a -> a.getRuta().getId()))
                .values().stream()
                .map(grupo -> new FilaRuta(grupo.getFirst().getRuta().getId(), grupo.getFirst().getRuta().getNombre(),
                        grupo.getFirst().getRuta().getModalidad(), contar(grupo, ResultadoAcceso.APROBADO),
                        contar(grupo, ResultadoAcceso.DENEGADO)))
                .sorted(Comparator.comparingLong(FilaRuta::aprobados).reversed())
                .toList();

        List<FilaConteo> porFranja = agrupar(lista, a -> String.format("%02d:00", a.getFechaHora().getHour()));
        List<FilaConteo> porDia = agrupar(lista, a -> a.getFechaHora().toLocalDate().toString());
        List<FilaConteo> porDiaSemana = lista.stream()
                .collect(Collectors.groupingBy(a -> a.getFechaHora().getDayOfWeek(), TreeMap::new, Collectors.toList()))
                .entrySet().stream()
                .map(e -> new FilaConteo(nombreDia(e.getKey()), contar(e.getValue(), ResultadoAcceso.APROBADO),
                        contar(e.getValue(), ResultadoAcceso.DENEGADO)))
                .toList();

        return new ReporteUso(desde, hasta, aprobados, lista.size() - aprobados, porcentajeAutomatico, contingencia,
                porRuta, porFranja, porDia, porDiaSemana, indicadores(lista, desde, hasta));
    }

    private static List<FilaConteo> agrupar(List<Abordaje> lista, Function<Abordaje, String> clave) {
        Map<String, List<Abordaje>> grupos = lista.stream()
                .collect(Collectors.groupingBy(clave, TreeMap::new, Collectors.toList()));
        return grupos.entrySet().stream()
                .map(e -> new FilaConteo(e.getKey(), contar(e.getValue(), ResultadoAcceso.APROBADO),
                        contar(e.getValue(), ResultadoAcceso.DENEGADO)))
                .toList();
    }

    private static long contar(List<Abordaje> grupo, ResultadoAcceso resultado) {
        return grupo.stream().filter(a -> a.getResultado() == resultado).count();
    }

    private static String nombreDia(DayOfWeek dia) {
        String nombre = dia.getDisplayName(TextStyle.FULL, ES);
        return Character.toUpperCase(nombre.charAt(0)) + nombre.substring(1);
    }
}
