package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Coordenada {

    @Column(nullable = false)
    private double lat;

    @Column(nullable = false)
    private double lng;
}
