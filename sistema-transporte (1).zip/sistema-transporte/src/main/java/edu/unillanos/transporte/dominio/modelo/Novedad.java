package edu.unillanos.transporte.dominio.modelo;

import edu.unillanos.transporte.dominio.modelo.Enums.TipoNovedad;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Table(name = "novedades")
@Getter
@Setter
@NoArgsConstructor
public class Novedad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Recorrido recorrido;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private TipoNovedad tipo;

    @Column(length = 200)
    private String detalle;

    @Column(nullable = false)
    private Instant reportadaEn;

    private int pasajerosNotificados;
}
