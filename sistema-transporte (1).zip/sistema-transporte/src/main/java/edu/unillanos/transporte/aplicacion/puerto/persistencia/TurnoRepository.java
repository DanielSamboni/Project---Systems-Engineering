package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TurnoRepository extends JpaRepository<Turno, Long> {

    List<Turno> findAllByOrderByTipoDiaAscHoraInicioAsc();

    List<Turno> findByConductorIdOrderByTipoDiaAscHoraInicioAsc(Long conductorId);

    List<Turno> findByRutaId(Long rutaId);
}
