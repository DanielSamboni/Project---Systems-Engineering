package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.SeguimientoRuta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SeguimientoRutaRepository extends JpaRepository<SeguimientoRuta, Long> {

    List<SeguimientoRuta> findByRutaId(Long rutaId);

    List<SeguimientoRuta> findByPasajeroId(Long pasajeroId);

    Optional<SeguimientoRuta> findByPasajeroIdAndRutaId(Long pasajeroId, Long rutaId);
}
