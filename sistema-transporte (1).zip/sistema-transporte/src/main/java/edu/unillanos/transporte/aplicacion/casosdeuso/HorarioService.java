package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;

import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoSalida;
import edu.unillanos.transporte.dominio.modelo.Recordatorio;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.dominio.modelo.Salida;
import edu.unillanos.transporte.dominio.modelo.Usuario;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecordatorioRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.UsuarioRepository;
import edu.unillanos.transporte.dominio.reglas.EvaluadorProgramacion;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.Bloque;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.CrearRecordatorioRequest;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.HorariosRuta;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.RecordatorioDto;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** CU-02: consulta de la programación vigente (RF-05) y recordatorios (RF-06). */
@Service
@Transactional
public class HorarioService {

    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm");
    private static final int DIAS_AVISO_ACTUALIZACION = 7;
    private static final LocalTime FIN_BLOQUE_MANANA = LocalTime.of(10, 0);
    private static final LocalTime FIN_BLOQUE_MEDIODIA = LocalTime.of(15, 0);

    private final RutaService rutaService;
    private final RecordatorioRepository recordatorios;
    private final UsuarioRepository usuarios;
    private final NotificacionService notificaciones;
    private final Clock reloj;

    public HorarioService(RutaService rutaService, RecordatorioRepository recordatorios, UsuarioRepository usuarios,
                          NotificacionService notificaciones, Clock reloj) {
        this.rutaService = rutaService;
        this.recordatorios = recordatorios;
        this.usuarios = usuarios;
        this.notificaciones = notificaciones;
        this.reloj = reloj;
    }

    @Transactional(readOnly = true)
    public HorariosRuta horarios(Long rutaId, Long pasajeroId) {
        Ruta ruta = rutaService.buscarPublicada(rutaId);
        LocalDateTime ahora = LocalDateTime.now(reloj);
        String aviso = null;
        if (ruta.getUltimaPublicacion() != null
                && ruta.getUltimaPublicacion().isAfter(ahora.minusDays(DIAS_AVISO_ACTUALIZACION))) {
            aviso = "La programación de esta ruta se actualizó el " + FECHA.format(ruta.getUltimaPublicacion()) + ".";
        }
        List<Salida> salidas = ruta.getSalidas();
        return new HorariosRuta(ruta.getId(), ruta.getNombre(), ruta.getModalidad(), ruta.getUltimaPublicacion(), aviso,
                bloques(ruta.getModalidad(), salidas, TipoDia.HABIL),
                bloques(ruta.getModalidad(), salidas, TipoDia.SABADO),
                ahora.toLocalDate(),
                EvaluadorProgramacion.horasDeLaFecha(salidas, ahora.toLocalDate()),
                EvaluadorProgramacion.proximaSalida(salidas, ahora).orElse(null),
                pasajeroId != null && notificaciones.sigue(pasajeroId, rutaId));
    }

    public RecordatorioDto crearRecordatorio(Long pasajeroId, CrearRecordatorioRequest req) {
        Ruta ruta = rutaService.buscarPublicada(req.rutaId());
        LocalDateTime salida = req.fecha().atTime(req.hora());
        LocalDateTime ahora = LocalDateTime.now(reloj);

        if (!EvaluadorProgramacion.esSalidaValida(ruta.getSalidas(), salida)) {
            throw new ReglaNegocioException("La ruta no tiene una salida programada el " + FECHA.format(salida) + ".");
        }
        if (!salida.isAfter(ahora)) {
            LocalDateTime siguiente = EvaluadorProgramacion.proximaSalida(ruta.getSalidas(), ahora).orElse(null);
            String sugerencia = siguiente == null ? "" : " La siguiente salida disponible es el " + FECHA.format(siguiente) + ".";
            throw new ReglaNegocioException("La salida seleccionada ya ocurrió." + sugerencia,
                    siguiente == null ? Map.<String, Object>of() : Map.<String, Object>of("sugerencia", siguiente));
        }
        if (recordatorios.existsByPasajeroIdAndRutaIdAndSalidaProgramadaAndActivoTrue(pasajeroId, ruta.getId(), salida)) {
            throw new ReglaNegocioException("Ya tiene un recordatorio para esa salida.");
        }
        Usuario pasajero = usuarios.findById(pasajeroId).orElseThrow(() -> new NoEncontradoException("Pasajero", pasajeroId));
        Recordatorio r = new Recordatorio();
        r.setPasajero(pasajero);
        r.setRuta(ruta);
        r.setSalidaProgramada(salida);
        r.setMinutosAntes(req.minutosAntes() != null ? req.minutosAntes() : 15);
        return RecordatorioDto.de(recordatorios.save(r));
    }

    @Transactional(readOnly = true)
    public List<RecordatorioDto> recordatorios(Long pasajeroId) {
        return recordatorios.findByPasajeroIdAndActivoTrueOrderBySalidaProgramada(pasajeroId)
                .stream().map(RecordatorioDto::de).toList();
    }

    public void cancelarRecordatorio(Long pasajeroId, Long id) {
        Recordatorio r = recordatorios.findById(id)
                .filter(x -> x.getPasajero().getId().equals(pasajeroId))
                .orElseThrow(() -> new NoEncontradoException("Recordatorio", id));
        r.setActivo(false);
    }

    /** Dispara los recordatorios cuya hora de aviso ya llegó. */
    @Scheduled(fixedDelay = 30_000, initialDelay = 15_000)
    public void dispararRecordatorios() {
        LocalDateTime ahora = LocalDateTime.now(reloj);
        recordatorios.findByActivoTrueAndNotificadoFalseAndSalidaProgramadaBetween(ahora, ahora.plusHours(2)).stream()
                .filter(r -> !r.getSalidaProgramada().minusMinutes(r.getMinutosAntes()).isAfter(ahora))
                .forEach(r -> {
                    notificaciones.notificar(List.of(r.getPasajero()), "RECORDATORIO",
                            "Tu ruta sale pronto",
                            r.getRuta().getNombre() + " sale a las " + HORA.format(r.getSalidaProgramada()) + ".");
                    r.setNotificado(true);
                });
    }

    private static List<Bloque> bloques(Modalidad modalidad, List<Salida> salidas, TipoDia dia) {
        List<Salida> delDia = salidas.stream().filter(s -> s.getTipoDia() == dia).toList();
        List<Bloque> bloques = new ArrayList<>();
        if (modalidad == Modalidad.CENTRO) {
            for (Salida s : delDia) {
                if (s.getTipo() == TipoSalida.FRECUENCIA) {
                    bloques.add(new Bloque("Franja " + HORA.format(s.getHoraInicio()) + " – " + HORA.format(s.getHoraFin()),
                            "Salidas cada " + s.getFrecuenciaMinutos() + " minutos", s.horasDeSalida()));
                }
            }
            return bloques;
        }
        List<LocalTime> horas = EvaluadorProgramacion.horasDelDia(delDia, dia);
        agregarBloque(bloques, "Ingreso en la mañana", horas.stream().filter(h -> h.isBefore(FIN_BLOQUE_MANANA)).toList());
        agregarBloque(bloques, "Retorno al mediodía", horas.stream()
                .filter(h -> !h.isBefore(FIN_BLOQUE_MANANA) && h.isBefore(FIN_BLOQUE_MEDIODIA)).toList());
        agregarBloque(bloques, "Salida en la tarde", horas.stream().filter(h -> !h.isBefore(FIN_BLOQUE_MEDIODIA)).toList());
        return bloques;
    }

    private static void agregarBloque(List<Bloque> bloques, String nombre, List<LocalTime> horas) {
        if (!horas.isEmpty()) {
            bloques.add(new Bloque(nombre, horas.size() + " salida(s) puntuales", horas));
        }
    }
}
