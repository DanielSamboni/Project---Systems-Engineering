package edu.unillanos.transporte.infraestructura.seguridad;

import edu.unillanos.transporte.aplicacion.puerto.persistencia.UsuarioRepository;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;

import java.io.IOException;

/**
 * RF-01: autenticación con credenciales institucionales y autorización por perfil.
 * Sesión basada en cookie; el frontend se sirve desde el mismo origen.
 */
@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // Prototipo académico: mismo origen y cookie de sesión; en producción habilitar CSRF y TLS (RNF-04).
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/", "/index.html", "/css/**", "/js/**", "/img/**", "/favicon.ico", "/error").permitAll()
                        .requestMatchers("/pasajero.html", "/conductor.html", "/admin.html").permitAll()
                        .requestMatchers("/api/auth/**").permitAll()
                        .requestMatchers("/api/admin/**").hasRole("ADMINISTRADOR")
                        .requestMatchers("/api/conductor/**").hasRole("CONDUCTOR")
                        .requestMatchers("/api/pasajero/**").hasRole("PASAJERO")
                        .requestMatchers("/api/**").authenticated()
                        .anyRequest().permitAll())
                .formLogin(form -> form
                        .loginProcessingUrl("/api/auth/login")
                        .successHandler((req, res, auth) -> escribirJson(res, HttpStatus.OK,
                                "{\"rol\":\"" + ((UsuarioAutenticado) auth.getPrincipal()).rol() + "\"}"))
                        .failureHandler((req, res, ex) -> escribirJson(res, HttpStatus.UNAUTHORIZED,
                                "{\"mensaje\":\"Credenciales institucionales inválidas\"}")))
                .logout(logout -> logout
                        .logoutUrl("/api/auth/logout")
                        .logoutSuccessHandler((req, res, auth) -> res.setStatus(HttpStatus.NO_CONTENT.value())))
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED))
                        .accessDeniedHandler((req, res, e) -> escribirJson(res, HttpStatus.FORBIDDEN,
                                "{\"mensaje\":\"Su perfil no tiene permiso para esta acción.\"}")));
        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService(UsuarioRepository usuarios) {
        return username -> usuarios.findByUsername(username.trim().toLowerCase())
                .map(UsuarioAutenticado::de)
                .orElseThrow(() -> new UsernameNotFoundException(username));
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    private static void escribirJson(HttpServletResponse res, HttpStatus status, String json) throws IOException {
        res.setStatus(status.value());
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setCharacterEncoding("UTF-8");
        res.getWriter().write(json);
    }
}
