package edu.unillanos.transporte.dominio.modelo;

import edu.unillanos.transporte.dominio.modelo.Enums.MetodoLectura;
import edu.unillanos.transporte.dominio.modelo.Enums.ModoValidacion;
import edu.unillanos.transporte.dominio.modelo.Enums.ResultadoAcceso;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/** Registro de cada intento de abordaje, aprobado o denegado (RF-09). */
@Entity
@Table(name = "abordajes", indexes = @Index(columnList = "fechaHora"))
@Getter
@Setter
@NoArgsConstructor
public class Abordaje {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Ruta ruta;

    @ManyToOne(optional = false)
    private Vehiculo vehiculo;

    @ManyToOne
    private Recorrido recorrido;

    @Column(nullable = false, length = 30)
    private String identificadorLeido;

    @Column(length = 120)
    private String nombrePortador;

    @Column(nullable = false)
    private LocalDateTime fechaHora;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private ResultadoAcceso resultado;

    @Column(length = 120)
    private String motivo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private MetodoLectura metodo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private ModoValidacion modo;

    private boolean revisado = false;
}
