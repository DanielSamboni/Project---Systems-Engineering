package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "vehiculos")
@Getter
@Setter
@NoArgsConstructor
public class Vehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 10)
    private String placa;

    @Column(length = 60)
    private String descripcion;

    private boolean tieneGps = true;

    private boolean tieneLector = true;

    private boolean activo = true;

    public Vehiculo(String placa, String descripcion, boolean tieneGps) {
        this.placa = placa;
        this.descripcion = descripcion;
        this.tieneGps = tieneGps;
    }
}
