package edu.unillanos.transporte.dominio.modelo;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Optional;

public final class Enums {

    private Enums() {
    }

    public enum Rol { PASAJERO, CONDUCTOR, ADMINISTRADOR }

    public enum Modalidad { CENTRO, BARRIO }

    public enum TipoSalida { FRECUENCIA, PUNTUAL }

    public enum EstadoRecorrido { EN_CURSO, PAUSADO, FINALIZADO }

    public enum ResultadoAcceso { APROBADO, DENEGADO }

    public enum MetodoLectura { CODIGO_BARRAS, QR, NFC, MANUAL }

    public enum ModoValidacion { EN_LINEA, CONTINGENCIA }

    public enum TipoNovedad { RETRASO, CONGESTION, ACCIDENTE, VARADA }

    public enum EstadoCarnet { ACTIVO, INACTIVO, VENCIDO }

    public enum TipoDia {
        HABIL, SABADO;

        public static Optional<TipoDia> de(LocalDate fecha) {
            DayOfWeek dia = fecha.getDayOfWeek();
            if (dia == DayOfWeek.SUNDAY) {
                return Optional.empty();
            }
            return Optional.of(dia == DayOfWeek.SATURDAY ? SABADO : HABIL);
        }
    }
}
