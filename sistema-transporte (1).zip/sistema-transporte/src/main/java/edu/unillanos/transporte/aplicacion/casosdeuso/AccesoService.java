package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;

import edu.unillanos.transporte.dominio.modelo.Abordaje;
import edu.unillanos.transporte.dominio.modelo.Enums.EstadoCarnet;
import edu.unillanos.transporte.dominio.modelo.Enums.MetodoLectura;
import edu.unillanos.transporte.dominio.modelo.Enums.ModoValidacion;
import edu.unillanos.transporte.dominio.modelo.Enums.ResultadoAcceso;
import edu.unillanos.transporte.dominio.modelo.Recorrido;
import edu.unillanos.transporte.aplicacion.puerto.SistemaAcademicoGateway;
import edu.unillanos.transporte.aplicacion.puerto.SistemaAcademicoGateway.EstadoPortador;
import edu.unillanos.transporte.aplicacion.puerto.SistemaAcademicoGateway.SistemaAcademicoNoDisponibleException;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.AbordajeRepository;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.AbordajeDto;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.AbordajeOfflineRequest;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.CarnetVigenteDto;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.ResultadoValidacion;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.ValidarAccesoRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** CU-03: validación del carnet al abordar (RF-07, RF-08) y registro de abordajes (RF-09). */
@Service
@Transactional
public class AccesoService {

    private final RecorridoService recorridoService;
    private final SistemaAcademicoGateway sistemaAcademico;
    private final AbordajeRepository abordajes;
    private final Clock reloj;

    public AccesoService(RecorridoService recorridoService, SistemaAcademicoGateway sistemaAcademico,
                         AbordajeRepository abordajes, Clock reloj) {
        this.recorridoService = recorridoService;
        this.sistemaAcademico = sistemaAcademico;
        this.abordajes = abordajes;
        this.reloj = reloj;
    }

    public ResultadoValidacion validar(Long conductorId, Long recorridoId, ValidarAccesoRequest req) {
        Recorrido recorrido = recorridoActivo(conductorId, recorridoId);
        Optional<EstadoPortador> portador;
        try {
            portador = sistemaAcademico.consultar(req.identificador());
        } catch (SistemaAcademicoNoDisponibleException e) {
            // 3a: la terminal debe validar contra su copia local y sincronizar después.
            throw new ReglaNegocioException("El Sistema Académico Institucional no responde. Valide en modo contingencia.",
                    Map.of("contingencia", true));
        }

        ResultadoAcceso resultado;
        String motivo = null;
        if (portador.isEmpty()) {
            resultado = ResultadoAcceso.DENEGADO;
            motivo = "Carnet no registrado en el Sistema Académico";
        } else if (!portador.get().activo()) {
            resultado = ResultadoAcceso.DENEGADO;
            motivo = "Carnet " + (portador.get().estado() == EstadoCarnet.VENCIDO ? "vencido" : "inactivo");
        } else {
            resultado = ResultadoAcceso.APROBADO;
        }
        String nombre = portador.map(EstadoPortador::nombre).orElse(null);
        Abordaje a = registrar(recorrido, req.identificador(), nombre, LocalDateTime.now(reloj), resultado, motivo,
                req.metodo(), ModoValidacion.EN_LINEA);
        return new ResultadoValidacion(resultado, resultado == ResultadoAcceso.APROBADO ? "VERDE" : "ROJO",
                nombre, motivo, ModoValidacion.EN_LINEA, a.getFechaHora());
    }

    @Transactional(readOnly = true)
    public List<CarnetVigenteDto> carnetsVigentes(Long conductorId, Long recorridoId) {
        recorridoActivo(conductorId, recorridoId);
        try {
            return sistemaAcademico.carnetsVigentes().stream()
                    .map(p -> new CarnetVigenteDto(p.codigo(), p.documento(), p.nombre())).toList();
        } catch (SistemaAcademicoNoDisponibleException e) {
            throw new ReglaNegocioException("No fue posible descargar la copia de carnets: el Sistema Académico no responde.");
        }
    }

    /** Registra los abordajes validados sin conexión cuando la terminal recupera cobertura. */
    public int sincronizar(Long conductorId, Long recorridoId, List<AbordajeOfflineRequest> lote) {
        Recorrido recorrido = recorridoService.propio(conductorId, recorridoId);
        lote.forEach(o -> registrar(recorrido, o.identificador(), o.nombre(), o.fechaHora(), o.resultado(),
                o.resultado() == ResultadoAcceso.DENEGADO && o.motivo() == null ? "No figura en la copia local de carnets vigentes" : o.motivo(),
                o.metodo(), ModoValidacion.CONTINGENCIA));
        return lote.size();
    }

    @Transactional(readOnly = true)
    public List<AbordajeDto> recientes(Long conductorId, Long recorridoId) {
        recorridoService.propio(conductorId, recorridoId);
        return abordajes.findTop20ByRecorridoIdOrderByFechaHoraDesc(recorridoId).stream().map(AbordajeDto::de).toList();
    }

    // Administrador: revisión de accesos denegados (extensión «Registrar Acceso Denegado»)

    @Transactional(readOnly = true)
    public List<AbordajeDto> denegadosPendientes() {
        return abordajes.findByResultadoAndRevisadoFalseOrderByFechaHoraDesc(ResultadoAcceso.DENEGADO)
                .stream().map(AbordajeDto::de).toList();
    }

    public void marcarRevisado(Long id) {
        abordajes.findById(id).orElseThrow(() -> new NoEncontradoException("Abordaje", id)).setRevisado(true);
    }

    private Recorrido recorridoActivo(Long conductorId, Long recorridoId) {
        Recorrido r = recorridoService.propio(conductorId, recorridoId);
        if (!r.estaActivo()) {
            throw new ReglaNegocioException("La validación requiere un recorrido iniciado.");
        }
        return r;
    }

    private Abordaje registrar(Recorrido recorrido, String identificador, String nombre, LocalDateTime fechaHora,
                               ResultadoAcceso resultado, String motivo, MetodoLectura metodo, ModoValidacion modo) {
        Abordaje a = new Abordaje();
        a.setRecorrido(recorrido);
        a.setRuta(recorrido.getRuta());
        a.setVehiculo(recorrido.getVehiculo());
        a.setIdentificadorLeido(identificador.trim());
        a.setNombrePortador(nombre);
        a.setFechaHora(fechaHora);
        a.setResultado(resultado);
        a.setMotivo(motivo);
        a.setMetodo(metodo);
        a.setModo(modo);
        return abordajes.save(a);
    }
}
