package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;

import edu.unillanos.transporte.dominio.modelo.Enums.Rol;
import edu.unillanos.transporte.dominio.modelo.Notificacion;
import edu.unillanos.transporte.dominio.modelo.Recordatorio;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.dominio.modelo.SeguimientoRuta;
import edu.unillanos.transporte.dominio.modelo.Usuario;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.NotificacionRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecordatorioRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RutaRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.SeguimientoRutaRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.UsuarioRepository;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.Bandeja;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.NotificacionDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Entrega de notificaciones a los pasajeros. La bandeja persistida simula el canal push:
 * la aplicación la consulta periódicamente y muestra cada notificación nueva como alerta.
 */
@Service
@Transactional
public class NotificacionService {

    private final NotificacionRepository notificaciones;
    private final SeguimientoRutaRepository seguimientos;
    private final RecordatorioRepository recordatorios;
    private final RutaRepository rutas;
    private final UsuarioRepository usuarios;
    private final Clock reloj;

    public NotificacionService(NotificacionRepository notificaciones, SeguimientoRutaRepository seguimientos,
                               RecordatorioRepository recordatorios, RutaRepository rutas,
                               UsuarioRepository usuarios, Clock reloj) {
        this.notificaciones = notificaciones;
        this.seguimientos = seguimientos;
        this.recordatorios = recordatorios;
        this.rutas = rutas;
        this.usuarios = usuarios;
        this.reloj = reloj;
    }

    public int notificar(Collection<Usuario> destinatarios, String categoria, String titulo, String mensaje) {
        Instant ahora = Instant.now(reloj);
        List<Notificacion> nuevas = destinatarios.stream()
                .map(u -> new Notificacion(u, categoria, titulo, mensaje, ahora))
                .toList();
        notificaciones.saveAll(nuevas);
        return nuevas.size();
    }

    /** Pasajeros que siguen la ruta o tienen recordatorios activos en ella. */
    @Transactional(readOnly = true)
    public Collection<Usuario> interesadosEnRuta(Long rutaId) {
        Map<Long, Usuario> destinatarios = new LinkedHashMap<>();
        seguimientos.findByRutaId(rutaId).forEach(s -> destinatarios.put(s.getPasajero().getId(), s.getPasajero()));
        conRecordatoriosActivos(rutaId).forEach(u -> destinatarios.put(u.getId(), u));
        return destinatarios.values();
    }

    @Transactional(readOnly = true)
    public Collection<Usuario> conRecordatoriosActivos(Long rutaId) {
        LocalDateTime ahora = LocalDateTime.now(reloj);
        Map<Long, Usuario> destinatarios = new LinkedHashMap<>();
        recordatorios.findByRutaIdAndActivoTrueAndSalidaProgramadaAfter(rutaId, ahora)
                .stream().map(Recordatorio::getPasajero)
                .forEach(u -> destinatarios.put(u.getId(), u));
        return destinatarios.values();
    }

    @Transactional(readOnly = true)
    public Bandeja bandeja(Long usuarioId) {
        List<NotificacionDto> items = notificaciones.findTop30ByUsuarioIdOrderByCreadaEnDesc(usuarioId)
                .stream().map(NotificacionDto::de).toList();
        return new Bandeja(notificaciones.countByUsuarioIdAndLeidaFalse(usuarioId), items);
    }

    public void marcarLeidas(Long usuarioId) {
        notificaciones.findTop30ByUsuarioIdOrderByCreadaEnDesc(usuarioId).forEach(n -> n.setLeida(true));
    }

    // Seguimiento de rutas

    @Transactional(readOnly = true)
    public List<Long> rutasSeguidas(Long pasajeroId) {
        return seguimientos.findByPasajeroId(pasajeroId).stream().map(s -> s.getRuta().getId()).toList();
    }

    @Transactional(readOnly = true)
    public boolean sigue(Long pasajeroId, Long rutaId) {
        return seguimientos.findByPasajeroIdAndRutaId(pasajeroId, rutaId).isPresent();
    }

    public void seguir(Long pasajeroId, Long rutaId) {
        if (sigue(pasajeroId, rutaId)) {
            return;
        }
        Usuario pasajero = usuarios.findById(pasajeroId)
                .filter(u -> u.getRol() == Rol.PASAJERO)
                .orElseThrow(() -> new NoEncontradoException("Pasajero", pasajeroId));
        Ruta ruta = rutas.findById(rutaId).orElseThrow(() -> new NoEncontradoException("Ruta", rutaId));
        seguimientos.save(new SeguimientoRuta(pasajero, ruta));
    }

    public void dejarDeSeguir(Long pasajeroId, Long rutaId) {
        seguimientos.findByPasajeroIdAndRutaId(pasajeroId, rutaId).ifPresent(seguimientos::delete);
    }
}
