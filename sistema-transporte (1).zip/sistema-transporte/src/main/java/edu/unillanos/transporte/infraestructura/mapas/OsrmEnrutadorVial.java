package edu.unillanos.transporte.infraestructura.mapas;

import edu.unillanos.transporte.aplicacion.puerto.EnrutadorVial;
import edu.unillanos.transporte.dominio.modelo.Coordenada;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

/** Adaptador del puerto {@link EnrutadorVial} sobre el servicio OSRM (datos de OpenStreetMap). */
@Component
public class OsrmEnrutadorVial implements EnrutadorVial {

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final JsonMapper json;
    private final String urlBase;

    public OsrmEnrutadorVial(JsonMapper json, @Value("${app.osrm.url}") String urlBase) {
        this.json = json;
        this.urlBase = urlBase;
    }

    @Override
    public Recorrido trazarPorVias(List<Coordenada> puntosDePaso) throws EnrutadorNoDisponibleException {
        String coordenadas = puntosDePaso.stream()
                .map(c -> String.format(Locale.ROOT, "%.6f,%.6f", c.getLng(), c.getLat()))
                .collect(Collectors.joining(";"));
        URI uri = URI.create(urlBase + "/route/v1/driving/" + coordenadas + "?overview=full&geometries=geojson");
        HttpRequest peticion = HttpRequest.newBuilder(uri)
                .timeout(Duration.ofSeconds(10))
                .header("User-Agent", "SistemaTransporteUnillanos/1.0")
                .GET().build();
        try {
            HttpResponse<String> respuesta = http.send(peticion, HttpResponse.BodyHandlers.ofString());
            JsonNode raiz = json.readTree(respuesta.body());
            if (respuesta.statusCode() != 200 || !"Ok".equals(raiz.path("code").asString())) {
                throw new EnrutadorNoDisponibleException("El servicio de rutas no encontró un recorrido por las vías ("
                        + raiz.path("code").asString() + ").", null);
            }
            JsonNode ruta = raiz.path("routes").get(0);
            List<Coordenada> trazado = new ArrayList<>();
            for (JsonNode punto : ruta.path("geometry").path("coordinates")) {
                trazado.add(new Coordenada(punto.get(1).asDouble(), punto.get(0).asDouble()));
            }
            List<Coordenada> ajustados = new ArrayList<>();
            for (JsonNode punto : raiz.path("waypoints")) {
                JsonNode ubicacion = punto.path("location");
                ajustados.add(new Coordenada(ubicacion.get(1).asDouble(), ubicacion.get(0).asDouble()));
            }
            return new Recorrido(trazado, ajustados, ruta.path("distance").asDouble(), ruta.path("duration").asDouble());
        } catch (IOException | JacksonException e) {
            throw new EnrutadorNoDisponibleException("No fue posible conectarse al servicio de rutas.", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new EnrutadorNoDisponibleException("La consulta al servicio de rutas fue interrumpida.", e);
        }
    }
}
