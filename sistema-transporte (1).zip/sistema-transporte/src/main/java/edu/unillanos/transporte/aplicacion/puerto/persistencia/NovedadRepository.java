package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.Novedad;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;

public interface NovedadRepository extends JpaRepository<Novedad, Long> {

    List<Novedad> findByRecorridoRutaIdAndReportadaEnAfterOrderByReportadaEnDesc(Long rutaId, Instant desde);

    List<Novedad> findByReportadaEnAfterOrderByReportadaEnDesc(Instant desde);

    List<Novedad> findByReportadaEnBetween(Instant desde, Instant hasta);
}
