package edu.unillanos.transporte.aplicacion.puerto;

import edu.unillanos.transporte.dominio.modelo.Coordenada;

import java.util.List;

/**
 * Puerto hacia un proveedor de rutas viales: dado un conjunto de puntos de paso devuelve
 * el recorrido que sigue las calles. Permite cambiar de proveedor sin tocar la lógica de negocio (RNF-11).
 */
public interface EnrutadorVial {

    Recorrido trazarPorVias(List<Coordenada> puntosDePaso) throws EnrutadorNoDisponibleException;

    /**
     * @param trazado         polilínea sobre las vías
     * @param puntosAjustados cada punto de paso desplazado a la vía más cercana
     */
    record Recorrido(List<Coordenada> trazado, List<Coordenada> puntosAjustados, double distanciaMetros,
                     double duracionSegundos) {
    }

    class EnrutadorNoDisponibleException extends Exception {
        public EnrutadorNoDisponibleException(String mensaje, Throwable causa) {
            super(mensaje, causa);
        }
    }
}
