package edu.unillanos.transporte.infraestructura.academico;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CarnetInstitucionalRepository extends JpaRepository<CarnetInstitucional, String> {

    Optional<CarnetInstitucional> findByDocumento(String documento);
}
