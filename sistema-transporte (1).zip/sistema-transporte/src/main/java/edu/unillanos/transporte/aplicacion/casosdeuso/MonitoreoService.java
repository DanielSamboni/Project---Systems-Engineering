package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.aplicacion.dto.AdminDtos.BusFlota;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.EstadoFlota;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.NovedadFlota;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.ResumenFlota;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.NovedadDto;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.AbordajeRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.NovedadRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecorridoRepository;
import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;
import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Recorrido;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

/** Supervisión del servicio por la oficina de transporte: toda la flota en vivo y las novedades del día. */
@Service
@Transactional
public class MonitoreoService {

    private static final List<EstadoRecorrido> ACTIVOS = List.of(EstadoRecorrido.EN_CURSO, EstadoRecorrido.PAUSADO);

    private final RecorridoRepository recorridos;
    private final NovedadRepository novedades;
    private final AbordajeRepository abordajes;
    private final Clock reloj;
    private final long antiguedadMaximaSeg;

    public MonitoreoService(RecorridoRepository recorridos, NovedadRepository novedades, AbordajeRepository abordajes,
                            Clock reloj, @Value("${app.antiguedad-maxima-posicion-seg}") long antiguedadMaximaSeg) {
        this.recorridos = recorridos;
        this.novedades = novedades;
        this.abordajes = abordajes;
        this.reloj = reloj;
        this.antiguedadMaximaSeg = antiguedadMaximaSeg;
    }

    @Transactional(readOnly = true)
    public EstadoFlota estadoFlota() {
        Instant ahora = Instant.now(reloj);
        LocalDate hoy = LocalDate.now(reloj);
        Instant inicioDelDia = hoy.atStartOfDay(reloj.getZone()).toInstant();

        List<BusFlota> buses = recorridos.findByEstadoIn(ACTIVOS).stream()
                .sorted(Comparator.comparing((Recorrido r) -> r.getRuta().getNombre()).thenComparing(Recorrido::getInicio))
                .map(r -> aBus(r, ahora))
                .toList();
        List<NovedadFlota> delDia = novedades.findByReportadaEnAfterOrderByReportadaEnDesc(inicioDelDia).stream()
                .map(n -> new NovedadFlota(new NovedadDto(n.getId(), n.getTipo(), n.getDetalle(), n.getReportadaEn(),
                        n.getRecorrido().getVehiculo().getPlaca()), n.getRecorrido().getRuta().getNombre(), n.getPasajerosNotificados()))
                .toList();

        ResumenFlota resumen = new ResumenFlota(
                buses.size(),
                (int) buses.stream().filter(b -> b.lat() == null || b.desactualizada()).count(),
                abordajes.countByFechaHoraBetween(hoy.atStartOfDay(), hoy.plusDays(1).atStartOfDay()),
                delDia.size(),
                buses.stream().map(BusFlota::rutaId).distinct().count());
        return new EstadoFlota(resumen, buses, delDia, ahora);
    }

    /** Cierra un recorrido que el conductor dejó abierto (p. ej. la terminal se apagó antes de finalizar). */
    public void finalizarRecorrido(Long id) {
        Recorrido r = recorridos.findById(id).orElseThrow(() -> new NoEncontradoException("Recorrido", id));
        if (!r.estaActivo()) {
            throw new ReglaNegocioException("El recorrido ya fue finalizado.");
        }
        r.setEstado(EstadoRecorrido.FINALIZADO);
        r.setFin(Instant.now(reloj));
    }

    private BusFlota aBus(Recorrido r, Instant ahora) {
        boolean conPosicion = r.getUltimaPosicion() != null;
        Long antiguedad = conPosicion ? Math.max(0, Duration.between(r.getUltimaPosicionEn(), ahora).toSeconds()) : null;
        boolean desactualizada = !conPosicion || antiguedad > antiguedadMaximaSeg || r.getEstado() == EstadoRecorrido.PAUSADO;
        return new BusFlota(r.getId(), r.getRuta().getId(), r.getRuta().getNombre(), r.getRuta().getModalidad(),
                r.getVehiculo().getPlaca(), r.getConductor().getNombreCompleto(), r.getEstado(), r.getVehiculo().isTieneGps(),
                conPosicion ? r.getUltimaPosicion().getLat() : null, conPosicion ? r.getUltimaPosicion().getLng() : null,
                r.getUltimaPosicionEn(), antiguedad, desactualizada, r.getInicio(), abordajes.countByRecorridoId(r.getId()));
    }
}
