package edu.unillanos.transporte.aplicacion.dto;

import edu.unillanos.transporte.dominio.modelo.Coordenada;
import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoSalida;
import edu.unillanos.transporte.dominio.modelo.Parada;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.dominio.modelo.Salida;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public final class RutaDtos {

    private RutaDtos() {
    }

    public record CoordenadaDto(double lat, double lng) {
        public static CoordenadaDto de(Coordenada c) {
            return c == null ? null : new CoordenadaDto(c.getLat(), c.getLng());
        }

        public Coordenada aDominio() {
            return new Coordenada(lat, lng);
        }
    }

    public record ParadaDto(Long id, String nombre, int orden, double lat, double lng) {
        public static ParadaDto de(Parada p) {
            return new ParadaDto(p.getId(), p.getNombre(), p.getOrden(), p.getUbicacion().getLat(), p.getUbicacion().getLng());
        }
    }

    public record SalidaDto(Long id, TipoDia tipoDia, TipoSalida tipo, LocalTime horaInicio, LocalTime horaFin,
                            Integer frecuenciaMinutos) {
        public static SalidaDto de(Salida s) {
            return new SalidaDto(s.getId(), s.getTipoDia(), s.getTipo(), s.getHoraInicio(), s.getHoraFin(), s.getFrecuenciaMinutos());
        }

        public Salida aDominio() {
            Salida s = new Salida();
            s.setTipoDia(tipoDia);
            s.setTipo(tipo);
            s.setHoraInicio(horaInicio);
            s.setHoraFin(tipo == TipoSalida.FRECUENCIA ? horaFin : null);
            s.setFrecuenciaMinutos(tipo == TipoSalida.FRECUENCIA ? frecuenciaMinutos : null);
            return s;
        }
    }

    public record RutaResumen(Long id, String nombre, Modalidad modalidad, String descripcion, boolean activa,
                              boolean publicada, LocalDateTime ultimaPublicacion, int paradas, int salidas,
                              long busesActivos) {
        public static RutaResumen de(Ruta r) {
            return de(r, 0);
        }

        public static RutaResumen de(Ruta r, long busesActivos) {
            return new RutaResumen(r.getId(), r.getNombre(), r.getModalidad(), r.getDescripcion(), r.isActiva(),
                    r.isPublicada(), r.getUltimaPublicacion(), r.getParadas().size(), r.getSalidas().size(), busesActivos);
        }
    }

    public record RutaDetalle(Long id, String nombre, Modalidad modalidad, String descripcion, int duracionEstimadaMin,
                              boolean activa, boolean publicada, LocalDateTime ultimaPublicacion,
                              LocalDateTime vigenteDesde, List<CoordenadaDto> trazado, List<ParadaDto> paradas,
                              List<SalidaDto> salidas) {
        public static RutaDetalle de(Ruta r) {
            return new RutaDetalle(r.getId(), r.getNombre(), r.getModalidad(), r.getDescripcion(),
                    r.getDuracionEstimadaMin(), r.isActiva(), r.isPublicada(), r.getUltimaPublicacion(),
                    r.getVigenteDesde(), r.getTrazado().stream().map(CoordenadaDto::de).toList(),
                    r.getParadas().stream().map(ParadaDto::de).toList(),
                    r.getSalidas().stream().map(SalidaDto::de).toList());
        }
    }

    public record MapaRuta(Long id, String nombre, Modalidad modalidad, List<CoordenadaDto> trazado,
                           List<ParadaDto> paradas) {
        public static MapaRuta de(Ruta r) {
            return new MapaRuta(r.getId(), r.getNombre(), r.getModalidad(),
                    r.getTrazado().stream().map(CoordenadaDto::de).toList(),
                    r.getParadas().stream().map(ParadaDto::de).toList());
        }
    }

    /** Completitud y solapamientos los valida ValidadorProgramacion, para informar todos los conflictos a la vez. */
    public record GuardarRutaRequest(@Size(max = 80) String nombre, Modalidad modalidad,
                                     @Size(max = 255) String descripcion,
                                     Integer duracionEstimadaMin, List<CoordenadaDto> trazado,
                                     List<ParadaDto> paradas, List<SalidaDto> salidas, boolean publicar,
                                     LocalDateTime vigenteDesde) {
    }

    public record ResultadoGuardado(RutaDetalle ruta, boolean urgente, int pasajerosNotificados) {
    }

    public record TrazarPorViasRequest(@NotNull @Size(min = 2, max = 25, message = "Indique entre 2 y 25 puntos de paso")
                                       List<CoordenadaDto> puntos) {
    }

    public record TrazadoSugerido(List<CoordenadaDto> trazado, List<CoordenadaDto> puntosAjustados, double distanciaKm,
                                  int duracionEstimadaMin) {
    }
}
