package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Coordenada;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public final class Geo {

    private static final double RADIO_TIERRA_M = 6_371_000;
    private static final double METROS_POR_GRADO_LAT = 110_540;
    private static final double METROS_POR_GRADO_LNG_ECUADOR = 111_320;

    private Geo() {
    }

    public static double distanciaMetros(Coordenada a, Coordenada b) {
        double lat1 = Math.toRadians(a.getLat());
        double lat2 = Math.toRadians(b.getLat());
        double dLat = lat2 - lat1;
        double dLng = Math.toRadians(b.getLng() - a.getLng());
        double h = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return 2 * RADIO_TIERRA_M * Math.asin(Math.min(1, Math.sqrt(h)));
    }

    public static double longitudMetros(List<Coordenada> trazado) {
        double total = 0;
        for (int i = 0; i + 1 < trazado.size(); i++) {
            total += distanciaMetros(trazado.get(i), trazado.get(i + 1));
        }
        return total;
    }

    /** Douglas-Peucker: elimina puntos que se desvían menos de la tolerancia, conservando la forma de la vía. */
    public static List<Coordenada> simplificar(List<Coordenada> puntos, double toleranciaMetros) {
        if (puntos.size() < 3) {
            return List.copyOf(puntos);
        }
        boolean[] conservar = new boolean[puntos.size()];
        conservar[0] = true;
        conservar[puntos.size() - 1] = true;
        ArrayDeque<int[]> pendientes = new ArrayDeque<>();
        pendientes.push(new int[]{0, puntos.size() - 1});
        while (!pendientes.isEmpty()) {
            int[] tramo = pendientes.pop();
            double maxima = 0;
            int indice = -1;
            for (int i = tramo[0] + 1; i < tramo[1]; i++) {
                double d = distanciaASegmento(puntos.get(i), puntos.get(tramo[0]), puntos.get(tramo[1]));
                if (d > maxima) {
                    maxima = d;
                    indice = i;
                }
            }
            if (indice >= 0 && maxima > toleranciaMetros) {
                conservar[indice] = true;
                pendientes.push(new int[]{tramo[0], indice});
                pendientes.push(new int[]{indice, tramo[1]});
            }
        }
        List<Coordenada> resultado = new ArrayList<>();
        for (int i = 0; i < puntos.size(); i++) {
            if (conservar[i]) {
                resultado.add(puntos.get(i));
            }
        }
        return resultado;
    }

    static double distanciaASegmento(Coordenada p, Coordenada a, Coordenada b) {
        double cosLat = Math.cos(Math.toRadians(p.getLat()));
        double ax = (a.getLng() - p.getLng()) * METROS_POR_GRADO_LNG_ECUADOR * cosLat;
        double ay = (a.getLat() - p.getLat()) * METROS_POR_GRADO_LAT;
        double bx = (b.getLng() - p.getLng()) * METROS_POR_GRADO_LNG_ECUADOR * cosLat;
        double by = (b.getLat() - p.getLat()) * METROS_POR_GRADO_LAT;
        double dx = bx - ax;
        double dy = by - ay;
        double largo2 = dx * dx + dy * dy;
        double t = largo2 == 0 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / largo2));
        return Math.hypot(ax + t * dx, ay + t * dy);
    }

    /**
     * Metros recorridos sobre el trazado hasta la proyección del punto sobre el segmento más cercano.
     */
    public static double progresoSobreTrazado(List<Coordenada> trazado, Coordenada punto) {
        if (trazado.size() < 2) {
            return 0;
        }
        double cosLat = Math.cos(Math.toRadians(punto.getLat()));
        double mejorDistancia = Double.MAX_VALUE;
        double mejorProgreso = 0;
        double acumulado = 0;
        for (int i = 0; i + 1 < trazado.size(); i++) {
            Coordenada a = trazado.get(i);
            Coordenada b = trazado.get(i + 1);
            double ax = (a.getLng() - punto.getLng()) * METROS_POR_GRADO_LNG_ECUADOR * cosLat;
            double ay = (a.getLat() - punto.getLat()) * METROS_POR_GRADO_LAT;
            double bx = (b.getLng() - punto.getLng()) * METROS_POR_GRADO_LNG_ECUADOR * cosLat;
            double by = (b.getLat() - punto.getLat()) * METROS_POR_GRADO_LAT;
            double dx = bx - ax;
            double dy = by - ay;
            double largo2 = dx * dx + dy * dy;
            double t = largo2 == 0 ? 0 : Math.max(0, Math.min(1, -(ax * dx + ay * dy) / largo2));
            double px = ax + t * dx;
            double py = ay + t * dy;
            double distancia = Math.hypot(px, py);
            double largoSegmento = distanciaMetros(a, b);
            if (distancia < mejorDistancia) {
                mejorDistancia = distancia;
                mejorProgreso = acumulado + t * largoSegmento;
            }
            acumulado += largoSegmento;
        }
        return mejorProgreso;
    }
}
