package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.aplicacion.dto.RutaDtos.CoordenadaDto;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.GuardarRutaRequest;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.MapaRuta;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.ParadaDto;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.ResultadoGuardado;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.RutaDetalle;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.RutaResumen;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.SalidaDto;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.TrazadoSugerido;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.TrazarPorViasRequest;
import edu.unillanos.transporte.aplicacion.puerto.EnrutadorVial;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecorridoRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RutaRepository;
import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;
import edu.unillanos.transporte.dominio.modelo.Coordenada;
import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Parada;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import edu.unillanos.transporte.dominio.modelo.Salida;
import edu.unillanos.transporte.dominio.reglas.Geo;
import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion;
import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion.Conflicto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/** CU-05: crear, editar, validar y publicar rutas, paradas y horarios (RF-12). */
@Service
@Transactional
public class RutaService {

    private static final DateTimeFormatter FORMATO = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private static final double TOLERANCIA_SIMPLIFICACION_M = 6;
    private static final double FACTOR_DURACION_BUS = 1.6;

    private final RutaRepository rutas;
    private final RecorridoRepository recorridos;
    private final NotificacionService notificaciones;
    private final EnrutadorVial enrutador;
    private final Clock reloj;
    private final int horasAnticipacionUrgente;

    public RutaService(RutaRepository rutas, RecorridoRepository recorridos, NotificacionService notificaciones,
                       EnrutadorVial enrutador, Clock reloj,
                       @Value("${app.horas-anticipacion-urgente}") int horasAnticipacionUrgente) {
        this.rutas = rutas;
        this.recorridos = recorridos;
        this.notificaciones = notificaciones;
        this.enrutador = enrutador;
        this.reloj = reloj;
        this.horasAnticipacionUrgente = horasAnticipacionUrgente;
    }

    /** Calcula el trazado que sigue las calles pasando por los puntos indicados (normalmente las paradas). */
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public TrazadoSugerido trazarPorVias(TrazarPorViasRequest req) {
        try {
            EnrutadorVial.Recorrido r = enrutador.trazarPorVias(req.puntos().stream().map(CoordenadaDto::aDominio).toList());
            List<Coordenada> trazado = Geo.simplificar(r.trazado(), TOLERANCIA_SIMPLIFICACION_M);
            int duracion = (int) Math.max(10, Math.round(r.duracionSegundos() / 60 * FACTOR_DURACION_BUS));
            return new TrazadoSugerido(trazado.stream().map(CoordenadaDto::de).toList(),
                    r.puntosAjustados().stream().map(CoordenadaDto::de).toList(),
                    Math.round(r.distanciaMetros() / 100) / 10.0, duracion);
        } catch (EnrutadorVial.EnrutadorNoDisponibleException e) {
            throw new ReglaNegocioException(e.getMessage() + " Puede dibujar el trazado manualmente sobre el mapa.");
        }
    }

    @Transactional(readOnly = true)
    public List<RutaResumen> listarTodas() {
        return rutas.findAllByOrderByModalidadAscNombreAsc().stream().map(RutaResumen::de).toList();
    }

    @Transactional(readOnly = true)
    public RutaDetalle detalle(Long id) {
        return RutaDetalle.de(buscar(id));
    }

    @Transactional(readOnly = true)
    public List<Conflicto> validar(GuardarRutaRequest req, Long idExcluido) {
        List<Conflicto> conflictos = new ArrayList<>(ValidadorProgramacion.validarRuta(req.nombre(), req.modalidad(),
                tamano(req.paradas()), tamano(req.trazado()), salidas(req)));
        if (req.paradas() != null) {
            for (int i = 0; i < req.paradas().size(); i++) {
                String nombre = req.paradas().get(i).nombre();
                if (nombre == null || nombre.isBlank()) {
                    conflictos.add(new Conflicto("paradas", "La parada " + (i + 1) + " no tiene nombre."));
                } else if (nombre.trim().length() > 80) {
                    conflictos.add(new Conflicto("paradas", "El nombre de la parada " + (i + 1) + " supera 80 caracteres."));
                }
            }
        }
        if (req.nombre() != null && !req.nombre().isBlank()) {
            boolean duplicado = rutas.findAll().stream()
                    .anyMatch(r -> r.getNombre().equalsIgnoreCase(req.nombre().trim()) && !r.getId().equals(idExcluido));
            if (duplicado) {
                conflictos.add(new Conflicto("nombre", "Ya existe una ruta con ese nombre."));
            }
        }
        return conflictos;
    }

    public ResultadoGuardado crear(GuardarRutaRequest req) {
        return guardar(new Ruta(), req);
    }

    public ResultadoGuardado actualizar(Long id, GuardarRutaRequest req) {
        return guardar(buscar(id), req);
    }

    public RutaResumen cambiarActiva(Long id, boolean activa) {
        Ruta ruta = buscar(id);
        ruta.setActiva(activa);
        return RutaResumen.de(ruta);
    }

    // Consultas del pasajero: solo rutas publicadas y activas

    @Transactional(readOnly = true)
    public List<RutaResumen> listarPublicadas(Modalidad modalidad) {
        List<Ruta> lista = modalidad == null
                ? rutas.findByPublicadaTrueAndActivaTrueOrderByModalidadAscNombreAsc()
                : rutas.findByModalidadAndPublicadaTrueAndActivaTrueOrderByNombre(modalidad);
        Map<Long, Long> busesPorRuta = recorridos.findByEstadoIn(List.of(EstadoRecorrido.EN_CURSO, EstadoRecorrido.PAUSADO))
                .stream().collect(Collectors.groupingBy(r -> r.getRuta().getId(), Collectors.counting()));
        return lista.stream().map(r -> RutaResumen.de(r, busesPorRuta.getOrDefault(r.getId(), 0L))).toList();
    }

    @Transactional(readOnly = true)
    public MapaRuta mapa(Long id) {
        return MapaRuta.de(buscarPublicada(id));
    }

    @Transactional(readOnly = true)
    public Ruta buscarPublicada(Long id) {
        Ruta ruta = buscar(id);
        if (!ruta.isPublicada() || !ruta.isActiva()) {
            throw new NoEncontradoException("Ruta publicada", id);
        }
        return ruta;
    }

    Ruta buscar(Long id) {
        return rutas.findById(id).orElseThrow(() -> new NoEncontradoException("Ruta", id));
    }

    private ResultadoGuardado guardar(Ruta ruta, GuardarRutaRequest req) {
        List<Conflicto> conflictos = validar(req, ruta.getId());
        if (!conflictos.isEmpty()) {
            throw new ReglaNegocioException("La programación tiene campos incompletos o en conflicto", conflictos);
        }
        boolean yaEstabaPublicada = ruta.isPublicada();

        ruta.setNombre(req.nombre().trim());
        ruta.setModalidad(req.modalidad());
        ruta.setDescripcion(req.descripcion());
        if (req.duracionEstimadaMin() != null && req.duracionEstimadaMin() > 0) {
            ruta.setDuracionEstimadaMin(req.duracionEstimadaMin());
        }
        ruta.getTrazado().clear();
        req.trazado().stream().map(CoordenadaDto::aDominio).forEach(ruta.getTrazado()::add);
        List<ParadaDto> paradas = req.paradas();
        ruta.reemplazarParadas(IntStream.range(0, paradas.size())
                .mapToObj(i -> new Parada(paradas.get(i).nombre().trim(), i + 1, paradas.get(i).lat(), paradas.get(i).lng()))
                .toList());
        ruta.reemplazarSalidas(salidas(req));

        boolean urgente = false;
        int notificados = 0;
        if (req.publicar() || yaEstabaPublicada) {
            LocalDateTime ahora = LocalDateTime.now(reloj);
            LocalDateTime vigenteDesde = req.vigenteDesde() != null ? req.vigenteDesde() : ahora;
            ruta.setPublicada(true);
            ruta.setUltimaPublicacion(ahora);
            ruta.setVigenteDesde(vigenteDesde);
            urgente = yaEstabaPublicada && vigenteDesde.isBefore(ahora.plusHours(horasAnticipacionUrgente));
        }
        rutas.save(ruta);

        if (urgente) {
            notificados = notificaciones.notificar(notificaciones.conRecordatoriosActivos(ruta.getId()), "URGENTE",
                    "Cambio urgente en " + ruta.getNombre(),
                    "La programación de la ruta cambia a partir del " + FORMATO.format(ruta.getVigenteDesde())
                            + ". Revise los horarios y sus recordatorios.");
        }
        return new ResultadoGuardado(RutaDetalle.de(ruta), urgente, notificados);
    }

    private static List<Salida> salidas(GuardarRutaRequest req) {
        return req.salidas() == null ? List.of() : req.salidas().stream().map(SalidaDto::aDominio).toList();
    }

    private static int tamano(List<?> lista) {
        return lista == null ? 0 : lista.size();
    }
}
