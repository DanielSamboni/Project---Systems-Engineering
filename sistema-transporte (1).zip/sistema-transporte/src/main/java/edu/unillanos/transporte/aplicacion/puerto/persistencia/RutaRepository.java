package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Ruta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RutaRepository extends JpaRepository<Ruta, Long> {

    List<Ruta> findAllByOrderByModalidadAscNombreAsc();

    List<Ruta> findByPublicadaTrueAndActivaTrueOrderByModalidadAscNombreAsc();

    List<Ruta> findByModalidadAndPublicadaTrueAndActivaTrueOrderByNombre(Modalidad modalidad);

    Optional<Ruta> findByNombreIgnoreCase(String nombre);
}
