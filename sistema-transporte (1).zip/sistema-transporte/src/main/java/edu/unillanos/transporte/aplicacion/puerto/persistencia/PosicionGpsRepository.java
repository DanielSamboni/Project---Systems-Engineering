package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.PosicionGps;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PosicionGpsRepository extends JpaRepository<PosicionGps, Long> {

    List<PosicionGps> findTop5ByRecorridoIdOrderByCapturadaEnDesc(Long recorridoId);
}
