package edu.unillanos.transporte.infraestructura.seguridad;

import edu.unillanos.transporte.aplicacion.puerto.CifradorClaves;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class CifradorClavesBCrypt implements CifradorClaves {

    private final PasswordEncoder encoder;

    public CifradorClavesBCrypt(PasswordEncoder encoder) {
        this.encoder = encoder;
    }

    @Override
    public String cifrar(String claveEnClaro) {
        return encoder.encode(claveEnClaro);
    }
}
