package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/** Histórico de posiciones del vehículo. Nunca se almacena la ubicación del pasajero (RNF-05). */
@Entity
@Table(name = "posiciones_gps", indexes = @Index(columnList = "recorrido_id, capturadaEn"))
@Getter
@Setter
@NoArgsConstructor
public class PosicionGps {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Recorrido recorrido;

    @Embedded
    private Coordenada coordenada;

    @Column(nullable = false)
    private Instant capturadaEn;

    @Column(nullable = false)
    private Instant recibidaEn;

    public PosicionGps(Recorrido recorrido, Coordenada coordenada, Instant capturadaEn, Instant recibidaEn) {
        this.recorrido = recorrido;
        this.coordenada = coordenada;
        this.capturadaEn = capturadaEn;
        this.recibidaEn = recibidaEn;
    }
}
