package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.Recordatorio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface RecordatorioRepository extends JpaRepository<Recordatorio, Long> {

    List<Recordatorio> findByPasajeroIdAndActivoTrueOrderBySalidaProgramada(Long pasajeroId);

    List<Recordatorio> findByRutaIdAndActivoTrueAndSalidaProgramadaAfter(Long rutaId, LocalDateTime desde);

    List<Recordatorio> findByActivoTrueAndNotificadoFalseAndSalidaProgramadaBetween(LocalDateTime desde, LocalDateTime hasta);

    boolean existsByPasajeroIdAndRutaIdAndSalidaProgramadaAndActivoTrue(Long pasajeroId, Long rutaId, LocalDateTime salida);
}
