package edu.unillanos.transporte.presentacion.controlador;

import edu.unillanos.transporte.infraestructura.seguridad.UsuarioAutenticado;
import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.Rol;
import edu.unillanos.transporte.aplicacion.casosdeuso.HorarioService;
import edu.unillanos.transporte.aplicacion.casosdeuso.RutaService;
import edu.unillanos.transporte.aplicacion.casosdeuso.UbicacionService;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.EstadoEnVivo;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.HorariosRuta;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.MapaRuta;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.RutaResumen;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Consultas sobre rutas publicadas, disponibles para cualquier usuario autenticado (CU-01 y CU-02). */
@RestController
@RequestMapping("/api/rutas")
public class RutaConsultaController {

    private final RutaService rutas;
    private final UbicacionService ubicacion;
    private final HorarioService horarios;

    public RutaConsultaController(RutaService rutas, UbicacionService ubicacion, HorarioService horarios) {
        this.rutas = rutas;
        this.ubicacion = ubicacion;
        this.horarios = horarios;
    }

    @GetMapping
    public List<RutaResumen> publicadas(@RequestParam(required = false) Modalidad modalidad) {
        return rutas.listarPublicadas(modalidad);
    }

    @GetMapping("/{id}/mapa")
    public MapaRuta mapa(@PathVariable Long id) {
        return rutas.mapa(id);
    }

    @GetMapping("/{id}/en-vivo")
    public EstadoEnVivo enVivo(@PathVariable Long id, @RequestParam(required = false) Long paradaId) {
        return ubicacion.estadoEnVivo(id, paradaId);
    }

    @GetMapping("/{id}/horarios")
    public HorariosRuta horarios(@PathVariable Long id, @AuthenticationPrincipal UsuarioAutenticado usuario) {
        Long pasajeroId = usuario.rol() == Rol.PASAJERO ? usuario.id() : null;
        return horarios.horarios(id, pasajeroId);
    }
}
