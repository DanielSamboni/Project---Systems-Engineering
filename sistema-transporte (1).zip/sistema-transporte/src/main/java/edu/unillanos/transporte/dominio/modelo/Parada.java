package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "paradas")
@Getter
@Setter
@NoArgsConstructor
public class Parada {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Ruta ruta;

    @Column(nullable = false, length = 80)
    private String nombre;

    @Column(nullable = false)
    private int orden;

    @Embedded
    private Coordenada ubicacion;

    public Parada(String nombre, int orden, double lat, double lng) {
        this.nombre = nombre;
        this.orden = orden;
        this.ubicacion = new Coordenada(lat, lng);
    }
}
