package edu.unillanos.transporte.aplicacion.puerto;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoCarnet;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Puerto hacia el Sistema Académico Institucional (actor secundario de CU-03).
 * La lógica de negocio depende solo de esta interfaz, no de la implementación.
 */
public interface SistemaAcademicoGateway {

    /** Busca por código de carnet o por número de documento. */
    Optional<EstadoPortador> consultar(String identificador) throws SistemaAcademicoNoDisponibleException;

    /** Copia de carnets vigentes que la terminal descarga al iniciar el recorrido (modo contingencia). */
    List<EstadoPortador> carnetsVigentes() throws SistemaAcademicoNoDisponibleException;

    boolean estaDisponible();

    void simularDisponibilidad(boolean disponible);

    record EstadoPortador(String codigo, String documento, String nombre, String vinculo,
                          EstadoCarnet estado, LocalDate vigenteHasta) {
        public boolean activo() {
            return estado == EstadoCarnet.ACTIVO;
        }
    }

    class SistemaAcademicoNoDisponibleException extends Exception {
        public SistemaAcademicoNoDisponibleException() {
            super("El Sistema Académico Institucional no está disponible");
        }
    }
}
