package edu.unillanos.transporte.dominio.modelo;

import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoSalida;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Programación de salidas: FRECUENCIA (franja con intervalo, rutas de Centro)
 * o PUNTUAL (una hora fija, rutas de Barrio).
 */
@Entity
@Table(name = "salidas")
@Getter
@Setter
@NoArgsConstructor
public class Salida {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private Ruta ruta;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private TipoDia tipoDia;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private TipoSalida tipo;

    @Column(nullable = false)
    private LocalTime horaInicio;

    private LocalTime horaFin;

    private Integer frecuenciaMinutos;

    public static Salida puntual(TipoDia dia, LocalTime hora) {
        Salida s = new Salida();
        s.tipoDia = dia;
        s.tipo = TipoSalida.PUNTUAL;
        s.horaInicio = hora;
        return s;
    }

    public static Salida frecuencia(TipoDia dia, LocalTime inicio, LocalTime fin, int minutos) {
        Salida s = new Salida();
        s.tipoDia = dia;
        s.tipo = TipoSalida.FRECUENCIA;
        s.horaInicio = inicio;
        s.horaFin = fin;
        s.frecuenciaMinutos = minutos;
        return s;
    }

    /** Horas concretas de salida que genera esta programación. */
    public List<LocalTime> horasDeSalida() {
        List<LocalTime> horas = new ArrayList<>();
        if (tipo == TipoSalida.PUNTUAL || frecuenciaMinutos == null || frecuenciaMinutos <= 0 || horaFin == null) {
            horas.add(horaInicio);
            return horas;
        }
        for (LocalTime h = horaInicio; !h.isAfter(horaFin); h = h.plusMinutes(frecuenciaMinutos)) {
            horas.add(h);
            if (h.plusMinutes(frecuenciaMinutos).isBefore(h)) {
                break;
            }
        }
        return horas;
    }
}
