package edu.unillanos.transporte.infraestructura.configuracion;

import edu.unillanos.transporte.dominio.modelo.Coordenada;
import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Parada;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

/**
 * Rutas iniciales con trazados que siguen las vías reales de Villavicencio.
 * Generadas a partir de OpenStreetMap (Nominatim + OSRM); ver {@code datos/rutas-iniciales.json}.
 */
@Component
public class CatalogoRutasIniciales {

    private static final String RECURSO = "datos/rutas-iniciales.json";

    private final List<RutaInicial> rutas;

    public CatalogoRutasIniciales(JsonMapper json) {
        try (InputStream in = new ClassPathResource(RECURSO).getInputStream()) {
            this.rutas = List.of(json.readValue(in, RutaInicial[].class));
        } catch (IOException e) {
            throw new UncheckedIOException("No se pudo leer " + RECURSO, e);
        }
    }

    public List<RutaInicial> rutas() {
        return rutas;
    }

    public record ParadaInicial(String nombre, double lat, double lng) {
    }

    public record RutaInicial(String nombre, Modalidad modalidad, String descripcion, int duracionEstimadaMin,
                              List<ParadaInicial> paradas, double[][] trazado) {

        public List<Coordenada> coordenadas() {
            return Arrays.stream(trazado).map(p -> new Coordenada(p[0], p[1])).toList();
        }

        public List<Parada> nuevasParadas() {
            return IntStream.range(0, paradas.size())
                    .mapToObj(i -> new Parada(paradas.get(i).nombre(), i + 1, paradas.get(i).lat(), paradas.get(i).lng()))
                    .toList();
        }
    }
}
