package edu.unillanos.transporte.presentacion.controlador;

import edu.unillanos.transporte.infraestructura.seguridad.UsuarioAutenticado;
import edu.unillanos.transporte.aplicacion.casosdeuso.HorarioService;
import edu.unillanos.transporte.aplicacion.casosdeuso.NotificacionService;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.Bandeja;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.CrearRecordatorioRequest;
import edu.unillanos.transporte.aplicacion.dto.PasajeroDtos.RecordatorioDto;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/pasajero")
public class PasajeroController {

    private final HorarioService horarios;
    private final NotificacionService notificaciones;

    public PasajeroController(HorarioService horarios, NotificacionService notificaciones) {
        this.horarios = horarios;
        this.notificaciones = notificaciones;
    }

    // CU-02: recordatorios

    @GetMapping("/recordatorios")
    public List<RecordatorioDto> recordatorios(@AuthenticationPrincipal UsuarioAutenticado u) {
        return horarios.recordatorios(u.id());
    }

    @PostMapping("/recordatorios")
    @ResponseStatus(HttpStatus.CREATED)
    public RecordatorioDto crearRecordatorio(@AuthenticationPrincipal UsuarioAutenticado u,
                                             @Valid @RequestBody CrearRecordatorioRequest req) {
        return horarios.crearRecordatorio(u.id(), req);
    }

    @DeleteMapping("/recordatorios/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancelarRecordatorio(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id) {
        horarios.cancelarRecordatorio(u.id(), id);
    }

    // Seguimiento de rutas: define quién recibe las novedades push

    @GetMapping("/seguimientos")
    public List<Long> seguimientos(@AuthenticationPrincipal UsuarioAutenticado u) {
        return notificaciones.rutasSeguidas(u.id());
    }

    @PutMapping("/seguimientos/{rutaId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void seguir(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long rutaId) {
        notificaciones.seguir(u.id(), rutaId);
    }

    @DeleteMapping("/seguimientos/{rutaId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void dejarDeSeguir(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long rutaId) {
        notificaciones.dejarDeSeguir(u.id(), rutaId);
    }

    // Bandeja de notificaciones push (simuladas)

    @GetMapping("/notificaciones")
    public Bandeja notificaciones(@AuthenticationPrincipal UsuarioAutenticado u) {
        return notificaciones.bandeja(u.id());
    }

    @PostMapping("/notificaciones/leidas")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void marcarLeidas(@AuthenticationPrincipal UsuarioAutenticado u) {
        notificaciones.marcarLeidas(u.id());
    }
}
