package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Coordenada;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

/** Estima el tiempo de llegada de un bus a una parada (CU-01, pasos 7-8 y flujo 7a). */
public final class CalculadoraEta {

    private static final double TOLERANCIA_METROS = 25;
    private static final double VELOCIDAD_MIN_KMH = 5;
    private static final double VELOCIDAD_MAX_KMH = 80;

    private CalculadoraEta() {
    }

    public record ParadaRef(Long id, String nombre, Coordenada ubicacion) {
    }

    public record Muestra(Coordenada coordenada, Instant capturadaEn) {
    }

    public record Estimacion(Long paradaId, String paradaNombre, double distanciaMetros, int minutos,
                             boolean yaPaso, boolean paradaElegidaPorSistema) {
    }

    /**
     * @param paradaId parada elegida por el pasajero; si es null se usa la primera parada no superada.
     */
    public static Optional<Estimacion> estimar(List<Coordenada> trazado, List<ParadaRef> paradas,
                                               Coordenada bus, Long paradaId, double velocidadKmh) {
        if (trazado.size() < 2 || paradas.isEmpty()) {
            return Optional.empty();
        }
        double progresoBus = Geo.progresoSobreTrazado(trazado, bus);
        double metrosPorMinuto = velocidadKmh * 1000 / 60;

        if (paradaId != null) {
            return paradas.stream().filter(p -> p.id().equals(paradaId)).findFirst().map(p -> {
                double faltante = Geo.progresoSobreTrazado(trazado, p.ubicacion()) - progresoBus;
                if (faltante < -TOLERANCIA_METROS) {
                    return new Estimacion(p.id(), p.nombre(), 0, -1, true, false);
                }
                double distancia = Math.max(0, faltante);
                return new Estimacion(p.id(), p.nombre(), distancia, minutos(distancia, metrosPorMinuto), false, false);
            });
        }

        for (ParadaRef p : paradas) {
            double faltante = Geo.progresoSobreTrazado(trazado, p.ubicacion()) - progresoBus;
            if (faltante > TOLERANCIA_METROS) {
                return Optional.of(new Estimacion(p.id(), p.nombre(), faltante, minutos(faltante, metrosPorMinuto), false, true));
            }
        }
        return Optional.empty();
    }

    /** Velocidad observada a partir de las últimas posiciones; si no es confiable usa la velocidad por defecto. */
    public static double velocidadKmh(List<Muestra> muestrasRecientes, double porDefecto) {
        if (muestrasRecientes.size() < 2) {
            return porDefecto;
        }
        List<Muestra> ordenadas = muestrasRecientes.stream()
                .sorted((a, b) -> a.capturadaEn().compareTo(b.capturadaEn())).toList();
        double metros = 0;
        for (int i = 0; i + 1 < ordenadas.size(); i++) {
            metros += Geo.distanciaMetros(ordenadas.get(i).coordenada(), ordenadas.get(i + 1).coordenada());
        }
        double segundos = Duration.between(ordenadas.getFirst().capturadaEn(), ordenadas.getLast().capturadaEn()).toMillis() / 1000.0;
        if (segundos <= 0) {
            return porDefecto;
        }
        double kmh = metros / segundos * 3.6;
        return (kmh < VELOCIDAD_MIN_KMH || kmh > VELOCIDAD_MAX_KMH) ? porDefecto : kmh;
    }

    private static int minutos(double distancia, double metrosPorMinuto) {
        return (int) Math.ceil(distancia / metrosPorMinuto);
    }
}
