package edu.unillanos.transporte.presentacion.controlador;

import edu.unillanos.transporte.aplicacion.puerto.SistemaAcademicoGateway;
import edu.unillanos.transporte.aplicacion.casosdeuso.AccesoService;
import edu.unillanos.transporte.aplicacion.casosdeuso.AsignacionService;
import edu.unillanos.transporte.aplicacion.casosdeuso.MonitoreoService;
import edu.unillanos.transporte.aplicacion.casosdeuso.ReporteService;
import edu.unillanos.transporte.aplicacion.casosdeuso.RutaService;
import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion.Conflicto;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.*;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.AbordajeDto;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.TurnoDto;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.GuardarRutaRequest;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.ResultadoGuardado;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.RutaDetalle;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.RutaResumen;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.TrazadoSugerido;
import edu.unillanos.transporte.aplicacion.dto.RutaDtos.TrazarPorViasRequest;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Módulo administrativo: CU-05 (RF-12, RF-13, RF-14), revisión de accesos denegados de CU-03 y supervisión
 * del servicio en vivo por la oficina de transporte.
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final RutaService rutas;
    private final AsignacionService asignaciones;
    private final ReporteService reportes;
    private final AccesoService accesos;
    private final SistemaAcademicoGateway sistemaAcademico;
    private final MonitoreoService monitoreo;
    private final Clock reloj;

    public AdminController(RutaService rutas, AsignacionService asignaciones, ReporteService reportes,
                           AccesoService accesos, SistemaAcademicoGateway sistemaAcademico, MonitoreoService monitoreo,
                           Clock reloj) {
        this.monitoreo = monitoreo;
        this.rutas = rutas;
        this.asignaciones = asignaciones;
        this.reportes = reportes;
        this.accesos = accesos;
        this.sistemaAcademico = sistemaAcademico;
        this.reloj = reloj;
    }

    // Rutas, paradas y horarios

    @GetMapping("/rutas")
    public List<RutaResumen> rutas() {
        return rutas.listarTodas();
    }

    @GetMapping("/rutas/{id}")
    public RutaDetalle ruta(@PathVariable Long id) {
        return rutas.detalle(id);
    }

    @PostMapping("/rutas/validar")
    public Map<String, List<Conflicto>> validar(@RequestBody GuardarRutaRequest req, @RequestParam(required = false) Long id) {
        return Map.of("conflictos", rutas.validar(req, id));
    }

    @PostMapping("/rutas/trazar-por-vias")
    public TrazadoSugerido trazarPorVias(@Valid @RequestBody TrazarPorViasRequest req) {
        return rutas.trazarPorVias(req);
    }

    @PostMapping("/rutas")
    @ResponseStatus(HttpStatus.CREATED)
    public ResultadoGuardado crear(@Valid @RequestBody GuardarRutaRequest req) {
        return rutas.crear(req);
    }

    @PutMapping("/rutas/{id}")
    public ResultadoGuardado actualizar(@PathVariable Long id, @Valid @RequestBody GuardarRutaRequest req) {
        return rutas.actualizar(id, req);
    }

    @PatchMapping("/rutas/{id}/activa")
    public RutaResumen cambiarActiva(@PathVariable Long id, @RequestParam boolean valor) {
        return rutas.cambiarActiva(id, valor);
    }

    // Vehículos, conductores y turnos

    @GetMapping("/vehiculos")
    public List<VehiculoDto> vehiculos() {
        return asignaciones.vehiculos();
    }

    @PostMapping("/vehiculos")
    @ResponseStatus(HttpStatus.CREATED)
    public VehiculoDto crearVehiculo(@Valid @RequestBody CrearVehiculoRequest req) {
        return asignaciones.crearVehiculo(req);
    }

    @GetMapping("/conductores")
    public List<UsuarioDto> conductores() {
        return asignaciones.conductores();
    }

    @GetMapping("/turnos")
    public List<TurnoDto> turnos() {
        return asignaciones.turnos();
    }

    @PostMapping("/turnos")
    @ResponseStatus(HttpStatus.CREATED)
    public TurnoDto crearTurno(@Valid @RequestBody CrearTurnoRequest req) {
        return asignaciones.crearTurno(req);
    }

    @PutMapping("/turnos/{id}")
    public TurnoDto actualizarTurno(@PathVariable Long id, @Valid @RequestBody CrearTurnoRequest req) {
        return asignaciones.actualizarTurno(id, req);
    }

    @PutMapping("/vehiculos/{id}")
    public VehiculoDto actualizarVehiculo(@PathVariable Long id, @Valid @RequestBody ActualizarVehiculoRequest req) {
        return asignaciones.actualizarVehiculo(id, req);
    }

    @PostMapping("/conductores")
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioDto crearConductor(@Valid @RequestBody CrearConductorRequest req) {
        return asignaciones.crearConductor(req);
    }

    @PatchMapping("/conductores/{id}/activo")
    public UsuarioDto cambiarConductorActivo(@PathVariable Long id, @RequestParam boolean valor) {
        return asignaciones.cambiarConductorActivo(id, valor);
    }

    // Supervisión del servicio en vivo

    @GetMapping("/monitoreo")
    public EstadoFlota monitoreo() {
        return monitoreo.estadoFlota();
    }

    @PostMapping("/recorridos/{id}/finalizar")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void finalizarRecorrido(@PathVariable Long id) {
        monitoreo.finalizarRecorrido(id);
    }

    @DeleteMapping("/turnos/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminarTurno(@PathVariable Long id) {
        asignaciones.eliminarTurno(id);
    }

    // Reportes de uso

    @GetMapping("/reportes/uso")
    public ReporteUso reporteUso(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate desde,
                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate hasta) {
        LocalDate hoy = LocalDate.now(reloj);
        return reportes.reporteUso(desde != null ? desde : hoy.minusDays(13), hasta != null ? hasta : hoy);
    }

    // Accesos denegados

    @GetMapping("/accesos-denegados")
    public List<AbordajeDto> accesosDenegados() {
        return accesos.denegadosPendientes();
    }

    @PostMapping("/accesos-denegados/{id}/revisado")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void marcarRevisado(@PathVariable Long id) {
        accesos.marcarRevisado(id);
    }

    // Simulación de disponibilidad del Sistema Académico Institucional (para demostrar el modo contingencia)

    @GetMapping("/sistema-academico")
    public EstadoSistemaAcademico estadoSistemaAcademico() {
        return new EstadoSistemaAcademico(sistemaAcademico.estaDisponible());
    }

    @PutMapping("/sistema-academico")
    public EstadoSistemaAcademico cambiarSistemaAcademico(@RequestBody EstadoSistemaAcademico estado) {
        sistemaAcademico.simularDisponibilidad(estado.disponible());
        return new EstadoSistemaAcademico(sistemaAcademico.estaDisponible());
    }
}
