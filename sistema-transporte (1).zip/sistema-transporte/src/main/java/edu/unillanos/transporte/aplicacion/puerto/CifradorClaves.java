package edu.unillanos.transporte.aplicacion.puerto;

/** Puerto para cifrar contraseñas sin que los casos de uso dependan del mecanismo concreto (BCrypt). */
public interface CifradorClaves {

    String cifrar(String claveEnClaro);
}
