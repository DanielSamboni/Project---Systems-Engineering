package edu.unillanos.transporte.aplicacion.casosdeuso;

import edu.unillanos.transporte.dominio.excepcion.NoEncontradoException;
import edu.unillanos.transporte.dominio.excepcion.ReglaNegocioException;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoNovedad;
import edu.unillanos.transporte.dominio.modelo.Novedad;
import edu.unillanos.transporte.dominio.modelo.PosicionGps;
import edu.unillanos.transporte.dominio.modelo.Recorrido;
import edu.unillanos.transporte.dominio.modelo.Turno;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.NovedadRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.PosicionGpsRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.RecorridoRepository;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.TurnoRepository;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.IniciarRecorridoRequest;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.NovedadRequest;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.PosicionRequest;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.RecorridoDto;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.ResultadoNovedad;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.ResultadoPosiciones;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.TurnoDto;
import edu.unillanos.transporte.dominio.modelo.Coordenada;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/** CU-04: iniciar, pausar y finalizar la transmisión (RF-10) y reportar novedades (RF-11). */
@Service
@Transactional
public class RecorridoService {

    private static final List<EstadoRecorrido> ACTIVOS = List.of(EstadoRecorrido.EN_CURSO, EstadoRecorrido.PAUSADO);

    private final RecorridoRepository recorridos;
    private final TurnoRepository turnos;
    private final PosicionGpsRepository posiciones;
    private final NovedadRepository novedades;
    private final NotificacionService notificaciones;
    private final Clock reloj;

    public RecorridoService(RecorridoRepository recorridos, TurnoRepository turnos, PosicionGpsRepository posiciones,
                            NovedadRepository novedades, NotificacionService notificaciones, Clock reloj) {
        this.recorridos = recorridos;
        this.turnos = turnos;
        this.posiciones = posiciones;
        this.novedades = novedades;
        this.notificaciones = notificaciones;
        this.reloj = reloj;
    }

    @Transactional(readOnly = true)
    public List<TurnoDto> turnosDe(Long conductorId) {
        return turnos.findByConductorIdOrderByTipoDiaAscHoraInicioAsc(conductorId).stream().map(TurnoDto::de).toList();
    }

    @Transactional(readOnly = true)
    public Optional<RecorridoDto> actual(Long conductorId) {
        return recorridos.findFirstByConductorIdAndEstadoIn(conductorId, ACTIVOS).map(RecorridoDto::de);
    }

    public RecorridoDto iniciar(Long conductorId, IniciarRecorridoRequest req) {
        if (recorridos.findFirstByConductorIdAndEstadoIn(conductorId, ACTIVOS).isPresent()) {
            throw new ReglaNegocioException("Ya tiene un recorrido en curso. Finalícelo antes de iniciar otro.");
        }
        Turno turno = turnos.findById(req.turnoId())
                .filter(t -> t.getConductor().getId().equals(conductorId))
                .orElseThrow(() -> new ReglaNegocioException("El turno seleccionado no está asignado a este conductor."));
        if (!turno.getRuta().isPublicada() || !turno.getRuta().isActiva()) {
            throw new ReglaNegocioException("La ruta del turno no está publicada o está inactiva.");
        }
        if (recorridos.existsByVehiculoIdAndEstadoIn(turno.getVehiculo().getId(), ACTIVOS)) {
            throw new ReglaNegocioException("El vehículo " + turno.getVehiculo().getPlaca() + " ya tiene un recorrido en curso.");
        }

        // 4a: la ruta ya fue iniciada por otro vehículo.
        List<Recorrido> otros = recorridos.findByRutaIdAndEstadoIn(turno.getRuta().getId(), ACTIVOS);
        if (!otros.isEmpty() && !req.confirmarSegundoVehiculo()) {
            String placas = otros.stream().map(r -> r.getVehiculo().getPlaca()).collect(Collectors.joining(", "));
            throw new ReglaNegocioException("La ruta ya fue iniciada por otro vehículo (" + placas
                    + "). ¿Desea registrar este bus como vehículo adicional de la ruta?",
                    Map.of("requiereConfirmacion", true));
        }

        Recorrido r = new Recorrido();
        r.setRuta(turno.getRuta());
        r.setVehiculo(turno.getVehiculo());
        r.setConductor(turno.getConductor());
        r.setTurno(turno);
        r.setInicio(Instant.now(reloj));
        return RecorridoDto.de(recorridos.save(r));
    }

    public RecorridoDto pausar(Long conductorId, Long id) {
        Recorrido r = propio(conductorId, id);
        exigirEstado(r, EstadoRecorrido.EN_CURSO, "Solo se puede pausar un recorrido en curso.");
        r.setEstado(EstadoRecorrido.PAUSADO);
        return RecorridoDto.de(r);
    }

    public RecorridoDto reanudar(Long conductorId, Long id) {
        Recorrido r = propio(conductorId, id);
        exigirEstado(r, EstadoRecorrido.PAUSADO, "Solo se puede reanudar un recorrido pausado.");
        r.setEstado(EstadoRecorrido.EN_CURSO);
        return RecorridoDto.de(r);
    }

    public RecorridoDto finalizar(Long conductorId, Long id) {
        Recorrido r = propio(conductorId, id);
        if (!r.estaActivo()) {
            throw new ReglaNegocioException("El recorrido ya fue finalizado.");
        }
        r.setEstado(EstadoRecorrido.FINALIZADO);
        r.setFin(Instant.now(reloj));
        return RecorridoDto.de(r);
    }

    /**
     * Recibe una o varias posiciones. Varias llegan juntas cuando la terminal recupera cobertura
     * y reenvía las coordenadas que almacenó localmente (flujo 5a).
     */
    public ResultadoPosiciones registrarPosiciones(Long conductorId, Long id, List<PosicionRequest> lote) {
        Recorrido r = propio(conductorId, id);
        if (!r.getVehiculo().isTieneGps()) {
            throw new ReglaNegocioException("El vehículo " + r.getVehiculo().getPlaca() + " no tiene dispositivo GPS registrado.");
        }
        if (r.getEstado() != EstadoRecorrido.EN_CURSO) {
            throw new ReglaNegocioException("La transmisión está pausada o el recorrido ya finalizó.");
        }
        Instant ahora = Instant.now(reloj);
        int aceptadas = 0;
        List<PosicionRequest> ordenadas = lote.stream()
                .sorted(Comparator.comparing(p -> p.capturadaEn() == null ? ahora : p.capturadaEn()))
                .toList();
        for (PosicionRequest p : ordenadas) {
            Instant capturada = p.capturadaEn() == null || p.capturadaEn().isAfter(ahora) ? ahora : p.capturadaEn();
            if (capturada.isBefore(r.getInicio()) || !coordenadaValida(p.lat(), p.lng())) {
                continue;
            }
            Coordenada c = new Coordenada(p.lat(), p.lng());
            posiciones.save(new PosicionGps(r, c, capturada, ahora));
            if (r.getUltimaPosicionEn() == null || capturada.isAfter(r.getUltimaPosicionEn())) {
                r.setUltimaPosicion(c);
                r.setUltimaPosicionEn(capturada);
            }
            aceptadas++;
        }
        return new ResultadoPosiciones(aceptadas, lote.size() - aceptadas);
    }

    /** Extensión «Reportar Alerta de Novedad»: se difunde a los pasajeros que siguen la ruta. */
    public ResultadoNovedad reportarNovedad(Long conductorId, Long id, NovedadRequest req) {
        Recorrido r = propio(conductorId, id);
        if (!r.estaActivo()) {
            throw new ReglaNegocioException("Solo se pueden reportar novedades durante un recorrido activo.");
        }
        Novedad n = new Novedad();
        n.setRecorrido(r);
        n.setTipo(req.tipo());
        n.setDetalle(req.detalle() == null || req.detalle().isBlank() ? null : req.detalle().trim());
        n.setReportadaEn(Instant.now(reloj));

        String mensaje = descripcion(req.tipo()) + " reportado por el bus " + r.getVehiculo().getPlaca()
                + (n.getDetalle() == null ? "." : ": " + n.getDetalle());
        int notificados = notificaciones.notificar(notificaciones.interesadosEnRuta(r.getRuta().getId()), "NOVEDAD",
                "Novedad en " + r.getRuta().getNombre(), mensaje);
        n.setPasajerosNotificados(notificados);
        return new ResultadoNovedad(novedades.save(n).getId(), notificados);
    }

    Recorrido propio(Long conductorId, Long id) {
        return recorridos.findById(id)
                .filter(r -> r.getConductor().getId().equals(conductorId))
                .orElseThrow(() -> new NoEncontradoException("Recorrido", id));
    }

    private static void exigirEstado(Recorrido r, EstadoRecorrido esperado, String mensaje) {
        if (r.getEstado() != esperado) {
            throw new ReglaNegocioException(mensaje);
        }
    }

    private static boolean coordenadaValida(double lat, double lng) {
        return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
    }

    private static String descripcion(TipoNovedad tipo) {
        return switch (tipo) {
            case RETRASO -> "Retraso";
            case CONGESTION -> "Congestión vial";
            case ACCIDENTE -> "Accidente";
            case VARADA -> "Vehículo varado";
        };
    }
}
