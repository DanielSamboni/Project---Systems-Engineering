package edu.unillanos.transporte.presentacion.controlador;

import edu.unillanos.transporte.infraestructura.seguridad.UsuarioAutenticado;
import edu.unillanos.transporte.aplicacion.dto.AdminDtos.UsuarioDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** «include» Iniciar Sesión. El POST de login y el logout los atiende Spring Security (ver SecurityConfig). */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @GetMapping("/yo")
    public ResponseEntity<UsuarioDto> yo(@AuthenticationPrincipal UsuarioAutenticado usuario) {
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        return ResponseEntity.ok(new UsuarioDto(usuario.id(), usuario.username(), usuario.nombre(), usuario.rol(), null, usuario.activo()));
    }
}
