package edu.unillanos.transporte.dominio.modelo;

import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalTime;

@Entity
@Table(name = "turnos")
@Getter
@Setter
@NoArgsConstructor
public class Turno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Ruta ruta;

    @ManyToOne(optional = false)
    private Usuario conductor;

    @ManyToOne(optional = false)
    private Vehiculo vehiculo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private TipoDia tipoDia;

    @Column(nullable = false)
    private LocalTime horaInicio;

    @Column(nullable = false)
    private LocalTime horaFin;

    public Turno(Ruta ruta, Usuario conductor, Vehiculo vehiculo, TipoDia tipoDia, LocalTime horaInicio, LocalTime horaFin) {
        this.ruta = ruta;
        this.conductor = conductor;
        this.vehiculo = vehiculo;
        this.tipoDia = tipoDia;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    public boolean seSolapaCon(Turno otro) {
        return tipoDia == otro.tipoDia
                && horaInicio.isBefore(otro.horaFin)
                && otro.horaInicio.isBefore(horaFin);
    }
}
