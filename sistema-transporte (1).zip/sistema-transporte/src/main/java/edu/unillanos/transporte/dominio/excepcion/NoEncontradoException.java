package edu.unillanos.transporte.dominio.excepcion;

public class NoEncontradoException extends RuntimeException {

    public NoEncontradoException(String recurso, Object id) {
        super("No se encontró " + recurso.toLowerCase() + " con identificador " + id + ".");
    }
}
