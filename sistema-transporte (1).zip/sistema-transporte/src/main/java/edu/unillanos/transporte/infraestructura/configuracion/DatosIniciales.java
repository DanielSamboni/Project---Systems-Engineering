package edu.unillanos.transporte.infraestructura.configuracion;

import edu.unillanos.transporte.dominio.modelo.*;
import edu.unillanos.transporte.dominio.modelo.Enums.*;
import edu.unillanos.transporte.infraestructura.academico.CarnetInstitucional;
import edu.unillanos.transporte.infraestructura.academico.CarnetInstitucionalRepository;
import edu.unillanos.transporte.infraestructura.configuracion.CatalogoRutasIniciales.RutaInicial;
import edu.unillanos.transporte.aplicacion.puerto.persistencia.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Carga datos de demostración la primera vez que arranca el sistema (base de datos vacía).
 * Las rutas y paradas vienen de {@link CatalogoRutasIniciales}. Las credenciales de prueba están en el README.
 */
@Component
public class DatosIniciales implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DatosIniciales.class);
    private static final String CLAVE_DEMO = "unillanos2026";
    private static final int MAX_PUNTOS_TRAZADO_ANTIGUO = 10;

    private final UsuarioRepository usuarios;
    private final VehiculoRepository vehiculos;
    private final RutaRepository rutas;
    private final TurnoRepository turnos;
    private final AbordajeRepository abordajes;
    private final SeguimientoRutaRepository seguimientos;
    private final CarnetInstitucionalRepository carnets;
    private final PasswordEncoder encoder;
    private final Clock reloj;
    private final CatalogoRutasIniciales catalogo;

    public DatosIniciales(UsuarioRepository usuarios, VehiculoRepository vehiculos, RutaRepository rutas,
                          TurnoRepository turnos, AbordajeRepository abordajes, SeguimientoRutaRepository seguimientos,
                          CarnetInstitucionalRepository carnets, PasswordEncoder encoder, Clock reloj,
                          CatalogoRutasIniciales catalogo) {
        this.catalogo = catalogo;
        this.usuarios = usuarios;
        this.vehiculos = vehiculos;
        this.rutas = rutas;
        this.turnos = turnos;
        this.abordajes = abordajes;
        this.seguimientos = seguimientos;
        this.carnets = carnets;
        this.encoder = encoder;
        this.reloj = reloj;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (usuarios.count() > 0) {
            actualizarTrazadosAntiguos();
            return;
        }
        log.info("Base de datos vacía: cargando datos de demostración");
        LocalDate hoy = LocalDate.now(reloj);

        cargarCarnets(hoy);

        Usuario admin = usuario("admin", "Oficina de Transporte - Bienestar", Rol.ADMINISTRADOR, null, null);
        Usuario c1 = usuario("conductor1", "Carlos Rojas", Rol.CONDUCTOR, "86000001", null);
        Usuario c2 = usuario("conductor2", "Luis Pérez", Rol.CONDUCTOR, "86000002", null);
        Usuario c3 = usuario("conductor3", "Andrea Gómez", Rol.CONDUCTOR, "86000003", null);
        Usuario e1 = usuario("estudiante1", "Ana María López", Rol.PASAJERO, "1121000001", "160001001");
        usuario("estudiante2", "Jorge Castro", Rol.PASAJERO, "1121000002", "160001002");
        usuario("docente1", "Marta Ruiz", Rol.PASAJERO, "40100001", "900002001");

        Vehiculo v1 = vehiculos.save(new Vehiculo("WTK101", "Bus 40 pasajeros", true));
        Vehiculo v2 = vehiculos.save(new Vehiculo("WTK102", "Buseta 30 pasajeros", true));
        Vehiculo v3 = vehiculos.save(new Vehiculo("WTK103", "Bus 40 pasajeros", true));
        Vehiculo v4 = vehiculos.save(new Vehiculo("WTK104", "Buseta 30 pasajeros (GPS pendiente)", false));
        vehiculos.save(new Vehiculo("WTK105", "Buseta 30 pasajeros", true));
        vehiculos.save(new Vehiculo("WTK106", "Bus 40 pasajeros", true));

        List<Ruta> todas = new ArrayList<>();
        List<RutaInicial> iniciales = catalogo.rutas();
        for (int i = 0; i < iniciales.size(); i++) {
            todas.add(rutas.save(crearRuta(iniciales.get(i), i - 1)));
        }
        Ruta centro = todas.getFirst();
        List<Ruta> barrios = todas.subList(1, todas.size());

        turnos.save(new Turno(centro, c1, v1, TipoDia.HABIL, LocalTime.of(5, 30), LocalTime.of(13, 30)));
        turnos.save(new Turno(centro, c1, v1, TipoDia.SABADO, LocalTime.of(5, 0), LocalTime.of(12, 0)));
        turnos.save(new Turno(centro, c2, v3, TipoDia.SABADO, LocalTime.of(12, 0), LocalTime.of(18, 0)));
        turnos.save(new Turno(barrios.get(0), c2, v2, TipoDia.HABIL, LocalTime.of(5, 0), LocalTime.of(19, 0)));
        turnos.save(new Turno(barrios.get(4), c3, v4, TipoDia.HABIL, LocalTime.of(5, 0), LocalTime.of(19, 0)));
        turnos.save(new Turno(centro, c1, v1, TipoDia.HABIL, LocalTime.of(13, 30), LocalTime.of(19, 0)));

        seguimientos.save(new SeguimientoRuta(e1, centro));
        seguimientos.save(new SeguimientoRuta(e1, barrios.get(0)));

        cargarHistoricoAbordajes(hoy, todas, List.of(v1, v2, v3, v4));
        log.info("Datos de demostración cargados ({} usuarios, {} rutas). Administrador: {}", usuarios.count(), rutas.count(), admin.getUsername());
    }

    private Usuario usuario(String username, String nombre, Rol rol, String documento, String carnet) {
        Usuario u = new Usuario(username, encoder.encode(CLAVE_DEMO), nombre, rol);
        u.setDocumento(documento);
        u.setCodigoCarnet(carnet);
        return usuarios.save(u);
    }

    private void cargarCarnets(LocalDate hoy) {
        LocalDate finSemestre = hoy.plusMonths(3);
        carnets.save(new CarnetInstitucional("160001001", "1121000001", "Ana María López", "Estudiante", EstadoCarnet.ACTIVO, finSemestre));
        carnets.save(new CarnetInstitucional("160001002", "1121000002", "Jorge Castro", "Estudiante", EstadoCarnet.ACTIVO, finSemestre));
        carnets.save(new CarnetInstitucional("160001003", "1121000003", "Laura Méndez", "Estudiante", EstadoCarnet.ACTIVO, hoy.minusMonths(2)));
        carnets.save(new CarnetInstitucional("160001004", "1121000004", "Pedro Salazar", "Estudiante", EstadoCarnet.INACTIVO, finSemestre));
        carnets.save(new CarnetInstitucional("900002001", "40100001", "Marta Ruiz", "Docente", EstadoCarnet.ACTIVO, hoy.plusYears(1)));
        carnets.save(new CarnetInstitucional("900003001", "40100002", "Diego Hernández", "Administrativo", EstadoCarnet.ACTIVO, hoy.plusYears(1)));
        String[] nombres = {"Valentina", "Santiago", "Camila", "Mateo", "Daniela", "Sebastián", "Mariana", "Nicolás",
                "Sofía", "Samuel", "Isabella", "Alejandro", "Gabriela", "Tomás", "Paula", "Juan Esteban"};
        String[] apellidos = {"Rodríguez", "Martínez", "García", "Torres", "Ramírez", "Vargas", "Moreno", "Jiménez"};
        for (int i = 0; i < nombres.length; i++) {
            carnets.save(new CarnetInstitucional("1600020" + String.format("%02d", i), "11220000" + String.format("%02d", i),
                    nombres[i] + " " + apellidos[i % apellidos.length], "Estudiante", EstadoCarnet.ACTIVO, finSemestre));
        }
    }

    private Ruta crearRuta(RutaInicial inicial, int indice) {
        String descripcion = inicial.descripcion() != null ? inicial.descripcion()
                : "Ruta de Barrio hacia los sectores " + inicial.nombre().replace(" – ", " y ") + ".";
        Ruta r = new Ruta(inicial.nombre(), inicial.modalidad(), descripcion);
        aplicarTrazado(r, inicial);
        r.reemplazarSalidas(inicial.modalidad() == Modalidad.CENTRO ? salidasCentro() : salidasBarrio(indice));
        publicar(r);
        return r;
    }

    private static void aplicarTrazado(Ruta r, RutaInicial inicial) {
        r.setDuracionEstimadaMin(inicial.duracionEstimadaMin());
        r.getTrazado().clear();
        r.getTrazado().addAll(inicial.coordenadas());
        r.reemplazarParadas(inicial.nuevasParadas());
    }

    /**
     * Las primeras versiones del sistema guardaron trazados aproximados (rectas entre 4 u 8 puntos).
     * Si la base de datos ya existía, se reemplazan por los trazados que siguen las vías reales.
     */
    private void actualizarTrazadosAntiguos() {
        int actualizadas = 0;
        for (RutaInicial inicial : catalogo.rutas()) {
            Ruta ruta = rutas.findByNombreIgnoreCase(inicial.nombre()).orElse(null);
            if (ruta != null && ruta.getTrazado().size() <= MAX_PUNTOS_TRAZADO_ANTIGUO) {
                aplicarTrazado(ruta, inicial);
                actualizadas++;
            }
        }
        if (actualizadas > 0) {
            log.info("Se actualizaron {} rutas con trazados sobre las vías reales", actualizadas);
        }
    }

    private static List<Salida> salidasCentro() {
        return List.of(
                Salida.frecuencia(TipoDia.HABIL, LocalTime.of(6, 0), LocalTime.of(18, 40), 20),
                Salida.frecuencia(TipoDia.SABADO, LocalTime.of(5, 20), LocalTime.of(7, 40), 20),
                Salida.frecuencia(TipoDia.SABADO, LocalTime.of(8, 0), LocalTime.of(17, 30), 30));
    }

    private static List<Salida> salidasBarrio(int indice) {
        int desfase = (indice % 4) * 5;
        List<Salida> salidas = new ArrayList<>();
        for (LocalTime base : List.of(LocalTime.of(5, 20), LocalTime.of(6, 20), LocalTime.of(7, 0),
                LocalTime.of(11, 0), LocalTime.of(12, 15), LocalTime.of(13, 15),
                LocalTime.of(17, 0), LocalTime.of(17, 35), LocalTime.of(18, 5))) {
            salidas.add(Salida.puntual(TipoDia.HABIL, base.plusMinutes(desfase)));
        }
        salidas.add(Salida.puntual(TipoDia.SABADO, LocalTime.of(5, 40).plusMinutes(desfase)));
        salidas.add(Salida.puntual(TipoDia.SABADO, LocalTime.of(12, 0).plusMinutes(desfase)));
        return salidas;
    }

    private void publicar(Ruta r) {
        LocalDateTime hace30Dias = LocalDateTime.now(reloj).minusDays(30);
        r.setPublicada(true);
        r.setUltimaPublicacion(hace30Dias);
        r.setVigenteDesde(hace30Dias);
    }

    /** Histórico sintético de dos semanas para que los reportes de uso (RF-14) tengan datos. */
    private void cargarHistoricoAbordajes(LocalDate hoy, List<Ruta> rutasDemo, List<Vehiculo> flota) {
        Random azar = new Random(2026);
        List<CarnetInstitucional> activos = carnets.findAll().stream()
                .filter(c -> c.getEstado() == EstadoCarnet.ACTIVO && c.getVigenteHasta().isAfter(hoy)).toList();
        List<Abordaje> lote = new ArrayList<>();
        for (int d = 14; d >= 1; d--) {
            LocalDate fecha = hoy.minusDays(d);
            if (fecha.getDayOfWeek() == DayOfWeek.SUNDAY) {
                continue;
            }
            boolean sabado = fecha.getDayOfWeek() == DayOfWeek.SATURDAY;
            for (Ruta ruta : rutasDemo) {
                int base = ruta.getModalidad() == Modalidad.CENTRO ? 90 : 25;
                int cantidad = (int) ((sabado ? base * 0.4 : base) * (0.8 + azar.nextDouble() * 0.4));
                for (int k = 0; k < cantidad; k++) {
                    int hora = horaPico(azar, ruta.getModalidad());
                    LocalDateTime fh = fecha.atTime(hora, azar.nextInt(60));
                    boolean denegado = azar.nextDouble() < 0.03;
                    CarnetInstitucional portador = activos.get(azar.nextInt(activos.size()));
                    Abordaje a = new Abordaje();
                    a.setRuta(ruta);
                    a.setVehiculo(flota.get(azar.nextInt(flota.size())));
                    a.setFechaHora(fh);
                    a.setMetodo(azar.nextDouble() < 0.05 ? MetodoLectura.MANUAL
                            : (azar.nextBoolean() ? MetodoLectura.QR : MetodoLectura.NFC));
                    a.setModo(azar.nextDouble() < 0.02 ? ModoValidacion.CONTINGENCIA : ModoValidacion.EN_LINEA);
                    if (denegado) {
                        a.setIdentificadorLeido(azar.nextBoolean() ? "160001003" : "160001004");
                        a.setNombrePortador(a.getIdentificadorLeido().endsWith("3") ? "Laura Méndez" : "Pedro Salazar");
                        a.setResultado(ResultadoAcceso.DENEGADO);
                        a.setMotivo(a.getIdentificadorLeido().endsWith("3") ? "Carnet vencido" : "Carnet inactivo");
                        a.setRevisado(d > 3);
                    } else {
                        a.setIdentificadorLeido(portador.getCodigo());
                        a.setNombrePortador(portador.getNombre());
                        a.setResultado(ResultadoAcceso.APROBADO);
                    }
                    lote.add(a);
                }
            }
        }
        abordajes.saveAll(lote);
    }

    private static int horaPico(Random azar, Modalidad modalidad) {
        double p = azar.nextDouble();
        if (modalidad == Modalidad.BARRIO) {
            return p < 0.5 ? 5 + azar.nextInt(3) : p < 0.75 ? 11 + azar.nextInt(3) : 17 + azar.nextInt(2);
        }
        return p < 0.35 ? 6 + azar.nextInt(2) : p < 0.55 ? 12 + azar.nextInt(2) : p < 0.8 ? 17 + azar.nextInt(2) : 8 + azar.nextInt(9);
    }
}
