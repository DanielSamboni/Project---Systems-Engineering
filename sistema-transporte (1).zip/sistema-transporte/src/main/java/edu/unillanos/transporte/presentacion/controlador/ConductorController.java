package edu.unillanos.transporte.presentacion.controlador;

import edu.unillanos.transporte.infraestructura.seguridad.UsuarioAutenticado;
import edu.unillanos.transporte.aplicacion.casosdeuso.AccesoService;
import edu.unillanos.transporte.aplicacion.casosdeuso.RecorridoService;
import edu.unillanos.transporte.aplicacion.dto.ConductorDtos.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/** Terminal del conductor a bordo: CU-04 y la parte del conductor en CU-03. */
@RestController
@RequestMapping("/api/conductor")
public class ConductorController {

    private final RecorridoService recorridos;
    private final AccesoService accesos;

    public ConductorController(RecorridoService recorridos, AccesoService accesos) {
        this.recorridos = recorridos;
        this.accesos = accesos;
    }

    @GetMapping("/turnos")
    public List<TurnoDto> turnos(@AuthenticationPrincipal UsuarioAutenticado u) {
        return recorridos.turnosDe(u.id());
    }

    @GetMapping("/recorrido-actual")
    public ResponseEntity<RecorridoDto> actual(@AuthenticationPrincipal UsuarioAutenticado u) {
        return recorridos.actual(u.id()).map(ResponseEntity::ok).orElse(ResponseEntity.noContent().build());
    }

    @PostMapping("/recorridos")
    @ResponseStatus(HttpStatus.CREATED)
    public RecorridoDto iniciar(@AuthenticationPrincipal UsuarioAutenticado u, @Valid @RequestBody IniciarRecorridoRequest req) {
        return recorridos.iniciar(u.id(), req);
    }

    @PostMapping("/recorridos/{id}/pausar")
    public RecorridoDto pausar(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id) {
        return recorridos.pausar(u.id(), id);
    }

    @PostMapping("/recorridos/{id}/reanudar")
    public RecorridoDto reanudar(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id) {
        return recorridos.reanudar(u.id(), id);
    }

    @PostMapping("/recorridos/{id}/finalizar")
    public RecorridoDto finalizar(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id) {
        return recorridos.finalizar(u.id(), id);
    }

    @PostMapping("/recorridos/{id}/posiciones")
    public ResultadoPosiciones posiciones(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id,
                                          @RequestBody @Size(min = 1, max = 2000) List<@Valid PosicionRequest> lote) {
        return recorridos.registrarPosiciones(u.id(), id, lote);
    }

    @PostMapping("/recorridos/{id}/novedades")
    @ResponseStatus(HttpStatus.CREATED)
    public ResultadoNovedad novedad(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id,
                                    @Valid @RequestBody NovedadRequest req) {
        return recorridos.reportarNovedad(u.id(), id, req);
    }

    // CU-03

    @PostMapping("/recorridos/{id}/validaciones")
    public ResultadoValidacion validar(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id,
                                       @Valid @RequestBody ValidarAccesoRequest req) {
        return accesos.validar(u.id(), id, req);
    }

    @GetMapping("/recorridos/{id}/carnets-vigentes")
    public List<CarnetVigenteDto> carnetsVigentes(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id) {
        return accesos.carnetsVigentes(u.id(), id);
    }

    @PostMapping("/recorridos/{id}/validaciones/sincronizar")
    public Map<String, Integer> sincronizar(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id,
                                            @RequestBody @Size(max = 2000) List<@Valid AbordajeOfflineRequest> lote) {
        return Map.of("sincronizados", accesos.sincronizar(u.id(), id, lote));
    }

    @GetMapping("/recorridos/{id}/abordajes")
    public List<AbordajeDto> abordajes(@AuthenticationPrincipal UsuarioAutenticado u, @PathVariable Long id) {
        return accesos.recientes(u.id(), id);
    }
}
