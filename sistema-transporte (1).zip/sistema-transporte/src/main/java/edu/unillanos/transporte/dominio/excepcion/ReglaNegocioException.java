package edu.unillanos.transporte.dominio.excepcion;

import edu.unillanos.transporte.dominio.reglas.ValidadorProgramacion.Conflicto;
import lombok.Getter;

import java.util.List;
import java.util.Map;

@Getter
public class ReglaNegocioException extends RuntimeException {

    private final List<Conflicto> conflictos;
    private final Map<String, Object> datos;

    public ReglaNegocioException(String mensaje) {
        this(mensaje, List.of(), Map.of());
    }

    public ReglaNegocioException(String mensaje, List<Conflicto> conflictos) {
        this(mensaje, conflictos, Map.of());
    }

    public ReglaNegocioException(String mensaje, Map<String, Object> datos) {
        this(mensaje, List.of(), datos);
    }

    private ReglaNegocioException(String mensaje, List<Conflicto> conflictos, Map<String, Object> datos) {
        super(mensaje);
        this.conflictos = conflictos;
        this.datos = datos;
    }
}
