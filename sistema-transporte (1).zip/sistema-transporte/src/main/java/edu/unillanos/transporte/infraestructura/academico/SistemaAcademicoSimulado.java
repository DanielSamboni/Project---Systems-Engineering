package edu.unillanos.transporte.infraestructura.academico;

import edu.unillanos.transporte.aplicacion.puerto.SistemaAcademicoGateway;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoCarnet;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;

@Component
public class SistemaAcademicoSimulado implements SistemaAcademicoGateway {

    private final CarnetInstitucionalRepository repositorio;
    private final Clock reloj;
    private final AtomicBoolean disponible = new AtomicBoolean(true);

    public SistemaAcademicoSimulado(CarnetInstitucionalRepository repositorio, Clock reloj) {
        this.repositorio = repositorio;
        this.reloj = reloj;
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EstadoPortador> consultar(String identificador) throws SistemaAcademicoNoDisponibleException {
        verificarDisponible();
        String id = identificador.trim();
        return repositorio.findById(id)
                .or(() -> repositorio.findByDocumento(id))
                .map(this::aEstado);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadoPortador> carnetsVigentes() throws SistemaAcademicoNoDisponibleException {
        verificarDisponible();
        return repositorio.findAll().stream().map(this::aEstado).filter(EstadoPortador::activo).toList();
    }

    @Override
    public boolean estaDisponible() {
        return disponible.get();
    }

    @Override
    public void simularDisponibilidad(boolean valor) {
        disponible.set(valor);
    }

    private void verificarDisponible() throws SistemaAcademicoNoDisponibleException {
        if (!disponible.get()) {
            throw new SistemaAcademicoNoDisponibleException();
        }
    }

    private EstadoPortador aEstado(CarnetInstitucional c) {
        EstadoCarnet estado = c.getEstado();
        if (estado == EstadoCarnet.ACTIVO && c.getVigenteHasta() != null
                && c.getVigenteHasta().isBefore(LocalDate.now(reloj))) {
            estado = EstadoCarnet.VENCIDO;
        }
        return new EstadoPortador(c.getCodigo(), c.getDocumento(), c.getNombre(), c.getVinculo(), estado, c.getVigenteHasta());
    }
}
