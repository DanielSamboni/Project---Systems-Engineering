package edu.unillanos.transporte.dominio.modelo;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/** Bandeja de notificaciones del pasajero; simula la entrega push. */
@Entity
@Table(name = "notificaciones", indexes = @Index(columnList = "usuario_id, creadaEn"))
@Getter
@Setter
@NoArgsConstructor
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Usuario usuario;

    @Column(nullable = false, length = 20)
    private String categoria;

    @Column(nullable = false, length = 120)
    private String titulo;

    @Column(nullable = false, length = 300)
    private String mensaje;

    @Column(nullable = false)
    private Instant creadaEn;

    private boolean leida = false;

    public Notificacion(Usuario usuario, String categoria, String titulo, String mensaje, Instant creadaEn) {
        this.usuario = usuario;
        this.categoria = categoria;
        this.titulo = titulo;
        this.mensaje = mensaje;
        this.creadaEn = creadaEn;
    }
}
