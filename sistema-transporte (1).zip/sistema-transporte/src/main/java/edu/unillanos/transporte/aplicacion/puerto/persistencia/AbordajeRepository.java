package edu.unillanos.transporte.aplicacion.puerto.persistencia;

import edu.unillanos.transporte.dominio.modelo.Abordaje;
import edu.unillanos.transporte.dominio.modelo.Enums.ResultadoAcceso;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface AbordajeRepository extends JpaRepository<Abordaje, Long> {

    List<Abordaje> findByFechaHoraBetween(LocalDateTime desde, LocalDateTime hasta);

    List<Abordaje> findByResultadoAndRevisadoFalseOrderByFechaHoraDesc(ResultadoAcceso resultado);

    List<Abordaje> findTop20ByRecorridoIdOrderByFechaHoraDesc(Long recorridoId);

    long countByFechaHoraBetween(LocalDateTime desde, LocalDateTime hasta);

    long countByRecorridoId(Long recorridoId);
}
