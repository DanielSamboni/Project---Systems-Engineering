package edu.unillanos.transporte.dominio.modelo;

import edu.unillanos.transporte.dominio.modelo.Enums.EstadoRecorrido;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/** Trayecto que un conductor realiza con un vehículo sobre una ruta (CU-04). */
@Entity
@Table(name = "recorridos")
@Getter
@Setter
@NoArgsConstructor
public class Recorrido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private Ruta ruta;

    @ManyToOne(optional = false)
    private Vehiculo vehiculo;

    @ManyToOne(optional = false)
    private Usuario conductor;

    @ManyToOne
    private Turno turno;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private EstadoRecorrido estado = EstadoRecorrido.EN_CURSO;

    @Column(nullable = false)
    private Instant inicio;

    private Instant fin;

    @AttributeOverrides({
            @AttributeOverride(name = "lat", column = @Column(name = "ultima_lat")),
            @AttributeOverride(name = "lng", column = @Column(name = "ultima_lng"))
    })
    @Embedded
    private Coordenada ultimaPosicion;

    private Instant ultimaPosicionEn;

    public boolean estaActivo() {
        return estado != EstadoRecorrido.FINALIZADO;
    }
}
