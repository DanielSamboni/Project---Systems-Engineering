package edu.unillanos.transporte.dominio.reglas;

import edu.unillanos.transporte.dominio.modelo.Enums.Modalidad;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoDia;
import edu.unillanos.transporte.dominio.modelo.Enums.TipoSalida;
import edu.unillanos.transporte.dominio.modelo.Salida;
import edu.unillanos.transporte.dominio.modelo.Turno;

import java.util.ArrayList;
import java.util.List;

/** Validaciones de completitud y solapamiento antes de publicar (CU-05, paso 8 y flujo 8a). */
public final class ValidadorProgramacion {

    private ValidadorProgramacion() {
    }

    public record Conflicto(String campo, String mensaje) {
    }

    public static List<Conflicto> validarRuta(String nombre, Modalidad modalidad, int cantidadParadas,
                                              int puntosTrazado, List<Salida> salidas) {
        List<Conflicto> conflictos = new ArrayList<>();
        if (nombre == null || nombre.isBlank()) {
            conflictos.add(new Conflicto("nombre", "La ruta debe tener un nombre."));
        }
        if (modalidad == null) {
            conflictos.add(new Conflicto("modalidad", "Seleccione la modalidad (Centro o Barrio)."));
        }
        if (cantidadParadas < 2) {
            conflictos.add(new Conflicto("paradas", "La ruta debe tener al menos dos paradas."));
        }
        if (puntosTrazado < 2) {
            conflictos.add(new Conflicto("trazado", "El trazado debe tener al menos dos puntos."));
        }
        if (salidas.isEmpty()) {
            conflictos.add(new Conflicto("salidas", "Defina al menos una salida."));
        }

        for (int i = 0; i < salidas.size(); i++) {
            Salida s = salidas.get(i);
            String campo = "salidas[" + i + "]";
            if (s.getTipoDia() == null || s.getHoraInicio() == null || s.getTipo() == null) {
                conflictos.add(new Conflicto(campo, "La salida está incompleta (día, tipo y hora son obligatorios)."));
                continue;
            }
            if (modalidad == Modalidad.CENTRO && s.getTipo() != TipoSalida.FRECUENCIA) {
                conflictos.add(new Conflicto(campo, "Las rutas de Centro se programan por frecuencia y franja."));
            }
            if (modalidad == Modalidad.BARRIO && s.getTipo() != TipoSalida.PUNTUAL) {
                conflictos.add(new Conflicto(campo, "Las rutas de Barrio se programan con horarios puntuales."));
            }
            if (s.getTipo() == TipoSalida.FRECUENCIA) {
                if (s.getHoraFin() == null || !s.getHoraFin().isAfter(s.getHoraInicio())) {
                    conflictos.add(new Conflicto(campo, "La hora de fin de la franja debe ser posterior a la de inicio."));
                }
                if (s.getFrecuenciaMinutos() == null || s.getFrecuenciaMinutos() < 1) {
                    conflictos.add(new Conflicto(campo, "La frecuencia debe ser de al menos un minuto."));
                }
            }
        }

        for (int i = 0; i < salidas.size(); i++) {
            for (int j = i + 1; j < salidas.size(); j++) {
                Salida a = salidas.get(i);
                Salida b = salidas.get(j);
                if (seSolapan(a, b)) {
                    conflictos.add(new Conflicto("salidas[" + j + "]",
                            "Se solapa con la salida " + (i + 1) + " del mismo tipo de día."));
                }
            }
        }
        return conflictos;
    }

    public static List<Conflicto> validarTurno(Turno nuevo, List<Turno> existentes) {
        List<Conflicto> conflictos = new ArrayList<>();
        if (!nuevo.getHoraFin().isAfter(nuevo.getHoraInicio())) {
            conflictos.add(new Conflicto("horaFin", "La hora de fin del turno debe ser posterior a la de inicio."));
            return conflictos;
        }
        for (Turno t : existentes) {
            if (t.getId() != null && t.getId().equals(nuevo.getId()) || !t.seSolapaCon(nuevo)) {
                continue;
            }
            String franja = (t.getTipoDia() == TipoDia.SABADO ? "los sábados" : "los días hábiles")
                    + " de " + t.getHoraInicio() + " a " + t.getHoraFin();
            if (t.getConductor().getId().equals(nuevo.getConductor().getId())) {
                conflictos.add(new Conflicto("conductor", "El conductor ya tiene un turno " + franja
                        + " (" + t.getRuta().getNombre() + ")."));
            }
            if (t.getVehiculo().getId().equals(nuevo.getVehiculo().getId())) {
                conflictos.add(new Conflicto("vehiculo", "El vehículo " + t.getVehiculo().getPlaca()
                        + " ya está asignado " + franja + " (" + t.getRuta().getNombre() + ")."));
            }
        }
        return conflictos;
    }

    private static boolean seSolapan(Salida a, Salida b) {
        if (a.getTipoDia() == null || a.getTipoDia() != b.getTipoDia()
                || a.getHoraInicio() == null || b.getHoraInicio() == null) {
            return false;
        }
        if (a.getTipo() == TipoSalida.PUNTUAL && b.getTipo() == TipoSalida.PUNTUAL) {
            return a.getHoraInicio().equals(b.getHoraInicio());
        }
        var finA = a.getHoraFin() != null ? a.getHoraFin() : a.getHoraInicio();
        var finB = b.getHoraFin() != null ? b.getHoraFin() : b.getHoraInicio();
        return !a.getHoraInicio().isAfter(finB) && !b.getHoraInicio().isAfter(finA);
    }
}
