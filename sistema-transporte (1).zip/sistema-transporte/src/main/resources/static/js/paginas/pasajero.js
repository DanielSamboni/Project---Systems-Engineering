'use strict';

/* Aplicación del pasajero: CU-01 (mapa en vivo), CU-02 (horarios) y bandeja de avisos. */

const REFRESCO_MAPA_MS = 5000;
const REFRESCO_AVISOS_MS = 10000;

const estado = {
  modalidad: 'CENTRO',
  rutas: [],
  rutaId: null,
  seguidas: [],
  vista: 'mapa',
  paradaId: null,
  mapaRuta: null,
  capas: null,
  capaParadas: null,
  marcadoresBus: new Map(),
  ultimoEnVivo: null,
  temporizadorMapa: null,
  generacionMapa: 0,
  ciclosMapa: 0,
  horarios: null,
  fechaElegidaPorUsuario: false,
  avisosVistos: new Set(),
  primeraCargaAvisos: true,
  bandeja: null,
};

let mapa;
const esMovil = () => window.matchMedia('(max-width: 760px)').matches;

document.addEventListener('DOMContentLoaded', async () => {
  try {
    await Sesion.requerir('PASAJERO');
  } catch (e) {
    return;
  }
  mapa = Mapa.crear('mapa');
  $('hueco-selector-mapa').appendChild($('selector-ruta'));
  $('fecha').value = UI.hoyISO();
  conectarEventos();

  estado.seguidas = await API.get('/api/pasajero/seguimientos');
  // Se abre directamente la ruta más útil (RNF-07: mínimo de toques):
  // una ruta seguida con bus en servicio, luego cualquiera en servicio, luego una seguida.
  const todas = await API.get('/api/rutas');
  const sigue = (r) => estado.seguidas.includes(r.id);
  const preferida = todas.find((r) => sigue(r) && r.busesActivos > 0)
    || todas.find((r) => r.busesActivos > 0)
    || todas.find(sigue);
  if (preferida) estado.modalidad = preferida.modalidad;
  await cargarRutas(preferida ? preferida.id : null);

  refrescarAvisos();
  setInterval(refrescarAvisos, REFRESCO_AVISOS_MS);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') programarRefrescoMapa();
  });
});

function conectarEventos() {
  document.querySelectorAll('#modalidad button').forEach((b) => b.addEventListener('click', async () => {
    estado.modalidad = b.dataset.modalidad;
    await cargarRutas(null);
  }));
  $('ruta').addEventListener('change', () => seleccionarRuta(Number($('ruta').value)));
  $('parada').addEventListener('change', () => elegirParada($('parada').value ? Number($('parada').value) : null));
  $('btn-seguir').addEventListener('click', alternarSeguimiento);
  document.querySelectorAll('.nav-app button').forEach((b) => b.addEventListener('click', () => cambiarVista(b.dataset.vista)));
  $('btn-campana').addEventListener('click', () => cambiarVista('avisos'));
  $('asa').addEventListener('click', () => $('panel').classList.toggle('plegado'));
  $('fecha').addEventListener('change', () => {
    estado.fechaElegidaPorUsuario = true;
    pintarSalidasDeFecha();
  });
}

function cambiarVista(vista) {
  estado.vista = vista;
  document.querySelectorAll('.nav-app button').forEach((b) => b.classList.toggle('activa', b.dataset.vista === vista));
  $('vista-mapa').hidden = vista !== 'mapa';
  $('vista-horarios').hidden = vista !== 'horarios';
  $('vista-avisos').hidden = vista !== 'avisos';
  if (vista === 'mapa') {
    $('hueco-selector-mapa').appendChild($('selector-ruta'));
    setTimeout(() => mapa.invalidateSize(), 50);
    programarRefrescoMapa();
  } else {
    clearTimeout(estado.temporizadorMapa);
  }
  if (vista === 'horarios') {
    $('hueco-selector-horarios').appendChild($('selector-ruta'));
    cargarHorarios();
  }
  if (vista === 'avisos') abrirAvisos();
}

async function cargarRutas(rutaPreferida) {
  document.querySelectorAll('#modalidad button').forEach((b) => b.classList.toggle('activa', b.dataset.modalidad === estado.modalidad));
  estado.rutas = await API.get('/api/rutas?modalidad=' + estado.modalidad);
  pintarOpcionesRuta();
  if (estado.rutas.length === 0) {
    pintarEstado('', 'Sin rutas', 'No hay rutas publicadas en esta modalidad.');
    return;
  }
  const id = rutaPreferida
    || (estado.rutas.find((r) => r.busesActivos > 0)
      || estado.rutas.find((r) => estado.seguidas.includes(r.id))
      || estado.rutas[0]).id;
  $('ruta').value = id;
  await seleccionarRuta(id);
}

function pintarOpcionesRuta() {
  const seleccion = $('ruta').value;
  $('ruta').innerHTML = estado.rutas.map((r) => '<option value="' + r.id + '">' + (r.busesActivos > 0 ? '● ' : '')
    + UI.esc(r.nombre) + (r.busesActivos > 0 ? ' · en servicio' : '') + '</option>').join('');
  if (seleccion) $('ruta').value = seleccion;
}

async function seleccionarRuta(id) {
  estado.rutaId = id;
  estado.paradaId = null;
  estado.ultimoEnVivo = null;
  pintarBotonSeguir();
  estado.mapaRuta = await API.get('/api/rutas/' + id + '/mapa');
  $('parada').innerHTML = '<option value="">Próxima parada (automático)</option>'
    + estado.mapaRuta.paradas.map((p) => '<option value="' + p.id + '">' + p.orden + '. ' + UI.esc(p.nombre) + '</option>').join('');
  dibujarRuta();
  if (estado.vista === 'horarios') cargarHorarios();
  programarRefrescoMapa();
}

// ---------- CU-01: mapa en vivo ----------

function margenesMapa() {
  return esMovil()
    ? { paddingTopLeft: [24, 90], paddingBottomRight: [24, Math.round(window.innerHeight * 0.5) + 90] }
    : { paddingTopLeft: [460, 100], paddingBottomRight: [60, 40] };
}

function dibujarRuta() {
  if (estado.capas) estado.capas.remove();
  estado.marcadoresBus.forEach((m) => m.remove());
  estado.marcadoresBus.clear();
  estado.capas = L.layerGroup().addTo(mapa);
  const linea = Mapa.dibujarTrazado(estado.capas, estado.mapaRuta.trazado);
  estado.capaParadas = L.layerGroup().addTo(estado.capas);
  dibujarParadas();
  mapa.fitBounds(linea.getBounds(), margenesMapa());
}

function dibujarParadas() {
  estado.capaParadas.clearLayers();
  const paradas = estado.mapaRuta.paradas;
  paradas.forEach((p, i) => {
    const elegida = p.id === estado.paradaId;
    const extremo = i === 0 || i === paradas.length - 1;
    L.marker([p.lat, p.lng], { icon: Mapa.iconoParada({ elegida, extremo }), zIndexOffset: elegida ? 500 : 0 })
      .bindTooltip(p.orden + '. ' + p.nombre, { direction: 'top', offset: [0, -10] })
      // Paso 7: el pasajero selecciona sobre el mapa la parada donde espera.
      .on('click', () => elegirParada(p.id))
      .addTo(estado.capaParadas);
  });
}

function elegirParada(id) {
  estado.paradaId = id;
  $('parada').value = id ? String(id) : '';
  dibujarParadas();
  refrescarEnVivo();
}

// Paso 9: refresca cada 5 s mientras la pantalla esté activa. La generación evita ciclos duplicados.
function programarRefrescoMapa() {
  clearTimeout(estado.temporizadorMapa);
  const generacion = ++estado.generacionMapa;
  const ejecutar = async () => {
    if (generacion !== estado.generacionMapa || estado.vista !== 'mapa' || !estado.rutaId) return;
    if (document.visibilityState === 'visible' || !estado.ultimoEnVivo) {
      await refrescarEnVivo();
      if (++estado.ciclosMapa % 6 === 0) {
        estado.rutas = await API.get('/api/rutas?modalidad=' + estado.modalidad).catch(() => estado.rutas);
        pintarOpcionesRuta();
      }
    }
    if (generacion === estado.generacionMapa) estado.temporizadorMapa = setTimeout(ejecutar, REFRESCO_MAPA_MS);
  };
  ejecutar();
}

async function refrescarEnVivo() {
  const rutaId = estado.rutaId;
  const url = '/api/rutas/' + rutaId + '/en-vivo' + (estado.paradaId ? '?paradaId=' + estado.paradaId : '');
  try {
    const datos = await API.get(url);
    if (rutaId !== estado.rutaId) return;
    estado.ultimoEnVivo = datos;
    pintarEnVivo(datos, false);
  } catch (e) {
    if (e instanceof ApiError) return UI.error(e);
    // 9a: el dispositivo perdió conexión; se conserva la última posición conocida.
    if (estado.ultimoEnVivo) pintarEnVivo(estado.ultimoEnVivo, true);
    else pintarEstado('sin-conexion', 'Sin conexión', 'No hay datos para mostrar.');
  }
}

function pintarEstado(clase, titulo, mensaje) {
  $('estado').className = 'estado-servicio ' + clase;
  $('estado').innerHTML = '<span class="indicador"></span><div><strong>' + UI.esc(titulo) + '</strong><p>' + UI.esc(mensaje) + '</p></div>';
}

async function sugerirRutasEnServicio(rutaId) {
  const enServicio = (await API.get('/api/rutas')).filter((r) => r.busesActivos > 0 && r.id !== rutaId);
  if (rutaId !== estado.rutaId || enServicio.length === 0) return;
  const contenedor = document.createElement('div');
  contenedor.className = 'sugerencias';
  contenedor.innerHTML = '<small class="tenue" style="width:100%">Rutas con buses en servicio ahora:</small>'
    + enServicio.map((r) => '<button type="button" class="chip" data-ir="' + r.id + '" data-modalidad="' + r.modalidad + '">'
      + icono('bus') + UI.esc(r.nombre) + '</button>').join('');
  contenedor.querySelectorAll('[data-ir]').forEach((b) => b.addEventListener('click', async () => {
    estado.modalidad = b.dataset.modalidad;
    await cargarRutas(Number(b.dataset.ir));
  }));
  $('estado').querySelector('div').appendChild(contenedor);
}

function pintarEnVivo(d, sinConexion) {
  const titulos = { EN_SERVICIO: 'En servicio', SIN_SENAL: 'En ruta sin señal GPS', SIN_SERVICIO: 'Sin servicio activo' };
  const clases = { EN_SERVICIO: 'en-servicio', SIN_SENAL: 'sin-senal', SIN_SERVICIO: '' };
  let mensaje = d.mensaje;
  if (d.estado === 'SIN_SENAL' && d.proximaSalida) mensaje += ' Próxima salida: ' + fmt.fechaHora(d.proximaSalida) + '.';
  if (sinConexion) {
    pintarEstado('sin-conexion', 'Sin conexión', 'Se muestra la última información recibida a las '
      + fmt.soloHora(d.consultadoEn) + '; el dato no está actualizado.');
  } else if (d.estado === 'EN_SERVICIO' && d.buses.every((b) => b.desactualizada)) {
    pintarEstado('sin-senal', 'Posición no actualizada', mensaje);
  } else {
    pintarEstado(clases[d.estado], titulos[d.estado], mensaje);
    if (d.estado === 'SIN_SERVICIO') sugerirRutasEnServicio(d.rutaId);
  }

  const vigentes = new Set();
  d.buses.forEach((b) => {
    vigentes.add(b.recorridoId);
    const desactualizado = b.desactualizada || sinConexion;
    const texto = 'Bus ' + b.placa + ' · posición ' + fmt.hace(b.antiguedadSeg)
      + (b.estadoRecorrido === 'PAUSADO' ? ' · transmisión pausada' : '')
      + (desactualizado ? ' · no actualizada' : '');
    let m = estado.marcadoresBus.get(b.recorridoId);
    if (!m) {
      m = L.marker([b.lat, b.lng], { zIndexOffset: 1000 }).addTo(mapa);
      estado.marcadoresBus.set(b.recorridoId, m);
    }
    m.setLatLng([b.lat, b.lng]);
    m.setIcon(Mapa.iconoBus(b.placa, desactualizado));
    m.bindTooltip(texto, { direction: 'top', offset: [0, -18] });
  });
  estado.marcadoresBus.forEach((m, id) => {
    if (!vigentes.has(id)) { m.remove(); estado.marcadoresBus.delete(id); }
  });

  pintarEta(d.estimacion, d.estado, d.buses);
  $('novedades').innerHTML = d.novedades.length === 0
    ? '<li>' + UI.vacio('Sin novedades en las últimas dos horas.') + '</li>'
    : d.novedades.map((n) => '<li class="item"><span class="icono-chip">' + icono(ICONO_NOVEDAD[n.tipo] || 'alerta') + '</span>'
      + '<div class="item-cuerpo"><strong>' + UI.esc(ETIQUETAS[n.tipo]) + (n.detalle ? ' · ' + UI.esc(n.detalle) : '') + '</strong>'
      + '<small>Bus ' + UI.esc(n.placa) + ' · ' + UI.esc(fmt.soloHora(n.reportadaEn)) + '</small></div></li>').join('');
}

function pintarEta(e, estadoServicio, buses) {
  if (!e) {
    $('eta').innerHTML = '<p class="eta-vacia">' + (estadoServicio === 'EN_SERVICIO'
      ? 'El bus ya superó todas las paradas del trazado.'
      : 'La estimación aparece cuando un bus de la ruta transmite su ubicación.') + '</p>';
    return;
  }
  if (e.yaPaso) {
    $('eta').innerHTML = '<div class="eta-ya-paso">El bus ' + UI.esc(e.placa) + ' ya pasó por <strong>' + UI.esc(e.parada)
      + '</strong>. Consulta la próxima salida en Horarios.</div>';
    return;
  }
  const bus = buses.find((b) => b.placa === e.placa);
  $('eta').innerHTML = '<div class="eta-valor"><span class="minutos">' + (e.minutos <= 1 ? '1' : e.minutos)
    + '</span><span class="unidad">min</span></div>'
    + '<p class="eta-destino">Llega a <strong>' + UI.esc(e.parada) + '</strong>'
    + (e.paradaElegidaPorSistema ? ' <span class="tenue" style="color:rgba(255,255,255,.55)">(próxima parada)</span>' : '') + '</p>'
    + '<div class="eta-meta"><span class="insignia">' + icono('bus') + UI.esc(e.placa) + '</span>'
    + '<span class="insignia">' + icono('ruta') + (e.distanciaMetros / 1000).toFixed(1) + ' km</span>'
    + (bus ? '<span class="insignia">' + icono('senal') + fmt.hace(bus.antiguedadSeg) + '</span>' : '') + '</div>';
}

// ---------- Seguimiento de rutas ----------

function pintarBotonSeguir() {
  const sigue = estado.seguidas.includes(estado.rutaId);
  $('btn-seguir').classList.toggle('activo', sigue);
  $('btn-seguir').title = sigue ? 'Siguiendo: recibes las novedades de esta ruta' : 'Seguir ruta: recibir sus novedades';
}

async function alternarSeguimiento() {
  const id = estado.rutaId;
  try {
    if (estado.seguidas.includes(id)) {
      await API.del('/api/pasajero/seguimientos/' + id);
      estado.seguidas = estado.seguidas.filter((x) => x !== id);
      UI.toast('Ya no recibirás novedades de esta ruta.');
    } else {
      await API.put('/api/pasajero/seguimientos/' + id);
      estado.seguidas.push(id);
      UI.toast('Recibirás las novedades que reporten los conductores de esta ruta.', 'exito', 'Siguiendo la ruta');
    }
    pintarBotonSeguir();
  } catch (e) {
    UI.error(e);
  }
}

// ---------- CU-02: horarios y recordatorios ----------

async function cargarHorarios() {
  try {
    const h = await API.get('/api/rutas/' + estado.rutaId + '/horarios');
    estado.horarios = h;
    $('horarios-titulo').textContent = h.ruta;
    $('horarios-subtitulo').textContent = (h.modalidad === 'CENTRO' ? 'Ruta de alta frecuencia' : 'Ruta de Barrio con salidas puntuales')
      + ' · toca una salida para programar un recordatorio.';
    $('proxima-hora').textContent = h.proximaSalida ? h.proximaSalida.slice(11, 16) : '--:--';
    $('proxima-fecha').textContent = h.proximaSalida ? fmt.fecha(h.proximaSalida.slice(0, 10)) : 'Sin salidas próximas';
    $('aviso-programacion').innerHTML = h.avisoActualizacion
      ? '<div class="aviso ambar">' + icono('info') + '<span>' + UI.esc(h.avisoActualizacion) + '</span></div>' : '';
    $('bloques-habiles').innerHTML = pintarBloques(h.habiles);
    $('bloques-sabados').innerHTML = pintarBloques(h.sabados);
    // Si hoy no hay servicio (p. ej. domingo), se muestra directamente el próximo día con salidas.
    if (!estado.fechaElegidaPorUsuario) {
      const horasHoy = horasDeFecha(UI.hoyISO());
      $('fecha').value = (!horasHoy || horasHoy.length === 0) && h.proximaSalida ? h.proximaSalida.slice(0, 10) : UI.hoyISO();
    }
    pintarSalidasDeFecha();
    cargarRecordatorios();
  } catch (e) {
    UI.error(e);
  }
}

function pintarBloques(bloques) {
  if (bloques.length === 0) return UI.vacio('Sin salidas programadas.');
  return bloques.map((b) => '<div class="bloque-horario"><div class="entre"><strong>' + UI.esc(b.nombre) + '</strong>'
    + '<span class="insignia">' + UI.esc(b.descripcion) + '</span></div><div class="chips">'
    + b.horas.map((t) => '<span class="chip">' + fmt.hora(t) + '</span>').join('') + '</div></div>').join('');
}

function horasDeFecha(fechaISO) {
  const dia = new Date(fechaISO + 'T00:00:00').getDay();
  if (dia === 0) return null;
  const bloques = dia === 6 ? estado.horarios.sabados : estado.horarios.habiles;
  return [...new Set(bloques.flatMap((b) => b.horas))].sort();
}

function pintarSalidasDeFecha() {
  if (!estado.horarios) return;
  const fecha = $('fecha').value || UI.hoyISO();
  $('titulo-fecha').textContent = 'Salidas del ' + fmt.fecha(fecha);
  const horas = horasDeFecha(fecha);
  if (!horas || horas.length === 0) {
    $('salidas-fecha').innerHTML = UI.vacio('No hay servicio programado para esta fecha.');
    return;
  }
  const ahora = new Date();
  let marcadaProxima = false;
  $('salidas-fecha').innerHTML = horas.map((t) => {
    const pasada = new Date(fecha + 'T' + t) <= ahora;
    let clase = 'chip';
    if (pasada) clase += ' pasada';
    else if (!marcadaProxima) { clase += ' proxima'; marcadaProxima = true; }
    return '<button type="button" class="' + clase + '" data-hora="' + UI.esc(t) + '">' + fmt.hora(t) + '</button>';
  }).join('');
  $('salidas-fecha').querySelectorAll('button').forEach((b) => b.addEventListener('click', () => crearRecordatorio(fecha, b.dataset.hora)));
}

async function crearRecordatorio(fecha, hora) {
  try {
    await API.post('/api/pasajero/recordatorios', {
      rutaId: estado.rutaId, fecha, hora, minutosAntes: Number($('minutos-antes').value),
    });
    UI.toast('Te avisaremos ' + $('minutos-antes').value + ' minutos antes de la salida de las ' + fmt.hora(hora) + '.', 'exito', 'Recordatorio creado');
    cargarRecordatorios();
  } catch (e) {
    // 7a: la salida ya ocurrió; el sistema sugiere la siguiente disponible.
    if (e.datos && e.datos.sugerencia) {
      const s = e.datos.sugerencia;
      const aceptar = await UI.confirmar({
        titulo: 'Esa salida ya pasó', mensaje: e.message + '\n\n¿Quieres el recordatorio para esa salida?',
        aceptar: 'Crear recordatorio', icono: 'reloj',
      });
      if (aceptar) return crearRecordatorio(s.slice(0, 10), s.slice(11, 16) + ':00');
      return;
    }
    UI.error(e);
  }
}

async function cargarRecordatorios() {
  const lista = await API.get('/api/pasajero/recordatorios');
  $('recordatorios').innerHTML = lista.length === 0
    ? '<li>' + UI.vacio('No tienes recordatorios activos.') + '</li>'
    : lista.map((r) => '<li class="item"><span class="icono-chip">' + icono('campana') + '</span><div class="item-cuerpo"><strong>'
      + UI.esc(r.ruta) + '</strong><small>' + UI.esc(fmt.fechaHora(r.salidaProgramada)) + ' · aviso ' + r.minutosAntes + ' min antes'
      + (r.notificado ? ' · ya notificado' : '') + '</small></div>'
      + '<button class="boton fantasma pequeno" data-id="' + r.id + '">' + icono('x') + 'Cancelar</button></li>').join('');
  $('recordatorios').querySelectorAll('button[data-id]').forEach((b) => b.addEventListener('click', async () => {
    await API.del('/api/pasajero/recordatorios/' + b.dataset.id);
    cargarRecordatorios();
  }));
}

// ---------- Notificaciones push (simuladas por consulta periódica) ----------

async function refrescarAvisos() {
  try {
    const bandeja = await API.get('/api/pasajero/notificaciones');
    $('contador-avisos').hidden = bandeja.noLeidas === 0;
    $('contador-avisos').textContent = bandeja.noLeidas > 9 ? '9+' : bandeja.noLeidas;
    bandeja.notificaciones.forEach((n) => {
      if (!estado.avisosVistos.has(n.id)) {
        estado.avisosVistos.add(n.id);
        if (!estado.primeraCargaAvisos && !n.leida) UI.toast(n.mensaje, 'push', n.titulo, 8000);
      }
    });
    estado.primeraCargaAvisos = false;
    estado.bandeja = bandeja;
    if (estado.vista === 'avisos') pintarAvisos(bandeja.notificaciones);
  } catch (e) {
    // Sin conexión: se reintenta en el siguiente ciclo.
  }
}

async function abrirAvisos() {
  await refrescarAvisos();
  pintarAvisos(estado.bandeja ? estado.bandeja.notificaciones : []);
  await API.post('/api/pasajero/notificaciones/leidas');
  $('contador-avisos').hidden = true;
}

function pintarAvisos(lista) {
  const estilos = { NOVEDAD: ['ambar', 'alerta'], URGENTE: ['rojo', 'rayo'], RECORDATORIO: ['verde', 'reloj'] };
  $('lista-avisos').innerHTML = lista.length === 0
    ? '<li>' + UI.vacio('No tienes avisos todavía. Sigue una ruta para recibir sus novedades.') + '</li>'
    : lista.map((n) => {
      const [color, nombreIcono] = estilos[n.categoria] || ['', 'info'];
      return '<li class="aviso-item' + (n.leida ? '' : ' nuevo') + '"><span class="icono-chip">' + icono(nombreIcono) + '</span>'
        + '<div class="item-cuerpo"><div class="entre"><strong>' + UI.esc(n.titulo) + '</strong>'
        + '<span class="insignia ' + color + '">' + UI.esc(ETIQUETAS[n.categoria] || n.categoria) + '</span></div>'
        + '<p>' + UI.esc(n.mensaje) + '</p><small class="tenue">' + UI.esc(fmt.fechaHora(n.creadaEn)) + '</small></div></li>';
    }).join('');
}
