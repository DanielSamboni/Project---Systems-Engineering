'use strict';

/* Terminal del conductor: CU-04 (transmitir ubicación y reportar novedades) y CU-03 (validar acceso). */

const INTERVALO_GPS_MS = 5000;
const VELOCIDAD_BASE_KMH = 30;

const t = {
  recorrido: null,
  mapa: null,
  capa: null,
  marcador: null,
  temporizador: null,
  watchId: null,
  ultimaGeo: null,
  metodo: 'QR',
  carnetsLocales: new Map(),
  totalCarnets: 0,
};

// ---------- Persistencia local de la terminal (cola sin cobertura y avance del simulador) ----------

const local = {
  leer(clave, porDefecto) {
    try { return JSON.parse(localStorage.getItem(clave)) ?? porDefecto; } catch (e) { return porDefecto; }
  },
  escribir(clave, valor) {
    try { localStorage.setItem(clave, JSON.stringify(valor)); } catch (e) { /* almacenamiento no disponible */ }
  },
};
const claveCola = (tipo) => 'terminal.' + tipo + '.' + t.recorrido.id;
const sinCobertura = () => $('sin-cobertura').checked;

document.addEventListener('DOMContentLoaded', async () => {
  let yo;
  try {
    yo = await Sesion.requerir('CONDUCTOR');
  } catch (e) {
    return;
  }
  $('saludo').textContent = 'Hola, ' + yo.nombre.split(' ')[0];
  conectarEventos();
  actualizarRelojes();
  setInterval(actualizarRelojes, 1000);
  await cargar();
});

function conectarEventos() {
  $('btn-pausar').addEventListener('click', alternarPausa);
  $('btn-finalizar').addEventListener('click', finalizar);
  document.querySelectorAll('[data-novedad]').forEach((b) => b.addEventListener('click', () => reportarNovedad(b.dataset.novedad)));
  document.querySelectorAll('#metodo button').forEach((b) => b.addEventListener('click', () => {
    t.metodo = b.dataset.metodo;
    document.querySelectorAll('#metodo button').forEach((x) => x.classList.toggle('activa', x === b));
    $('identificador').placeholder = t.metodo === 'MANUAL' ? 'Digite el número de documento' : 'Acerque o digite el carnet';
    $('identificador').focus();
  }));
  $('form-validar').addEventListener('submit', (ev) => { ev.preventDefault(); validar(); });
  document.querySelectorAll('[data-carnet]').forEach((b) => b.addEventListener('click', () => {
    $('identificador').value = b.dataset.carnet;
    validar();
  }));
  $('fuente-gps').addEventListener('change', configurarFuenteGps);
  $('sin-cobertura').addEventListener('change', () => {
    pintarCobertura();
    if (!sinCobertura()) sincronizarPendientes();
    pintarInfoColas();
  });
}

function actualizarRelojes() {
  $('reloj').textContent = new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: false });
  if (t.recorrido) {
    const segundos = Math.max(0, Math.floor((Date.now() - new Date(t.recorrido.inicio).getTime()) / 1000));
    const h = String(Math.floor(segundos / 3600)).padStart(2, '0');
    const m = String(Math.floor(segundos / 60) % 60).padStart(2, '0');
    const s = String(segundos % 60).padStart(2, '0');
    $('cronometro').textContent = h + ':' + m + ':' + s;
  }
}

async function cargar() {
  const recorrido = await API.get('/api/conductor/recorrido-actual');
  if (recorrido) mostrarRecorrido(recorrido);
  else mostrarTurnos();
}

// ---------- Selección de turno e inicio ----------

async function mostrarTurnos() {
  detenerGps();
  t.recorrido = null;
  $('vista-recorrido').hidden = true;
  $('vista-turnos').hidden = false;
  const turnos = await API.get('/api/conductor/turnos');
  $('turnos').innerHTML = turnos.length === 0
    ? UI.vacio('No tienes turnos asignados. Comunícate con la oficina de transporte.')
    : turnos.map((x) => '<article class="turno">'
      + '<div><span class="insignia">' + icono('calendario') + UI.esc(ETIQUETAS[x.tipoDia]) + '</span></div>'
      + '<h3>' + UI.esc(x.ruta) + '</h3>'
      + '<div class="datos"><span class="insignia">' + icono('reloj') + fmt.hora(x.horaInicio) + ' – ' + fmt.hora(x.horaFin) + '</span>'
      + '<span class="insignia">' + icono('bus') + UI.esc(x.placa) + '</span>'
      + (x.vehiculoTieneGps ? '<span class="insignia verde">' + icono('gps') + 'GPS</span>' : '<span class="insignia ambar">' + icono('sinSenal') + 'Sin GPS</span>')
      + '</div>'
      + '<button class="boton primario grande bloque" data-turno="' + x.id + '">' + icono('play') + 'Iniciar recorrido</button></article>').join('');
  $('turnos').querySelectorAll('[data-turno]').forEach((b) => b.addEventListener('click', () => iniciar(Number(b.dataset.turno), false)));
}

async function iniciar(turnoId, confirmar) {
  try {
    const r = await API.post('/api/conductor/recorridos', { turnoId, confirmarSegundoVehiculo: confirmar });
    UI.toast(r.vehiculoTieneGps
      ? 'Transmitiendo ubicación cada 5 segundos.'
      : 'El vehículo no tiene GPS: los pasajeros verán que el bus está en ruta sin señal.', 'exito', 'Recorrido iniciado');
    mostrarRecorrido(r);
  } catch (e) {
    // 4a: la ruta ya fue iniciada por otro vehículo.
    if (e.datos && e.datos.requiereConfirmacion) {
      const seguir = await UI.confirmar({
        titulo: 'Ruta ya iniciada', mensaje: e.message, aceptar: 'Registrar como vehículo adicional', icono: 'bus',
      });
      if (seguir) return iniciar(turnoId, true);
      return;
    }
    UI.error(e);
  }
}

// ---------- Recorrido activo ----------

function mostrarRecorrido(r) {
  t.recorrido = r;
  $('vista-turnos').hidden = true;
  $('vista-recorrido').hidden = false;
  $('titulo-recorrido').textContent = r.ruta + ' · ' + r.placa;
  pintarEstado();
  pintarCobertura();
  if (!t.mapa) t.mapa = Mapa.crear('mapa', { oscuro: true });
  setTimeout(() => t.mapa.invalidateSize(), 60);
  if (t.capa) t.capa.remove();
  t.capa = L.layerGroup().addTo(t.mapa);
  const linea = Mapa.dibujarTrazado(t.capa, r.trazado, { oscuro: true });
  r.paradas.forEach((p, i) => L.marker([p.lat, p.lng], { icon: Mapa.iconoParada({ extremo: i === 0 || i === r.paradas.length - 1 }) })
    .bindTooltip(p.orden + '. ' + p.nombre, { direction: 'top', offset: [0, -10] }).addTo(t.capa));
  t.mapa.fitBounds(linea.getBounds(), { paddingTopLeft: [30, 30], paddingBottomRight: [30, 180] });
  if (t.marcador) t.marcador.remove();
  t.marcador = null;
  if (r.ultimaPosicion) moverMarcador(r.ultimaPosicion.lat, r.ultimaPosicion.lng);

  $('insignia-gps').className = 'insignia ' + (r.vehiculoTieneGps ? 'verde' : 'ambar');
  $('insignia-gps').innerHTML = icono(r.vehiculoTieneGps ? 'gps' : 'sinSenal') + (r.vehiculoTieneGps ? 'GPS instalado' : 'Vehículo sin GPS');
  $('fuente-gps').disabled = !r.vehiculoTieneGps;
  $('velocidad').disabled = !r.vehiculoTieneGps;
  $('btn-pausar').hidden = !r.vehiculoTieneGps;
  actualizarRelojes();
  configurarFuenteGps();
  descargarCopiaCarnets();
  cargarAbordajes();
  sincronizarPendientes();
}

function pintarEstado() {
  const r = t.recorrido;
  const enCurso = r.estado === 'EN_CURSO';
  $('insignia-estado').className = 'insignia punto ' + (enCurso ? 'verde vivo' : 'ambar');
  $('insignia-estado').textContent = enCurso ? 'Transmitiendo' : 'Transmisión pausada';
  $('btn-pausar').innerHTML = enCurso ? icono('pausa') + 'Pausar' : icono('play') + 'Reanudar';
}

function pintarCobertura() {
  const sin = sinCobertura();
  $('insignia-cobertura').className = 'insignia ' + (sin ? 'rojo' : 'verde');
  $('insignia-cobertura').innerHTML = icono(sin ? 'sinSenal' : 'senal') + (sin ? 'Sin cobertura' : 'Con cobertura');
}

async function alternarPausa() {
  const accion = t.recorrido.estado === 'PAUSADO' ? 'reanudar' : 'pausar';
  try {
    const r = await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/' + accion);
    t.recorrido.estado = r.estado;
    pintarEstado();
    pintarInfoGps();
  } catch (e) {
    UI.error(e);
  }
}

async function finalizar() {
  const ok = await UI.confirmar({
    titulo: '¿Finalizar el recorrido?', mensaje: 'Se detendrá la transmisión de ubicación y el trayecto quedará registrado.',
    aceptar: 'Finalizar', peligro: true, icono: 'detener',
  });
  if (!ok) return;
  try {
    await sincronizarPendientes();
    await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/finalizar');
    localStorage.removeItem('terminal.sim.' + t.recorrido.id);
    UI.toast('El trayecto quedó registrado.', 'exito', 'Recorrido finalizado');
    mostrarTurnos();
  } catch (e) {
    UI.error(e);
  }
}

// ---------- Captura y envío de posición GPS ----------

function configurarFuenteGps() {
  detenerGps();
  if (!t.recorrido || !t.recorrido.vehiculoTieneGps) {
    pintarInfoGps();
    return;
  }
  if ($('fuente-gps').value === 'dispositivo') {
    if (!navigator.geolocation) {
      UI.toast('Este navegador no permite leer la ubicación del dispositivo.', 'error');
      $('fuente-gps').value = 'simulador';
    } else {
      t.watchId = navigator.geolocation.watchPosition(
        (p) => { t.ultimaGeo = { lat: p.coords.latitude, lng: p.coords.longitude }; },
        (err) => UI.toast('No se pudo leer el GPS del dispositivo: ' + err.message, 'error'),
        { enableHighAccuracy: true },
      );
    }
  }
  t.temporizador = setInterval(tickGps, INTERVALO_GPS_MS);
  tickGps();
}

function detenerGps() {
  clearInterval(t.temporizador);
  if (t.watchId !== null) navigator.geolocation.clearWatch(t.watchId);
  t.watchId = null;
}

function siguientePosicionSimulada() {
  const trazado = t.recorrido.trazado;
  const clave = 'terminal.sim.' + t.recorrido.id;
  let recorridoM = local.leer(clave, 0);
  recorridoM += VELOCIDAD_BASE_KMH / 3.6 * (INTERVALO_GPS_MS / 1000) * Number($('velocidad').value);
  let acumulado = 0;
  for (let i = 0; i + 1 < trazado.length; i++) {
    const a = L.latLng(trazado[i].lat, trazado[i].lng);
    const b = L.latLng(trazado[i + 1].lat, trazado[i + 1].lng);
    const largo = a.distanceTo(b);
    if (recorridoM <= acumulado + largo) {
      const f = largo === 0 ? 0 : (recorridoM - acumulado) / largo;
      local.escribir(clave, recorridoM);
      return { lat: a.lat + (b.lat - a.lat) * f, lng: a.lng + (b.lng - a.lng) * f, fin: false };
    }
    acumulado += largo;
  }
  local.escribir(clave, acumulado);
  const ultimo = trazado[trazado.length - 1];
  return { lat: ultimo.lat, lng: ultimo.lng, fin: true };
}

async function tickGps() {
  if (!t.recorrido || t.recorrido.estado !== 'EN_CURSO') {
    pintarInfoGps();
    return;
  }
  let pos;
  if ($('fuente-gps').value === 'dispositivo') {
    if (!t.ultimaGeo) return;
    pos = t.ultimaGeo;
  } else {
    pos = siguientePosicionSimulada();
  }
  moverMarcador(pos.lat, pos.lng);
  const pendientes = local.leer(claveCola('gps'), []);
  pendientes.push({ lat: pos.lat, lng: pos.lng, capturadaEn: new Date().toISOString() });
  if (sinCobertura()) {
    // 5a: la terminal almacena localmente y reenvía al recuperar la señal.
    local.escribir(claveCola('gps'), pendientes);
    pintarInfoColas();
    return;
  }
  try {
    await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/posiciones', pendientes);
    local.escribir(claveCola('gps'), []);
    pintarInfoGps(pos.fin);
  } catch (e) {
    if (e instanceof ApiError) {
      // El servidor rechazó el lote (p. ej. recorrido pausado o finalizado): reintentarlo no cambiaría el resultado.
      local.escribir(claveCola('gps'), []);
      UI.error(e);
    } else {
      local.escribir(claveCola('gps'), pendientes);
    }
  }
}

function moverMarcador(lat, lng) {
  if (!t.marcador) {
    t.marcador = L.marker([lat, lng], { icon: Mapa.iconoBus(t.recorrido.placa, false), zIndexOffset: 1000 }).addTo(t.mapa);
  } else {
    t.marcador.setLatLng([lat, lng]);
  }
}

function pintarInfoGps(llegoAlFinal) {
  const r = t.recorrido;
  if (!r) return;
  let texto;
  if (!r.vehiculoTieneGps) {
    texto = 'Este vehículo no tiene GPS: los pasajeros verán «vehículo en ruta sin señal de ubicación».';
  } else if (r.estado === 'PAUSADO') {
    texto = 'Transmisión pausada. Los pasajeros verán la última posición marcada como no actualizada.';
  } else {
    texto = 'Última posición enviada a las ' + new Date().toLocaleTimeString('es-CO', { hour12: false })
      + (llegoAlFinal ? ' · el bus llegó al final del trazado.' : '.');
  }
  $('info-gps').innerHTML = icono('info') + UI.esc(texto);
  pintarInfoColas();
}

function pintarInfoColas() {
  if (!t.recorrido) return;
  const gps = local.leer(claveCola('gps'), []).length;
  const accesos = local.leer(claveCola('accesos'), []).length;
  $('info-contingencia').textContent = (accesos ? accesos + ' abordaje(s) pendientes de sincronizar · ' : '')
    + (t.totalCarnets ? 'Copia local para contingencia: ' + t.totalCarnets + ' carnets vigentes.' : 'Sin copia local de carnets.');
  if (sinCobertura() && gps) {
    $('info-gps').innerHTML = icono('sinSenal') + gps + ' posición(es) almacenadas en la terminal; se reenviarán al recuperar la señal.';
  }
}

async function sincronizarPendientes() {
  if (!t.recorrido || sinCobertura()) return;
  const gps = local.leer(claveCola('gps'), []);
  if (gps.length && t.recorrido.estado === 'EN_CURSO' && t.recorrido.vehiculoTieneGps) {
    try {
      const r = await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/posiciones', gps);
      local.escribir(claveCola('gps'), []);
      UI.toast(r.aceptadas + ' posiciones reenviadas.', 'exito', 'Señal recuperada');
    } catch (e) { /* se reintenta en el siguiente envío */ }
  }
  const accesos = local.leer(claveCola('accesos'), []);
  if (accesos.length) {
    try {
      const r = await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/validaciones/sincronizar', accesos);
      local.escribir(claveCola('accesos'), []);
      UI.toast(r.sincronizados + ' abordaje(s) validados sin conexión fueron registrados.', 'exito', 'Sincronización completa');
      cargarAbordajes();
    } catch (e) { /* se reintenta luego */ }
  }
  pintarInfoColas();
}

// ---------- CU-04 extensión: Reportar Alerta de Novedad ----------

async function reportarNovedad(tipo) {
  const detalle = $('detalle-novedad').value.trim();
  const ok = await UI.confirmar({
    titulo: 'Reportar «' + ETIQUETAS[tipo] + '»',
    mensaje: 'Se enviará una notificación a los pasajeros que siguen esta ruta.' + (detalle ? '\n\nDetalle: ' + detalle : ''),
    aceptar: 'Enviar novedad', peligro: tipo === 'ACCIDENTE' || tipo === 'VARADA', icono: ICONO_NOVEDAD[tipo],
  });
  if (!ok) return;
  try {
    const r = await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/novedades', { tipo, detalle });
    $('detalle-novedad').value = '';
    UI.toast('Se notificó a ' + r.pasajerosNotificados + ' pasajero(s).', 'exito', 'Novedad enviada');
  } catch (e) {
    UI.error(e);
  }
}

// ---------- CU-03: Validar Acceso al Bus ----------

async function descargarCopiaCarnets() {
  let lista;
  try {
    lista = await API.get('/api/conductor/recorridos/' + t.recorrido.id + '/carnets-vigentes');
    local.escribir('terminal.carnets', lista);
  } catch (e) {
    lista = local.leer('terminal.carnets', []);
  }
  t.carnetsLocales = new Map();
  lista.forEach((c) => {
    t.carnetsLocales.set(c.codigo, c);
    t.carnetsLocales.set(c.documento, c);
  });
  t.totalCarnets = lista.length;
  pintarInfoColas();
}

async function validar() {
  const identificador = $('identificador').value.trim();
  if (!identificador) return;
  const metodo = t.metodo;
  if (sinCobertura()) return validarSinConexion(identificador, metodo, 'Sin cobertura');
  try {
    const r = await API.post('/api/conductor/recorridos/' + t.recorrido.id + '/validaciones', { identificador, metodo });
    pintarSemaforo(r.resultado === 'APROBADO', r.nombre, r.motivo, null);
    cargarAbordajes();
  } catch (e) {
    if ((e.datos && e.datos.contingencia) || !(e instanceof ApiError)) {
      return validarSinConexion(identificador, metodo, e.datos && e.datos.contingencia ? 'Sistema Académico no disponible' : 'Sin conexión');
    }
    UI.error(e);
  } finally {
    $('identificador').value = '';
    $('identificador').focus();
  }
}

// 3a: validación contra la copia local descargada al iniciar el recorrido.
function validarSinConexion(identificador, metodo, causa) {
  const portador = t.carnetsLocales.get(identificador);
  const aprobado = Boolean(portador);
  const motivo = aprobado ? null : 'No figura en la copia local de carnets vigentes';
  const ahora = new Date();
  const fechaHora = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000).toISOString().slice(0, 19);
  const cola = local.leer(claveCola('accesos'), []);
  cola.push({ identificador, metodo, fechaHora, resultado: aprobado ? 'APROBADO' : 'DENEGADO', motivo, nombre: portador ? portador.nombre : null });
  local.escribir(claveCola('accesos'), cola);
  pintarSemaforo(aprobado, portador && portador.nombre, motivo, causa);
  pintarInfoColas();
  $('identificador').value = '';
}

function pintarSemaforo(aprobado, nombre, motivo, causaContingencia) {
  const s = $('semaforo');
  s.className = 'semaforo destello ' + (aprobado ? 'verde' : 'rojo');
  const detalle = [nombre, motivo].filter(Boolean).map(UI.esc).join(' · ');
  s.innerHTML = '<span class="luz">' + icono(aprobado ? 'check' : 'x') + '</span><div><strong>'
    + (aprobado ? 'Acceso aprobado' : 'Acceso denegado') + '</strong><small>' + detalle
    + (causaContingencia ? '<br>Modo contingencia (' + UI.esc(causaContingencia) + '): se sincronizará después' : '') + '</small></div>';
  pitido(aprobado);
}

function pitido(aprobado) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    osc.frequency.value = aprobado ? 880 : 220;
    osc.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + (aprobado ? 0.15 : 0.45));
  } catch (e) { /* sin audio disponible */ }
}

async function cargarAbordajes() {
  try {
    const lista = await API.get('/api/conductor/recorridos/' + t.recorrido.id + '/abordajes');
    $('abordajes').innerHTML = lista.length === 0
      ? '<li>' + UI.vacio('Aún no hay abordajes en este recorrido.') + '</li>'
      : lista.map((a) => {
        const ok = a.resultado === 'APROBADO';
        return '<li class="item"><span class="icono-chip" style="' + (ok ? 'background:rgba(16,185,129,.15);color:#34d399' : '') + '">'
          + icono(ok ? 'check' : 'x') + '</span><div class="item-cuerpo"><strong>' + UI.esc(a.nombre || a.identificador) + '</strong>'
          + '<small>' + UI.esc(fmt.soloHora(a.fechaHora)) + ' · ' + UI.esc(ETIQUETAS[a.metodo])
          + (a.modo === 'CONTINGENCIA' ? ' · contingencia' : '') + (a.motivo ? ' · ' + UI.esc(a.motivo) : '') + '</small></div></li>';
      }).join('');
  } catch (e) { /* sin conexión */ }
}
