'use strict';

/* Módulo administrativo: CU-05 (RF-12, RF-13, RF-14) y revisión de accesos denegados de CU-03. */

const SECCIONES = {
  monitoreo: ['Monitoreo en vivo', 'Supervisa toda la flota: posición de cada bus, abordajes y novedades del día.'],
  reportes: ['Reportes e indicadores', 'Abordajes por ruta, franja y día, e indicadores de éxito para sustentar la programación.'],
  rutas: ['Rutas y horarios', 'Crea y edita rutas, paradas y salidas, y publícalas para la comunidad.'],
  turnos: ['Turnos', 'Asigna y modifica los vehículos y conductores de cada turno.'],
  vehiculos: ['Vehículos', 'Flota del operador y su equipamiento a bordo.'],
  conductores: ['Conductores', 'Personal del operador habilitado para usar la terminal a bordo.'],
  denegados: ['Accesos denegados', 'Intentos de abordaje rechazados pendientes de revisión.'],
  sistema: ['Sistema académico', 'Disponibilidad del sistema externo que certifica los carnets.'],
};
const REFRESCO_FLOTA_MS = 5000;

let seccionActual = null;
let ed = null;
let mapaEditor = null;
let capaEditor = null;
let filtroModalidad = '';
let turnoEditando = null;
const flota = { mapa: null, capaRutas: null, marcadores: new Map(), rutas: new Map(), temporizador: null, ajustado: false };

document.addEventListener('DOMContentLoaded', async () => {
  try {
    await Sesion.requerir('ADMINISTRADOR');
  } catch (e) {
    return;
  }
  $('fecha-hoy').insertAdjacentText('beforeend', new Date().toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long' }));
  document.querySelectorAll('#menu button').forEach((b) => b.addEventListener('click', () => abrirSeccion(b.dataset.seccion)));
  aplicarRango(14);
  document.querySelectorAll('#rangos button').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('#rangos button').forEach((x) => x.classList.toggle('activa', x === b));
    aplicarRango(Number(b.dataset.dias));
    cargarReporte();
  }));
  $('btn-reporte').addEventListener('click', cargarReporte);

  document.querySelectorAll('#filtro-modalidad button').forEach((b) => b.addEventListener('click', () => {
    filtroModalidad = b.dataset.filtro;
    document.querySelectorAll('#filtro-modalidad button').forEach((x) => x.classList.toggle('activa', x === b));
    cargarRutas();
  }));
  $('btn-nueva-ruta').addEventListener('click', () => abrirEditor(null));
  $('btn-volver').addEventListener('click', cerrarEditor);
  $('btn-validar').addEventListener('click', validarRuta);
  $('btn-guardar').addEventListener('click', guardarRuta);
  $('btn-trazar-vias').addEventListener('click', trazarPorVias);
  $('btn-agregar-salida').addEventListener('click', () => { leerSalidas(); ed.salidas.push(salidaVacia()); pintarSalidas(); });
  $('ed-modalidad').addEventListener('change', () => {
    leerSalidas();
    ed.modalidad = $('ed-modalidad').value;
    ed.salidas = ed.salidas.map(convertirSalida);
    pintarSalidas();
  });
  document.querySelectorAll('#modo-mapa button').forEach((b) => b.addEventListener('click', () => {
    ed.modoMapa = b.dataset.modo;
    document.querySelectorAll('#modo-mapa button').forEach((x) => x.classList.toggle('activa', x === b));
    pintarMapaEditor(false);
  }));
  $('btn-deshacer').addEventListener('click', () => { ed.trazado.pop(); pintarMapaEditor(false); });
  $('btn-limpiar').addEventListener('click', async () => {
    const ok = await UI.confirmar({ titulo: 'Limpiar trazado', mensaje: '¿Borrar todos los puntos del trazado? Las paradas se conservan.', aceptar: 'Borrar trazado', peligro: true, icono: 'basura' });
    if (ok) { ed.trazado = []; pintarMapaEditor(false); }
  });

  $('form-turno').addEventListener('submit', guardarTurno);
  $('btn-cancelar-turno').addEventListener('click', salirDeEdicionTurno);
  $('form-vehiculo').addEventListener('submit', crearVehiculo);
  $('form-conductor').addEventListener('submit', crearConductor);
  $('btn-sa').addEventListener('click', alternarSistemaAcademico);

  abrirSeccion('monitoreo');
  actualizarContadorDenegados();
});

function abrirSeccion(seccion) {
  seccionActual = seccion;
  document.querySelectorAll('#menu button').forEach((b) => b.classList.toggle('activa', b.dataset.seccion === seccion));
  document.querySelectorAll('[data-panel]').forEach((p) => { p.hidden = p.dataset.panel !== seccion; });
  $('titulo-seccion').textContent = SECCIONES[seccion][0];
  $('subtitulo-seccion').textContent = SECCIONES[seccion][1];
  if (seccion !== 'monitoreo') clearInterval(flota.temporizador);
  const cargas = {
    monitoreo: cargarMonitoreo, reportes: cargarReporte, rutas: cargarRutas, turnos: cargarTurnos, vehiculos: cargarVehiculos,
    conductores: cargarConductores, denegados: cargarDenegados, sistema: cargarSistemaAcademico,
  };
  cargas[seccion]().catch(UI.error);
}

// ---------- Monitoreo en vivo (supervisión del servicio) ----------

async function cargarMonitoreo() {
  if (!flota.mapa) {
    flota.mapa = Mapa.crear('mapa-flota');
    flota.capaRutas = L.layerGroup().addTo(flota.mapa);
  }
  setTimeout(() => flota.mapa.invalidateSize(), 60);
  await refrescarFlota();
  flota.mapa.invalidateSize();
  clearInterval(flota.temporizador);
  flota.temporizador = setInterval(() => {
    if (seccionActual === 'monitoreo' && document.visibilityState === 'visible') refrescarFlota().catch(() => {});
  }, REFRESCO_FLOTA_MS);
}

async function refrescarFlota() {
  const f = await API.get('/api/admin/monitoreo');
  const r = f.resumen;
  $('kpis-flota').innerHTML = [
    { etiqueta: 'Buses en ruta', valor: r.busesEnRuta, icono: 'bus', destacado: true },
    { etiqueta: 'Rutas en servicio', valor: r.rutasEnServicio, icono: 'ruta' },
    { etiqueta: 'Sin señal o desactualizados', valor: r.sinSenal, icono: 'sinSenal' },
    { etiqueta: 'Abordajes de hoy', valor: fmt.numero(r.abordajesHoy), icono: 'usuarios' },
    { etiqueta: 'Novedades de hoy', valor: r.novedadesHoy, icono: 'alerta' },
  ].map(tarjetaKpi).join('');
  $('contador-buses').hidden = r.busesEnRuta === 0;
  $('contador-buses').textContent = r.busesEnRuta;

  await dibujarRutasActivas(new Set(f.buses.map((b) => b.rutaId)));
  const vigentes = new Set();
  f.buses.filter((b) => b.lat !== null).forEach((b) => {
    vigentes.add(b.recorridoId);
    let m = flota.marcadores.get(b.recorridoId);
    if (!m) {
      m = L.marker([b.lat, b.lng], { zIndexOffset: 1000 }).addTo(flota.mapa);
      flota.marcadores.set(b.recorridoId, m);
    }
    m.setLatLng([b.lat, b.lng]);
    m.setIcon(Mapa.iconoBus(b.placa, b.desactualizada));
    m.bindTooltip(b.ruta + ' · ' + b.conductor + (b.desactualizada ? ' · posición no actualizada' : ''), { direction: 'top', offset: [0, -18] });
  });
  flota.marcadores.forEach((m, id) => { if (!vigentes.has(id)) { m.remove(); flota.marcadores.delete(id); } });
  if (!flota.ajustado && flota.rutas.size) {
    const limites = L.latLngBounds([]);
    flota.rutas.forEach((capa) => capa.eachLayer((l) => { if (l.getBounds) limites.extend(l.getBounds()); }));
    if (limites.isValid()) flota.mapa.fitBounds(limites, { padding: [40, 40] });
    flota.ajustado = true;
  }

  $('lista-flota').innerHTML = f.buses.length === 0
    ? '<li>' + UI.vacio('No hay buses en ruta en este momento.') + '</li>'
    : f.buses.map((b) => {
      const senal = !b.tieneGps ? ['ambar', 'sinSenal', 'Sin GPS'] : b.lat === null ? ['ambar', 'sinSenal', 'Sin posición']
        : b.desactualizada ? ['ambar', 'sinSenal', 'Hace ' + fmt.hace(b.antiguedadSeg).replace('hace ', '')]
          : ['verde', 'senal', fmt.hace(b.antiguedadSeg)];
      return '<li class="item bus-flota" data-recorrido="' + b.recorridoId + '"><span class="icono-chip' + (b.desactualizada ? '' : ' oscuro') + '">' + icono('bus') + '</span>'
        + '<div class="item-cuerpo"><strong>' + UI.esc(b.placa) + ' · ' + UI.esc(b.ruta) + '</strong><small>' + UI.esc(b.conductor)
        + ' · en ruta desde ' + fmt.soloHora(b.inicio) + '</small><div class="acciones-bus">'
        + '<span class="insignia punto ' + (b.estado === 'EN_CURSO' ? 'verde' : 'ambar') + '">' + (b.estado === 'EN_CURSO' ? 'En curso' : 'Pausado') + '</span>'
        + '<span class="insignia ' + senal[0] + '">' + icono(senal[1]) + UI.esc(senal[2]) + '</span>'
        + '<span class="insignia">' + icono('usuarios') + b.abordajes + ' abordajes</span></div></div>'
        + '<button class="boton fantasma pequeno" data-finalizar="' + b.recorridoId + '" title="Finalizar recorrido">' + icono('detener') + '</button></li>';
    }).join('');
  $('lista-flota').querySelectorAll('[data-recorrido]').forEach((li) => li.addEventListener('click', (ev) => {
    if (ev.target.closest('[data-finalizar]')) return;
    const m = flota.marcadores.get(Number(li.dataset.recorrido));
    if (m) { flota.mapa.flyTo(m.getLatLng(), 16, { duration: .8 }); m.openTooltip(); }
  }));
  $('lista-flota').querySelectorAll('[data-finalizar]').forEach((b) => b.addEventListener('click', () => finalizarRecorridoAdmin(Number(b.dataset.finalizar))));

  $('novedades-flota').innerHTML = f.novedades.length === 0
    ? '<li>' + UI.vacio('Sin novedades reportadas hoy.') + '</li>'
    : f.novedades.map((n) => '<li class="item"><span class="icono-chip">' + icono(ICONO_NOVEDAD[n.novedad.tipo] || 'alerta') + '</span>'
      + '<div class="item-cuerpo"><strong>' + UI.esc(ETIQUETAS[n.novedad.tipo]) + ' · ' + UI.esc(n.ruta) + '</strong>'
      + '<small>' + (n.novedad.detalle ? UI.esc(n.novedad.detalle) + ' · ' : '') + 'Bus ' + UI.esc(n.novedad.placa) + ' · '
      + fmt.soloHora(n.novedad.reportadaEn) + ' · ' + n.pasajerosNotificados + ' notificado(s)</small></div></li>').join('');
}

async function dibujarRutasActivas(idsActivas) {
  for (const [id, capa] of flota.rutas) {
    if (!idsActivas.has(id)) { capa.remove(); flota.rutas.delete(id); }
  }
  for (const id of idsActivas) {
    if (flota.rutas.has(id)) continue;
    try {
      const ruta = await API.get('/api/rutas/' + id + '/mapa');
      const capa = L.layerGroup().addTo(flota.capaRutas);
      Mapa.dibujarTrazado(capa, ruta.trazado);
      ruta.paradas.forEach((p, i) => L.marker([p.lat, p.lng], { icon: Mapa.iconoParada({ extremo: i === 0 || i === ruta.paradas.length - 1 }) })
        .bindTooltip(ruta.nombre + ' · ' + p.nombre, { direction: 'top', offset: [0, -10] }).addTo(capa));
      flota.rutas.set(id, capa);
      flota.ajustado = false;
    } catch (e) { /* ruta no publicada: solo se muestra el bus */ }
  }
}

async function finalizarRecorridoAdmin(id) {
  const ok = await UI.confirmar({
    titulo: 'Finalizar recorrido', mensaje: 'Úsalo si el conductor no pudo cerrar el recorrido desde la terminal (por ejemplo, se apagó). El bus dejará de aparecer para los pasajeros.',
    aceptar: 'Finalizar recorrido', peligro: true, icono: 'detener',
  });
  if (!ok) return;
  try {
    await API.post('/api/admin/recorridos/' + id + '/finalizar');
    UI.toast('El recorrido quedó cerrado y registrado.', 'exito', 'Recorrido finalizado');
    refrescarFlota();
  } catch (e) {
    UI.error(e);
  }
}

function tarjetaKpi(k) {
  return '<div class="kpi' + (k.destacado ? ' destacado' : '') + '"><div class="entre"><span class="icono-chip">' + icono(k.icono) + '</span>'
    + (k.extra || '') + '</div><div class="valor">' + UI.esc(k.valor) + '</div><div class="etiqueta">' + UI.esc(k.etiqueta) + '</div></div>';
}

function pintarConflictos(contenedor, error) {
  const lista = (error.datos && error.datos.conflictos) || [];
  const ubicacion = (campo) => {
    const salida = /^salidas\[(\d+)\]$/.exec(campo || '');
    return salida ? 'Salida ' + (Number(salida[1]) + 1) + ': ' : '';
  };
  contenedor.innerHTML = '<div class="aviso rojo">' + icono('alerta') + '<div><strong>' + UI.esc(error.message) + '</strong>'
    + (lista.length ? '<ul>' + lista.map((c) => '<li>' + UI.esc(ubicacion(c.campo) + c.mensaje) + '</li>').join('') + '</ul>' : '')
    + '</div></div>';
}

// ---------- Reportes (RF-14) ----------

function aplicarRango(dias) {
  const hasta = new Date();
  const desde = new Date();
  desde.setDate(desde.getDate() - (dias - 1));
  $('rep-hasta').value = UI.fechaISO(hasta);
  $('rep-desde').value = UI.fechaISO(desde);
}

async function cargarReporte() {
  const r = await API.get('/api/admin/reportes/uso?desde=' + $('rep-desde').value + '&hasta=' + $('rep-hasta').value);
  const total = r.aprobados + r.denegados;
  $('kpis').innerHTML = [
    { etiqueta: 'Abordajes aprobados', valor: fmt.numero(r.aprobados), icono: 'usuarios', destacado: true },
    { etiqueta: 'Accesos denegados', valor: fmt.numero(r.denegados), icono: 'escudo' },
    { etiqueta: 'Recorridos realizados', valor: fmt.numero(r.indicadores.recorridosRealizados), icono: 'ruta' },
    { etiqueta: 'Registrados en contingencia', valor: fmt.numero(r.registradosEnContingencia), icono: 'sinSenal' },
    { etiqueta: 'Promedio diario de abordajes', valor: r.porDia.length ? fmt.numero(Math.round(total / r.porDia.length)) : '0', icono: 'grafica' },
  ].map(tarjetaKpi).join('');
  pintarIndicadores(r);

  $('rep-rutas').innerHTML = barrasHorizontales(r.porRuta.map((f) => ({ etiqueta: f.ruta, aprobados: f.aprobados, denegados: f.denegados })));
  $('rep-franjas').innerHTML = columnas(r.porFranja, (e) => e.slice(0, 2) + 'h', 3);
  $('rep-semana').innerHTML = columnas(r.porDiaSemana, (e) => e.slice(0, 3), 2);
  $('rep-dias').innerHTML = columnas(r.porDia, (e) => fmt.fechaCorta(e).replace('.', ''), 0, r.porDia.length > 16 ? 3 : 1);
}

/** Indicadores de la Tabla 6: los que el sistema puede medir, y los que requieren encuesta. */
function pintarIndicadores(r) {
  const i = r.indicadores;
  const medible = (titulo, valor, meta, detalle, quien) => {
    const cumple = valor >= meta;
    return '<div class="indicador"><div class="entre"><strong>' + UI.esc(titulo) + '</strong>'
      + '<span class="insignia ' + (cumple ? 'verde' : 'ambar') + '">' + (cumple ? 'Cumple' : 'En curso') + '</span></div>'
      + '<div class="valor">' + valor + ' %</div>'
      + '<div class="progreso' + (cumple ? ' cumple' : '') + '"><span style="width:' + Math.min(100, valor) + '%"></span><i class="meta" style="left:' + meta + '%"></i></div>'
      + '<small>Meta ≥ ' + meta + ' % · ' + UI.esc(detalle) + '</small><small><strong>Lo usa:</strong> ' + UI.esc(quien) + '</small></div>';
  };
  const pendiente = (titulo, meta, quien) => '<div class="indicador"><div class="entre"><strong>' + UI.esc(titulo) + '</strong>'
    + '<span class="insignia">Requiere encuesta</span></div><div class="valor" style="color:var(--gris-400)">—</div>'
    + '<small>Meta: ' + UI.esc(meta) + '. Se mide comparando una encuesta antes y después de implantar el sistema.</small>'
    + '<small><strong>Lo usa:</strong> ' + UI.esc(quien) + '</small></div>';
  $('indicadores').innerHTML = [
    medible('Abordajes validados electrónicamente', r.porcentajeLecturaAutomatica, 95,
      'lectura por QR, código de barras o NFC sobre el total', 'Registro y Control Académico'),
    medible('Adopción de la aplicación', i.adopcionApp, 60,
      i.portadoresConApp + ' de ' + i.portadoresDistintos + ' pasajeros que abordaron usan la app', 'Oficina de transporte'),
    '<div class="indicador"><div class="entre"><strong>Novedades que llegan al pasajero</strong>'
      + (i.novedadesDifundidas > 0 ? '<span class="insignia verde">Cumple</span>' : '<span class="insignia">Sin datos</span>') + '</div>'
      + '<div class="valor">' + fmt.numero(i.novedadesDifundidas) + ' <span style="font-size:.9rem;color:var(--texto-suave)">novedades</span></div>'
      + '<small>Meta ≥ 90 % en menos de 60 s. Se notificó a ' + fmt.numero(i.pasajerosNotificados)
      + ' pasajero(s); la app consulta los avisos cada 10 s.</small><small><strong>Lo usa:</strong> Empresa operadora</small></div>',
    pendiente('Reducción del tiempo de espera percibido', '≥ 30 % frente a la medición previa', 'Oficina de transporte'),
    pendiente('Salidas de ruta de Barrio perdidas', 'reducción ≥ 40 %', 'Oficina de transporte'),
  ].join('');
}

function barrasHorizontales(filas) {
  if (filas.length === 0) return UI.vacio('Sin abordajes en el periodo.');
  const max = Math.max(...filas.map((f) => f.aprobados + f.denegados));
  return filas.map((f) => '<div class="barra-h"><span class="nombre" title="' + UI.esc(f.etiqueta) + '">' + UI.esc(f.etiqueta) + '</span>'
    + '<span class="pista"><span class="relleno" style="width:' + (f.aprobados / max * 100) + '%"></span>'
    + '<span class="relleno denegado" style="width:' + (f.denegados / max * 100) + '%"></span></span>'
    + '<span class="num" title="' + f.denegados + ' denegados">' + fmt.numero(f.aprobados) + '</span></div>').join('');
}

function columnas(filas, etiqueta, resaltar, cadaCuantas = 1) {
  if (filas.length === 0) return UI.vacio('Sin abordajes en el periodo.');
  const max = Math.max(...filas.map((f) => f.aprobados));
  const umbral = resaltar ? [...filas].map((f) => f.aprobados).sort((a, b) => b - a)[Math.min(resaltar, filas.length) - 1] : Infinity;
  return filas.map((f, i) => '<div class="columna" title="' + UI.esc(f.etiqueta) + ': ' + f.aprobados + ' aprobados, ' + f.denegados + ' denegados">'
    + '<div class="barra' + (f.aprobados >= umbral ? ' alta' : '') + '" style="height:' + Math.max(3, f.aprobados / max * 100) + '%"><span>' + fmt.numero(f.aprobados) + '</span></div>'
    + '<small>' + (i % cadaCuantas === 0 ? UI.esc(etiqueta(f.etiqueta)) : '&nbsp;') + '</small></div>').join('');
}

// ---------- Rutas y horarios (RF-12) ----------

async function cargarRutas() {
  cerrarEditor();
  const rutas = (await API.get('/api/admin/rutas')).filter((r) => !filtroModalidad || r.modalidad === filtroModalidad);
  $('tabla-rutas').innerHTML = rutas.length === 0 ? '<tr><td colspan="7">' + UI.vacio('No hay rutas.') + '</td></tr>'
    : rutas.map((r) => '<tr><td><div style="display:flex;align-items:center;gap:.7rem"><span class="icono-chip' + (r.modalidad === 'CENTRO' ? ' oscuro' : '') + '">'
      + icono(r.modalidad === 'CENTRO' ? 'rayo' : 'pin') + '</span><strong>' + UI.esc(r.nombre) + '</strong></div></td>'
      + '<td><span class="insignia ' + (r.modalidad === 'CENTRO' ? 'oscuro' : 'rojo') + '">' + UI.esc(ETIQUETAS[r.modalidad]) + '</span></td>'
      + '<td class="num">' + r.paradas + '</td><td class="num">' + r.salidas + '</td><td>'
      + (r.activa ? '<span class="insignia punto ' + (r.publicada ? 'verde' : '') + '">' + (r.publicada ? 'Publicada' : 'Borrador') + '</span>'
        : '<span class="insignia punto rojo">Inactiva</span>') + '</td>'
      + '<td class="tenue">' + UI.esc(fmt.fechaHora(r.ultimaPublicacion)) + '</td>'
      + '<td><div class="acciones"><button class="boton pequeno" data-editar="' + r.id + '">' + icono('lapiz') + 'Editar</button>'
      + '<button class="boton pequeno fantasma" data-activa="' + r.id + '" data-valor="' + !r.activa + '">' + (r.activa ? 'Desactivar' : 'Activar') + '</button></div></td></tr>').join('');
  $('tabla-rutas').querySelectorAll('[data-editar]').forEach((b) => b.addEventListener('click', () => abrirEditor(Number(b.dataset.editar))));
  $('tabla-rutas').querySelectorAll('[data-activa]').forEach((b) => b.addEventListener('click', async () => {
    await API.patch('/api/admin/rutas/' + b.dataset.activa + '/activa?valor=' + b.dataset.valor).catch(UI.error);
    cargarRutas();
  }));
}

function cerrarEditor() {
  $('editor').hidden = true;
  $('lista-rutas-panel').hidden = false;
}

async function abrirEditor(id) {
  const r = id ? await API.get('/api/admin/rutas/' + id) : {
    id: null, nombre: '', modalidad: 'BARRIO', descripcion: '', duracionEstimadaMin: 45, publicada: false, trazado: [], paradas: [], salidas: [],
  };
  ed = {
    id: r.id, modalidad: r.modalidad, modoMapa: 'paradas', publicada: r.publicada,
    trazado: r.trazado.map((c) => ({ lat: c.lat, lng: c.lng })),
    paradas: r.paradas.map((p) => ({ nombre: p.nombre, lat: p.lat, lng: p.lng })),
    salidas: r.salidas.map((s) => ({ ...s })),
  };
  $('titulo-seccion').textContent = id ? 'Editar ruta' : 'Nueva ruta';
  $('subtitulo-seccion').textContent = id ? r.nombre : 'Agrega las paradas sobre el mapa y luego traza el recorrido por las vías.';
  $('insignia-editor').className = 'insignia punto ' + (r.publicada ? 'verde' : '');
  $('insignia-editor').textContent = r.publicada ? 'Publicada' : 'Sin publicar';
  $('ed-nombre').value = r.nombre;
  $('ed-modalidad').value = r.modalidad;
  $('ed-descripcion').value = r.descripcion || '';
  $('ed-duracion').value = r.duracionEstimadaMin;
  $('ed-publicar').checked = true;
  $('ed-publicar').disabled = r.publicada;
  $('ed-vigente').value = '';
  $('conflictos').innerHTML = '';
  marcarCampos([]);
  document.querySelectorAll('#modo-mapa button').forEach((x) => x.classList.toggle('activa', x.dataset.modo === 'paradas'));
  $('lista-rutas-panel').hidden = true;
  $('editor').hidden = false;

  if (!mapaEditor) {
    mapaEditor = Mapa.crear('mapa-editor');
    mapaEditor.on('click', (ev) => {
      const punto = { lat: +ev.latlng.lat.toFixed(6), lng: +ev.latlng.lng.toFixed(6) };
      if (ed.modoMapa === 'trazado') {
        ed.trazado.push(punto);
      } else {
        leerParadas();
        ed.paradas.push({ nombre: 'Parada ' + (ed.paradas.length + 1), ...punto });
      }
      pintarMapaEditor(false);
    });
  }
  setTimeout(() => { mapaEditor.invalidateSize(); pintarMapaEditor(true); }, 60);
  pintarSalidas();
}

function pintarMapaEditor(ajustar) {
  if (capaEditor) capaEditor.remove();
  capaEditor = L.layerGroup().addTo(mapaEditor);
  const limites = [];
  if (ed.trazado.length >= 2) {
    const linea = Mapa.dibujarTrazado(capaEditor, ed.trazado);
    limites.push(linea.getBounds());
  }
  if (ed.modoMapa === 'trazado') {
    ed.trazado.forEach((c) => L.marker([c.lat, c.lng], { icon: Mapa.iconoPunto(), interactive: false }).addTo(capaEditor));
  }
  ed.paradas.forEach((p, i) => {
    const marcador = L.marker([p.lat, p.lng], {
      icon: Mapa.iconoParada({ extremo: i === 0 || i === ed.paradas.length - 1 }), draggable: true, zIndexOffset: 500,
    }).bindTooltip((i + 1) + '. ' + p.nombre, { direction: 'top', offset: [0, -10] }).addTo(capaEditor);
    marcador.on('dragend', () => {
      const pos = marcador.getLatLng();
      leerParadas();
      ed.paradas[i].lat = +pos.lat.toFixed(6);
      ed.paradas[i].lng = +pos.lng.toFixed(6);
      pintarMapaEditor(false);
    });
    limites.push(L.latLngBounds([[p.lat, p.lng]]));
  });
  if (ajustar && limites.length) {
    const total = limites.reduce((a, b) => a.extend(b), L.latLngBounds(limites[0].getSouthWest(), limites[0].getNorthEast()));
    mapaEditor.fitBounds(total, { paddingTopLeft: [50, 120], paddingBottomRight: [60, 80] });
  }
  $('info-trazado').textContent = ed.paradas.length + ' parada(s) · ' + ed.trazado.length + ' punto(s) de trazado'
    + (ed.modoMapa === 'paradas' ? ' · clic para agregar parada, arrastra para mover' : ' · clic para agregar punto');
  pintarParadas();
}

function pintarParadas() {
  $('lista-paradas').innerHTML = ed.paradas.length === 0
    ? UI.vacio('Haz clic en el mapa para agregar la primera parada.')
    : ed.paradas.map((p, i) => '<div class="parada-editor"><span class="numero">' + (i + 1) + '</span>'
      + '<input class="control" data-parada="' + i + '" value="' + UI.esc(p.nombre) + '" maxlength="80" aria-label="Nombre de la parada ' + (i + 1) + '">'
      + '<button class="boton fantasma icono-solo pequeno" type="button" data-subir="' + i + '" title="Subir"' + (i === 0 ? ' disabled' : '') + '>' + icono('subir') + '</button>'
      + '<button class="boton fantasma icono-solo pequeno" type="button" data-quitar="' + i + '" title="Quitar">' + icono('basura') + '</button></div>').join('');
  $('lista-paradas').querySelectorAll('[data-quitar]').forEach((b) => b.addEventListener('click', () => {
    leerParadas(); ed.paradas.splice(Number(b.dataset.quitar), 1); pintarMapaEditor(false);
  }));
  $('lista-paradas').querySelectorAll('[data-subir]').forEach((b) => b.addEventListener('click', () => {
    const i = Number(b.dataset.subir);
    leerParadas();
    [ed.paradas[i - 1], ed.paradas[i]] = [ed.paradas[i], ed.paradas[i - 1]];
    pintarMapaEditor(false);
  }));
}

function leerParadas() {
  document.querySelectorAll('[data-parada]').forEach((input) => { ed.paradas[Number(input.dataset.parada)].nombre = input.value.trim(); });
}

async function trazarPorVias() {
  leerParadas();
  const puntos = ed.paradas.length >= 2 ? ed.paradas : ed.trazado;
  if (puntos.length < 2) {
    UI.toast('Agrega al menos dos paradas en el mapa para trazar el recorrido.', 'error');
    return;
  }
  const boton = $('btn-trazar-vias');
  boton.disabled = true;
  try {
    const r = await API.post('/api/admin/rutas/trazar-por-vias', { puntos: puntos.map((p) => ({ lat: p.lat, lng: p.lng })) });
    ed.trazado = r.trazado;
    if (ed.paradas.length >= 2) {
      // Cada parada se ubica sobre la vía más cercana.
      r.puntosAjustados.forEach((c, i) => { ed.paradas[i].lat = c.lat; ed.paradas[i].lng = c.lng; });
    }
    $('ed-duracion').value = r.duracionEstimadaMin;
    pintarMapaEditor(true);
    UI.toast(r.distanciaKm + ' km · duración estimada ' + r.duracionEstimadaMin + ' min. Las paradas se ubicaron sobre la vía.', 'exito', 'Recorrido trazado por las vías');
  } catch (e) {
    UI.error(e);
  } finally {
    boton.disabled = false;
  }
}

function salidaVacia() {
  return ed.modalidad === 'CENTRO'
    ? { tipoDia: 'HABIL', tipo: 'FRECUENCIA', horaInicio: '06:00', horaFin: '18:00', frecuenciaMinutos: 20 }
    : { tipoDia: 'HABIL', tipo: 'PUNTUAL', horaInicio: '06:00', horaFin: null, frecuenciaMinutos: null };
}

function convertirSalida(s) {
  return ed.modalidad === 'CENTRO'
    ? { ...s, tipo: 'FRECUENCIA', horaFin: s.horaFin || '18:00', frecuenciaMinutos: s.frecuenciaMinutos || 20 }
    : { ...s, tipo: 'PUNTUAL', horaFin: null, frecuenciaMinutos: null };
}

function pintarSalidas() {
  const centro = ed.modalidad === 'CENTRO';
  $('ayuda-salidas').textContent = centro ? 'Franja de operación y frecuencia' : 'Horarios puntuales de salida';
  $('cabecera-salidas').innerHTML = '<tr><th>Día</th><th>' + (centro ? 'Inicio' : 'Hora') + '</th>'
    + (centro ? '<th>Fin</th><th>Cada (min)</th>' : '') + '<th></th></tr>';
  $('tabla-salidas').innerHTML = ed.salidas.length === 0 ? '<tr><td colspan="5">' + UI.vacio('Agrega la primera salida.') + '</td></tr>'
    : ed.salidas.map((s, i) => '<tr data-fila="' + i + '">'
      + '<td><select class="control" data-k="tipoDia"><option value="HABIL"' + (s.tipoDia === 'HABIL' ? ' selected' : '') + '>Hábil</option>'
      + '<option value="SABADO"' + (s.tipoDia === 'SABADO' ? ' selected' : '') + '>Sábado</option></select></td>'
      + '<td><input class="control" type="time" data-k="horaInicio" value="' + fmt.hora(s.horaInicio) + '"></td>'
      + (centro ? '<td><input class="control" type="time" data-k="horaFin" value="' + fmt.hora(s.horaFin) + '"></td>'
        + '<td><input class="control" type="number" min="1" max="180" data-k="frecuenciaMinutos" value="' + (s.frecuenciaMinutos || '') + '"></td>' : '')
      + '<td><button class="boton fantasma icono-solo pequeno" type="button" data-quitar-salida="' + i + '" title="Quitar">' + icono('basura') + '</button></td></tr>').join('');
  $('tabla-salidas').querySelectorAll('[data-quitar-salida]').forEach((b) => b.addEventListener('click', () => {
    leerSalidas(); ed.salidas.splice(Number(b.dataset.quitarSalida), 1); pintarSalidas();
  }));
}

function leerSalidas() {
  ed.salidas = [...document.querySelectorAll('#tabla-salidas tr[data-fila]')].map((tr) => {
    const v = (k) => { const el = tr.querySelector('[data-k="' + k + '"]'); return el ? el.value : null; };
    const centro = ed.modalidad === 'CENTRO';
    return {
      tipoDia: v('tipoDia'),
      tipo: centro ? 'FRECUENCIA' : 'PUNTUAL',
      horaInicio: v('horaInicio') || null,
      horaFin: centro ? (v('horaFin') || null) : null,
      frecuenciaMinutos: centro && v('frecuenciaMinutos') ? Number(v('frecuenciaMinutos')) : null,
    };
  });
}

function cuerpoRuta() {
  leerParadas();
  leerSalidas();
  return {
    nombre: $('ed-nombre').value.trim(),
    modalidad: $('ed-modalidad').value,
    descripcion: $('ed-descripcion').value.trim(),
    duracionEstimadaMin: Number($('ed-duracion').value) || null,
    trazado: ed.trazado,
    paradas: ed.paradas.map((p, i) => ({ nombre: p.nombre, orden: i + 1, lat: p.lat, lng: p.lng })),
    salidas: ed.salidas,
    publicar: $('ed-publicar').checked,
    vigenteDesde: $('ed-vigente').value ? $('ed-vigente').value + ':00' : null,
  };
}

function marcarCampos(conflictos) {
  document.querySelectorAll('#editor .error').forEach((c) => c.classList.remove('error'));
  conflictos.forEach((c) => {
    const salida = /^salidas\[(\d+)\]$/.exec(c.campo || '');
    if (salida) {
      const tr = document.querySelector('#tabla-salidas tr[data-fila="' + salida[1] + '"]');
      if (tr) tr.classList.add('error');
      return;
    }
    const campo = document.querySelector('#editor [data-campo="' + c.campo + '"]');
    if (campo) campo.classList.add('error');
  });
}

async function validarRuta() {
  try {
    const r = await API.post('/api/admin/rutas/validar' + (ed.id ? '?id=' + ed.id : ''), cuerpoRuta());
    marcarCampos(r.conflictos);
    if (r.conflictos.length === 0) {
      $('conflictos').innerHTML = '<div class="aviso verde">' + icono('checkCirculo') + '<span>La información está completa y sin solapamientos. Puedes guardar y publicar.</span></div>';
    } else {
      pintarConflictos($('conflictos'), { message: 'Corrige los campos señalados antes de publicar', datos: r });
    }
    $('conflictos').scrollIntoView({ behavior: 'smooth', block: 'center' });
  } catch (e) {
    UI.error(e);
  }
}

async function guardarRuta() {
  try {
    const cuerpo = cuerpoRuta();
    const r = ed.id ? await API.put('/api/admin/rutas/' + ed.id, cuerpo) : await API.post('/api/admin/rutas', cuerpo);
    if (r.urgente) {
      UI.toast('Se notificó a ' + r.pasajerosNotificados + ' pasajero(s) con recordatorios activos.', 'exito', 'Cambio urgente publicado', 7000);
    } else {
      UI.toast(r.ruta.publicada ? 'La programación ya está disponible para los pasajeros.' : 'La ruta quedó guardada como borrador.', 'exito',
        r.ruta.publicada ? 'Ruta publicada' : 'Borrador guardado');
    }
    abrirSeccion('rutas');
  } catch (e) {
    // 8a: información incompleta o turnos solapados.
    if (e.datos && e.datos.conflictos) marcarCampos(e.datos.conflictos);
    pintarConflictos($('conflictos'), e);
    $('conflictos').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

// ---------- Turnos (RF-13) ----------

let turnosCargados = [];

async function cargarTurnos() {
  const [turnos, rutas, conductores, vehiculos] = await Promise.all([
    API.get('/api/admin/turnos'), API.get('/api/admin/rutas'), API.get('/api/admin/conductores'), API.get('/api/admin/vehiculos'),
  ]);
  turnosCargados = turnos;
  $('tu-ruta').innerHTML = rutas.map((r) => '<option value="' + r.id + '">' + UI.esc(r.nombre) + '</option>').join('');
  $('tu-conductor').innerHTML = conductores.filter((c) => c.activo).map((c) => '<option value="' + c.id + '">' + UI.esc(c.nombre) + '</option>').join('');
  $('tu-vehiculo').innerHTML = vehiculos.filter((v) => v.activo).map((v) => '<option value="' + v.id + '">' + UI.esc(v.placa)
    + (v.tieneGps ? '' : ' (sin GPS)') + '</option>').join('');
  $('tabla-turnos').innerHTML = turnos.length === 0 ? '<tr><td colspan="6">' + UI.vacio('Sin turnos asignados.') + '</td></tr>'
    : turnos.map((x) => '<tr' + (turnoEditando === x.id ? ' style="background:var(--rojo-50)"' : '') + '><td><strong>' + UI.esc(x.ruta) + '</strong></td>'
      + '<td><div style="display:flex;align-items:center;gap:.6rem"><span class="avatar" style="width:30px;height:30px;font-size:.7rem">' + UI.esc(UI.iniciales(x.conductor)) + '</span>' + UI.esc(x.conductor) + '</div></td>'
      + '<td><span class="insignia">' + icono('bus') + UI.esc(x.placa) + '</span></td>'
      + '<td>' + UI.esc(ETIQUETAS[x.tipoDia]) + '</td><td class="num">' + fmt.hora(x.horaInicio) + ' – ' + fmt.hora(x.horaFin) + '</td>'
      + '<td><div class="acciones"><button class="boton pequeno" data-editar-turno="' + x.id + '">' + icono('lapiz') + 'Modificar</button>'
      + '<button class="boton fantasma pequeno" data-eliminar="' + x.id + '">' + icono('basura') + 'Eliminar</button></div></td></tr>').join('');
  $('tabla-turnos').querySelectorAll('[data-editar-turno]').forEach((b) => b.addEventListener('click', () => editarTurno(Number(b.dataset.editarTurno))));
  $('tabla-turnos').querySelectorAll('[data-eliminar]').forEach((b) => b.addEventListener('click', async () => {
    const ok = await UI.confirmar({ titulo: 'Eliminar turno', mensaje: '¿Eliminar este turno? El conductor dejará de verlo en su terminal.', aceptar: 'Eliminar', peligro: true, icono: 'basura' });
    if (!ok) return;
    await API.del('/api/admin/turnos/' + b.dataset.eliminar).catch(UI.error);
    cargarTurnos();
  }));
}

function editarTurno(id) {
  const x = turnosCargados.find((t) => t.id === id);
  turnoEditando = id;
  $('tu-ruta').value = x.rutaId;
  $('tu-conductor').value = x.conductorId;
  $('tu-vehiculo').value = x.vehiculoId;
  $('tu-dia').value = x.tipoDia;
  $('tu-inicio').value = fmt.hora(x.horaInicio);
  $('tu-fin').value = fmt.hora(x.horaFin);
  $('titulo-form-turno').textContent = 'Modificar turno · ' + x.ruta;
  $('btn-guardar-turno').querySelector('span:last-child').textContent = 'Guardar cambios';
  $('btn-cancelar-turno').hidden = false;
  $('conflictos-turno').innerHTML = '';
  $('form-turno').scrollIntoView({ behavior: 'smooth', block: 'start' });
  cargarTurnosSinPerderFormulario();
}

async function cargarTurnosSinPerderFormulario() {
  const valores = ['tu-ruta', 'tu-conductor', 'tu-vehiculo'].map((id) => $(id).value);
  await cargarTurnos();
  ['tu-ruta', 'tu-conductor', 'tu-vehiculo'].forEach((id, i) => { $(id).value = valores[i]; });
}

function salirDeEdicionTurno() {
  turnoEditando = null;
  $('titulo-form-turno').textContent = 'Asignar turno';
  $('btn-guardar-turno').querySelector('span:last-child').textContent = 'Asignar';
  $('btn-cancelar-turno').hidden = true;
  $('conflictos-turno').innerHTML = '';
  cargarTurnos();
}

async function guardarTurno(ev) {
  ev.preventDefault();
  $('conflictos-turno').innerHTML = '';
  const cuerpo = {
    rutaId: Number($('tu-ruta').value), conductorId: Number($('tu-conductor').value), vehiculoId: Number($('tu-vehiculo').value),
    tipoDia: $('tu-dia').value, horaInicio: $('tu-inicio').value, horaFin: $('tu-fin').value,
  };
  try {
    if (turnoEditando) {
      await API.put('/api/admin/turnos/' + turnoEditando, cuerpo);
      UI.toast('El conductor verá la asignación actualizada en su terminal.', 'exito', 'Turno modificado');
      salirDeEdicionTurno();
    } else {
      await API.post('/api/admin/turnos', cuerpo);
      UI.toast('El conductor ya puede verlo en su terminal.', 'exito', 'Turno asignado');
      cargarTurnos();
    }
  } catch (e) {
    pintarConflictos($('conflictos-turno'), e);
  }
}

// ---------- Vehículos ----------

async function cargarVehiculos() {
  const lista = await API.get('/api/admin/vehiculos');
  const interruptor = (v, campo, texto) => '<label class="interruptor"><input type="checkbox" data-vehiculo="' + v.id + '" data-campo="' + campo + '"'
    + (v[campo] ? ' checked' : '') + '><span class="pista"></span>' + texto + '</label>';
  $('tabla-vehiculos').innerHTML = lista.map((v) => '<div class="tarjeta" style="' + (v.activo ? '' : 'opacity:.6') + '"><div class="entre">'
    + '<div style="display:flex;gap:.8rem;align-items:center"><span class="icono-chip oscuro" style="width:44px;height:44px">' + icono('bus') + '</span>'
    + '<div><strong style="font-size:1.1rem;letter-spacing:.04em">' + UI.esc(v.placa) + '</strong><br><small class="tenue">'
    + UI.esc(v.descripcion || 'Sin descripción') + '</small></div></div>'
    + '<span class="insignia punto ' + (v.activo ? 'verde' : '') + '">' + (v.activo ? 'En servicio' : 'Fuera de servicio') + '</span></div>'
    + '<div class="pila compacta" style="margin-top:1rem">' + interruptor(v, 'tieneGps', 'Dispositivo GPS')
    + interruptor(v, 'tieneLector', 'Lector de carnet') + interruptor(v, 'activo', 'Disponible para turnos') + '</div></div>').join('');
  $('tabla-vehiculos').querySelectorAll('[data-vehiculo]').forEach((input) => input.addEventListener('change', async () => {
    const v = lista.find((x) => x.id === Number(input.dataset.vehiculo));
    const cambio = { ...v, [input.dataset.campo]: input.checked };
    try {
      await API.put('/api/admin/vehiculos/' + v.id, {
        descripcion: cambio.descripcion, tieneGps: cambio.tieneGps, tieneLector: cambio.tieneLector, activo: cambio.activo,
      });
      UI.toast('Vehículo ' + v.placa + ' actualizado.', 'exito');
    } catch (e) {
      UI.error(e);
    }
    cargarVehiculos();
  }));
}

// ---------- Conductores ----------

async function cargarConductores() {
  const [conductores, turnos] = await Promise.all([API.get('/api/admin/conductores'), API.get('/api/admin/turnos')]);
  $('lista-conductores').innerHTML = conductores.length === 0 ? UI.vacio('No hay conductores registrados.')
    : conductores.map((c) => {
      const suyos = turnos.filter((t) => t.conductorId === c.id).length;
      return '<div class="tarjeta" style="' + (c.activo ? '' : 'opacity:.6') + '"><div class="entre">'
        + '<div style="display:flex;gap:.8rem;align-items:center"><span class="avatar" style="width:46px;height:46px">' + UI.esc(UI.iniciales(c.nombre)) + '</span>'
        + '<div><strong>' + UI.esc(c.nombre) + '</strong><br><small class="tenue">@' + UI.esc(c.username) + (c.documento ? ' · CC ' + UI.esc(c.documento) : '') + '</small></div></div>'
        + '<span class="insignia punto ' + (c.activo ? 'verde' : '') + '">' + (c.activo ? 'Activo' : 'Inactivo') + '</span></div>'
        + '<div class="entre" style="margin-top:1rem"><span class="insignia">' + icono('calendario') + suyos + ' turno(s)</span>'
        + '<button class="boton pequeno ' + (c.activo ? 'fantasma' : '') + '" data-conductor="' + c.id + '" data-valor="' + !c.activo + '">'
        + (c.activo ? 'Desactivar' : 'Activar') + '</button></div></div>';
    }).join('');
  $('lista-conductores').querySelectorAll('[data-conductor]').forEach((b) => b.addEventListener('click', async () => {
    if (b.dataset.valor === 'false') {
      const ok = await UI.confirmar({ titulo: 'Desactivar conductor', mensaje: 'No podrá iniciar sesión en la terminal ni recibir nuevos turnos.', aceptar: 'Desactivar', peligro: true, icono: 'usuario' });
      if (!ok) return;
    }
    await API.patch('/api/admin/conductores/' + b.dataset.conductor + '/activo?valor=' + b.dataset.valor).catch(UI.error);
    cargarConductores();
  }));
}

async function crearConductor(ev) {
  ev.preventDefault();
  $('conflictos-conductor').innerHTML = '';
  try {
    const c = await API.post('/api/admin/conductores', {
      nombre: $('co-nombre').value.trim(), documento: $('co-documento').value.trim(),
      username: $('co-usuario').value.trim(), clave: $('co-clave').value,
    });
    ev.target.reset();
    UI.toast('Ya puede ingresar a la terminal como «' + c.username + '» y recibir turnos.', 'exito', 'Conductor registrado');
    cargarConductores();
  } catch (e) {
    pintarConflictos($('conflictos-conductor'), e);
  }
}

async function crearVehiculo(ev) {
  ev.preventDefault();
  try {
    await API.post('/api/admin/vehiculos', {
      placa: $('ve-placa').value.trim(), descripcion: $('ve-descripcion').value.trim(),
      tieneGps: $('ve-gps').checked, tieneLector: $('ve-lector').checked,
    });
    ev.target.reset();
    UI.toast('El vehículo ya puede asignarse a turnos.', 'exito', 'Vehículo registrado');
    cargarVehiculos();
  } catch (e) {
    UI.error(e);
  }
}

// ---------- Accesos denegados ----------

async function actualizarContadorDenegados() {
  const lista = await API.get('/api/admin/accesos-denegados').catch(() => []);
  $('contador-denegados').hidden = lista.length === 0;
  $('contador-denegados').textContent = lista.length > 99 ? '99+' : lista.length;
  return lista;
}

async function cargarDenegados() {
  const lista = await actualizarContadorDenegados();
  $('tabla-denegados').innerHTML = lista.length === 0 ? '<tr><td colspan="8">' + UI.vacio('No hay accesos denegados pendientes.') + '</td></tr>'
    : lista.map((a) => '<tr><td class="tenue">' + UI.esc(fmt.fechaHora(a.fechaHora)) + '</td><td>' + UI.esc(a.ruta) + '</td>'
      + '<td><span class="insignia">' + UI.esc(a.placa) + '</span></td><td class="num">' + UI.esc(a.identificador) + '</td>'
      + '<td>' + UI.esc(a.nombre || '—') + '</td><td><span class="insignia rojo">' + UI.esc(a.motivo || '') + '</span></td>'
      + '<td>' + UI.esc(ETIQUETAS[a.modo]) + '</td>'
      + '<td><div class="acciones"><button class="boton pequeno" data-revisar="' + a.id + '">' + icono('check') + 'Revisado</button></div></td></tr>').join('');
  $('tabla-denegados').querySelectorAll('[data-revisar]').forEach((b) => b.addEventListener('click', async () => {
    await API.post('/api/admin/accesos-denegados/' + b.dataset.revisar + '/revisado').catch(UI.error);
    cargarDenegados();
  }));
}

// ---------- Sistema académico (simulación de disponibilidad) ----------

async function cargarSistemaAcademico() {
  pintarSistemaAcademico(await API.get('/api/admin/sistema-academico'));
}

function pintarSistemaAcademico(estadoSa) {
  $('estado-sistema').classList.toggle('caido', !estadoSa.disponible);
  $('estado-sa').textContent = estadoSa.disponible ? 'Sistema Académico disponible' : 'Sistema Académico no disponible (simulado)';
  $('btn-sa').innerHTML = estadoSa.disponible ? icono('sinSenal') + 'Simular caída' : icono('senal') + 'Restablecer';
  $('btn-sa').className = 'boton grande ' + (estadoSa.disponible ? 'primario' : 'exito');
  $('btn-sa').dataset.disponible = estadoSa.disponible;
}

async function alternarSistemaAcademico() {
  const nuevo = $('btn-sa').dataset.disponible !== 'true';
  pintarSistemaAcademico(await API.put('/api/admin/sistema-academico', { disponible: nuevo }));
}
