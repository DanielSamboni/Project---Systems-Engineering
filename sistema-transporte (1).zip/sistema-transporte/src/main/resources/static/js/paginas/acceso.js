'use strict';

/* «include» Iniciar Sesión */

(async () => {
  const res = await fetch('/api/auth/yo', { credentials: 'same-origin' });
  if (res.ok) {
    const yo = await res.json();
    location.replace(Sesion.DESTINO_POR_ROL[yo.rol]);
  }
})();

document.addEventListener('DOMContentLoaded', () => {
  $('form-login').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const boton = $('btn-ingresar');
    $('error').hidden = true;
    if (!$('usuario').value.trim() || !$('clave').value) {
      mostrarError('Ingrese su usuario y contraseña.');
      return;
    }
    boton.disabled = true;
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', body: new URLSearchParams(new FormData(ev.target)), credentials: 'same-origin',
      });
      const datos = await res.json().catch(() => ({}));
      if (!res.ok) {
        mostrarError(datos.mensaje || 'No fue posible iniciar sesión.');
        return;
      }
      location.replace(Sesion.DESTINO_POR_ROL[datos.rol]);
    } catch (e) {
      mostrarError('No hay conexión con el servidor.');
    } finally {
      boton.disabled = false;
    }
  });
});

function mostrarError(texto) {
  $('error-texto').textContent = texto;
  $('error').hidden = false;
}
