'use strict';

/* Utilidades del mapa (Leaflet): capas base, trazado de la ruta y marcadores. */

const Mapa = {
  CENTRO_VILLAVICENCIO: [4.12, -73.62],
  ERRORES_ANTES_DE_RESPALDO: 4,

  crear(id, { oscuro = false, zoomInicial = 13 } = {}) {
    const contenedor = $(id);
    contenedor.classList.add('mapa');
    if (oscuro) contenedor.classList.add('oscuro');
    const mapa = L.map(id, { zoomControl: false, attributionControl: true }).setView(this.CENTRO_VILLAVICENCIO, zoomInicial);
    L.control.zoom({ position: 'bottomright' }).addTo(mapa);
    this.agregarCapaBase(mapa, oscuro);
    return mapa;
  },

  /**
   * Capa base de Stadia Maps (estilo limpio; sin clave en localhost). Si falla, por ejemplo al publicar
   * la aplicación en otro dominio sin clave, se usa automáticamente la capa estándar de OpenStreetMap.
   */
  agregarCapaBase(mapa, oscuro) {
    const estilo = oscuro ? 'alidade_smooth_dark' : 'alidade_smooth';
    const principal = L.tileLayer('https://tiles.stadiamaps.com/tiles/' + estilo + '/{z}/{x}/{y}{r}.png', {
      maxZoom: 20,
      attribution: '&copy; <a href="https://stadiamaps.com/">Stadia Maps</a> &copy; <a href="https://openmaptiles.org/">OpenMapTiles</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(mapa);
    let errores = 0;
    principal.on('tileerror', () => {
      if (++errores !== this.ERRORES_ANTES_DE_RESPALDO) return;
      mapa.removeLayer(principal);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, className: oscuro ? 'mosaico-oscuro' : '',
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(mapa);
    });
  },

  /** Dibuja la ruta con borde (casing) para que resalte sobre el mapa. Devuelve la capa del trazado. */
  dibujarTrazado(capa, trazado, { oscuro = false } = {}) {
    const puntos = trazado.map((c) => [c.lat, c.lng]);
    L.polyline(puntos, { color: oscuro ? '#000000' : '#ffffff', weight: 10, opacity: oscuro ? 0.6 : 0.95, lineJoin: 'round', lineCap: 'round' }).addTo(capa);
    return L.polyline(puntos, { color: '#e11d38', weight: 5, opacity: 1, lineJoin: 'round', lineCap: 'round' }).addTo(capa);
  },

  iconoParada({ elegida = false, extremo = false } = {}) {
    const clase = 'parada' + (elegida ? ' elegida' : '') + (extremo && !elegida ? ' extremo' : '');
    const tam = elegida ? 22 : extremo ? 20 : 16;
    return L.divIcon({ className: 'parada-marcador', html: '<div class="' + clase + '"></div>', iconSize: [tam, tam], iconAnchor: [tam / 2, tam / 2] });
  },

  iconoBus(placa, desactualizado) {
    return L.divIcon({
      className: 'bus-marcador',
      html: '<div class="bus' + (desactualizado ? ' desactualizado' : '') + '">' + icono('bus') + UI.esc(placa) + '</div>',
      iconSize: [0, 0],
    });
  },

  iconoPunto() {
    return L.divIcon({ className: '', html: '<div class="punto-trazado"></div>', iconSize: [10, 10], iconAnchor: [5, 5] });
  },
};
