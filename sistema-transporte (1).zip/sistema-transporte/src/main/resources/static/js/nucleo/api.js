'use strict';

/* Cliente HTTP de la API REST y manejo de la sesión del usuario. */

class ApiError extends Error {
  constructor(status, mensaje, datos) {
    super(mensaje);
    this.status = status;
    this.datos = datos || {};
  }
}

const API = {
  async request(metodo, url, cuerpo) {
    const opciones = { method: metodo, headers: {}, credentials: 'same-origin' };
    if (cuerpo !== undefined) {
      opciones.headers['Content-Type'] = 'application/json';
      opciones.body = JSON.stringify(cuerpo);
    }
    const res = await fetch(url, opciones);
    if (res.status === 401) {
      location.href = '/index.html';
      throw new ApiError(401, 'La sesión expiró');
    }
    if (res.status === 403) {
      // Ocurre si en este mismo navegador se inició sesión con otro usuario: la cookie de sesión es compartida.
      await Sesion.verificarCambioDeUsuario();
      throw new ApiError(403, 'Su perfil no tiene permiso para esta acción.');
    }
    if (res.status === 204) return null;
    const tipo = res.headers.get('content-type') || '';
    const datos = tipo.includes('application/json') ? await res.json() : null;
    if (!res.ok) {
      throw new ApiError(res.status, (datos && datos.mensaje) || 'Error inesperado (' + res.status + ')', datos);
    }
    return datos;
  },
  get: (url) => API.request('GET', url),
  post: (url, cuerpo) => API.request('POST', url, cuerpo === undefined ? {} : cuerpo),
  put: (url, cuerpo) => API.request('PUT', url, cuerpo === undefined ? {} : cuerpo),
  patch: (url) => API.request('PATCH', url),
  del: (url) => API.request('DELETE', url),
};

const Sesion = {
  DESTINO_POR_ROL: { PASAJERO: '/pasajero.html', CONDUCTOR: '/conductor.html', ADMINISTRADOR: '/admin.html' },
  rolDeLaPantalla: null,
  usuario: null,

  /** Exige un usuario con el rol de la pantalla; pinta su nombre y conecta el botón de salir. */
  async requerir(rolEsperado) {
    this.rolDeLaPantalla = rolEsperado;
    const yo = await API.get('/api/auth/yo');
    if (yo.rol !== rolEsperado) {
      location.href = this.DESTINO_POR_ROL[yo.rol];
      throw new Error('Rol no autorizado para esta pantalla');
    }
    this.usuario = yo;
    document.querySelectorAll('[data-usuario-nombre]').forEach((el) => { el.textContent = yo.nombre; });
    document.querySelectorAll('[data-usuario-iniciales]').forEach((el) => { el.textContent = UI.iniciales(yo.nombre); });
    document.querySelectorAll('[data-salir]').forEach((el) => el.addEventListener('click', () => this.cerrar()));
    return yo;
  },

  async cerrar() {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    location.href = '/index.html';
  },

  async verificarCambioDeUsuario() {
    const res = await fetch('/api/auth/yo', { credentials: 'same-origin' });
    if (!res.ok) {
      location.href = '/index.html';
      return;
    }
    const yo = await res.json();
    if (this.rolDeLaPantalla && yo.rol !== this.rolDeLaPantalla) {
      await UI.confirmar({
        titulo: 'La sesión cambió de usuario',
        mensaje: 'En este navegador se inició sesión como «' + yo.nombre + '», por eso esta pantalla perdió su sesión.\n\n'
          + 'Para usar dos usuarios a la vez, abra el segundo en una ventana de incógnito o en otro navegador.',
        aceptar: 'Ir a mi pantalla', soloAceptar: true, icono: 'usuarios',
      });
      location.href = this.DESTINO_POR_ROL[yo.rol];
    }
  },
};
