'use strict';

/* Utilidades de interfaz: escape de HTML, formatos, notificaciones y diálogos. */

const $ = (id) => document.getElementById(id);

const ETIQUETAS = {
  CENTRO: 'Centro', BARRIO: 'Barrio', HABIL: 'Días hábiles', SABADO: 'Sábados',
  RETRASO: 'Retraso', CONGESTION: 'Congestión', ACCIDENTE: 'Accidente', VARADA: 'Varada',
  EN_CURSO: 'En curso', PAUSADO: 'Pausado', FINALIZADO: 'Finalizado',
  QR: 'Código QR', CODIGO_BARRAS: 'Código de barras', NFC: 'NFC', MANUAL: 'Manual',
  APROBADO: 'Aprobado', DENEGADO: 'Denegado', EN_LINEA: 'En línea', CONTINGENCIA: 'Contingencia',
  NOVEDAD: 'Novedad', URGENTE: 'Urgente', RECORDATORIO: 'Recordatorio',
};

const ICONO_NOVEDAD = { RETRASO: 'reloj', CONGESTION: 'trafico', ACCIDENTE: 'octagono', VARADA: 'llave' };

const UI = {
  esc(valor) {
    return String(valor ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  },

  iniciales(nombre) {
    return String(nombre || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase();
  },

  hoyISO() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  },

  fechaISO(fecha) {
    return fecha.getFullYear() + '-' + String(fecha.getMonth() + 1).padStart(2, '0') + '-' + String(fecha.getDate()).padStart(2, '0');
  },

  toast(mensaje, tipo = 'info', titulo = null, duracionMs = 4500) {
    let contenedor = $('toasts');
    if (!contenedor) {
      contenedor = document.createElement('div');
      contenedor.id = 'toasts';
      contenedor.setAttribute('aria-live', 'polite');
      document.body.appendChild(contenedor);
    }
    const iconos = { exito: 'checkCirculo', error: 'alerta', push: 'campana', info: 'info' };
    const el = document.createElement('div');
    el.className = 'toast ' + tipo;
    el.innerHTML = icono(iconos[tipo] || 'info') + '<div>' + (titulo ? '<strong>' + UI.esc(titulo) + '</strong>' : '')
      + '<p>' + UI.esc(mensaje) + '</p></div>';
    contenedor.appendChild(el);
    setTimeout(() => {
      el.classList.add('saliendo');
      setTimeout(() => el.remove(), 260);
    }, duracionMs);
  },

  error(e) {
    console.error(e);
    UI.toast(e.message || 'Ocurrió un error', 'error');
  },

  /** Diálogo de confirmación con estilo propio. Devuelve una promesa con true/false. */
  confirmar({ titulo, mensaje, aceptar = 'Aceptar', cancelar = 'Cancelar', peligro = false, soloAceptar = false, icono: nombreIcono = 'info' }) {
    return new Promise((resolver) => {
      const fondo = document.createElement('div');
      fondo.className = 'dialogo-fondo';
      fondo.innerHTML = '<div class="dialogo" role="dialog" aria-modal="true" aria-labelledby="dialogo-titulo">'
        + '<div class="icono-chip' + (peligro ? '' : ' oscuro') + '">' + icono(nombreIcono) + '</div>'
        + '<h2 id="dialogo-titulo">' + UI.esc(titulo) + '</h2><p>' + UI.esc(mensaje) + '</p>'
        + '<div class="dialogo-acciones">'
        + (soloAceptar ? '' : '<button class="boton fantasma" data-r="0">' + UI.esc(cancelar) + '</button>')
        + '<button class="boton ' + (peligro ? 'primario' : 'oscuro') + '" data-r="1">' + UI.esc(aceptar) + '</button>'
        + '</div></div>';
      const cerrar = (valor) => {
        document.removeEventListener('keydown', teclado);
        fondo.remove();
        resolver(valor);
      };
      const teclado = (ev) => {
        if (ev.key === 'Escape') cerrar(false);
      };
      fondo.addEventListener('click', (ev) => {
        if (ev.target === fondo) cerrar(false);
        const boton = ev.target.closest('[data-r]');
        if (boton) cerrar(boton.dataset.r === '1');
      });
      document.addEventListener('keydown', teclado);
      document.body.appendChild(fondo);
      fondo.querySelector('[data-r="1"]').focus();
    });
  },

  vacio(texto) {
    return '<div class="vacio">' + UI.esc(texto) + '</div>';
  },
};

const fmt = {
  hora: (t) => (t ? String(t).slice(0, 5) : ''),
  fechaHora: (iso) => (iso ? new Date(iso).toLocaleString('es-CO', {
    weekday: 'short', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false,
  }) : ''),
  soloHora: (iso) => (iso ? new Date(iso).toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit', hour12: false }) : ''),
  fecha: (iso) => (iso ? new Date(iso + (String(iso).length === 10 ? 'T00:00:00' : '')).toLocaleDateString('es-CO', {
    weekday: 'long', day: 'numeric', month: 'long',
  }) : ''),
  fechaCorta: (iso) => (iso ? new Date(iso + 'T00:00:00').toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short' }) : ''),
  hace: (segundos) => {
    if (segundos < 60) return 'hace ' + segundos + ' s';
    const min = Math.floor(segundos / 60);
    return min < 60 ? 'hace ' + min + ' min' : 'hace ' + Math.floor(min / 60) + ' h';
  },
  numero: (n) => Number(n || 0).toLocaleString('es-CO'),
};

document.addEventListener('DOMContentLoaded', () => {
  hidratarIconos();
  document.querySelectorAll('[data-marca]').forEach((el) => {
    el.innerHTML = '<span class="emblema-unillanos claro" role="img" aria-label="Unillanos"><span></span></span>';
  });
});
