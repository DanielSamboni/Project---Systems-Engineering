# Sistema de Gestión y Seguimiento de Rutas de Transporte Universitario

Prototipo funcional de los cinco casos de uso del documento de análisis (Ingeniería de Software I – Unillanos).

- **Backend:** Java 21 + Spring Boot 4.1 (Web MVC, Data JPA, Security, Validation)
- **Base de datos:** PostgreSQL (perfil por defecto) o H2 en memoria (perfil `h2`, para demostraciones rápidas)
- **Frontend:** HTML + CSS + JavaScript sin frameworks, mapas con Leaflet/OpenStreetMap

## Cómo ejecutarlo

Requisitos: JDK 21. No hace falta instalar Maven (se usa el wrapper `mvnw`).

### Opción A – PostgreSQL

1. Crear la base de datos (una sola vez):

   ```bash
   psql -U postgres -c "CREATE DATABASE transporte_db;"
   ```

2. Arrancar indicando la contraseña del usuario `postgres`.

   En **CMD** (símbolo del sistema, el prompt se ve como `C:\...>`):

   ```bat
   set "DB_PASSWORD=su_contraseña"
   mvnw.cmd spring-boot:run
   ```

   En **PowerShell** (el prompt se ve como `PS C:\...>`):

   ```powershell
   $env:DB_PASSWORD = "su_contraseña"; .\mvnw.cmd spring-boot:run
   ```

   Variables opcionales: `DB_URL` (por defecto `jdbc:postgresql://localhost:5432/transporte_db`), `DB_USERNAME` (por defecto `postgres`), `PORT` (por defecto `8080`).

   Las tablas se crean solas y la primera vez se cargan datos de demostración.

### Opción B – H2 en memoria (sin instalar nada)

```powershell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=h2"
```

Los datos se pierden al detener el servidor.

Abrir <http://localhost:8080>.

### Pruebas automatizadas

```powershell
.\mvnw.cmd test
```

## Usuarios de prueba

Todos usan la contraseña `unillanos2026`.

| Usuario | Perfil | Para qué sirve |
|---|---|---|
| `estudiante1` | Pasajero | Sigue las rutas Centro y La Madrid – Porfía (recibe sus novedades) |
| `estudiante2`, `docente1` | Pasajero | Otros pasajeros |
| `conductor1` | Conductor | Turnos de la ruta Centro con el bus WTK101 |
| `conductor2` | Conductor | Turno de La Madrid – Porfía (WTK102) y de Centro los sábados (WTK103) |
| `conductor3` | Conductor | Turno de Grama – Catama con WTK104, **vehículo sin GPS** (flujo 5b de CU-01) |
| `admin` | Administrador | Módulo administrativo |

Carnets en el Sistema Académico simulado: `160001001` y `900002001` activos, `160001003` vencido, `160001004` inactivo; cualquier otro código no existe. También se puede digitar el número de documento (p. ej. `1121000002`).

## Guion de demostración

1. **CU-04 + CU-01:** en una ventana inicie sesión como `conductor2` e inicie el recorrido de La Madrid – Porfía. En otra ventana (modo incógnito) entre como `estudiante1`: el bus aparece en el mapa, se mueve cada 5 s y se muestra el tiempo estimado de llegada a la parada elegida.
2. **Novedades:** desde la terminal del conductor reporte «Congestión»; al pasajero le llega la notificación.
3. **CU-03:** valide los carnets de prueba. Marque «Simular pérdida de cobertura» y valide de nuevo: la terminal usa la copia local y sincroniza al desmarcar la casilla. Con `admin` → *Sistema académico* puede simular la caída del sistema externo.
4. **CU-02:** en *Horarios* el pasajero toca una salida para crear un recordatorio; si elige una salida que ya pasó, el sistema sugiere la siguiente.
5. **CU-05:** con `admin` revise los reportes, edite una ruta (clic en el mapa para agregar trazado y paradas) y guarde. Si fija «Vigente desde» a menos de 12 horas, el cambio se marca urgente y se notifica a los pasajeros con recordatorios.

## Qué puede hacer el administrador

Todo lo que el documento de análisis asigna al actor Administrador (oficina de transporte):

| Según el documento | En el módulo administrativo |
|---|---|
| Supervisar el servicio (Tabla 4) | **Monitoreo en vivo**: mapa con toda la flota, estado y señal de cada bus, abordajes, novedades del día y cierre de recorridos que el conductor dejó abiertos |
| Consultar reportes de uso por ruta, franja y día (CU-05 paso 4, RF-14) | **Reportes e indicadores**, con los indicadores de éxito de la Tabla 6 (los que dependen de encuestas quedan señalados) |
| Crear y modificar rutas, paradas, trazado y horarios; publicar; cambio urgente (CU-05, RF-12) | **Rutas y horarios**, con editor sobre el mapa y «Trazar por las vías» |
| Asignar y modificar vehículos y conductores de cada turno (RF-13) | **Turnos**: asignar, modificar y eliminar, sin solapamientos |
| Administrar la flota y su equipamiento | **Vehículos**: registrar, marcar GPS o lector y retirar de servicio |
| Habilitar a los conductores del operador | **Conductores**: registrar, activar y desactivar |
| Revisar los accesos denegados (CU-03 flujo 5a) | **Accesos denegados** |
| Contingencia ante caída del Sistema Académico | **Sistema académico** (simulación) |

## Trazabilidad casos de uso → código

| Caso de uso / RF | Controlador (presentación) | Caso de uso (aplicación) | Reglas de dominio | Vista |
|---|---|---|---|---|
| Iniciar sesión (RF-01) | `AuthController` | — (Spring Security en `infraestructura/seguridad`) | — | `index.html`, `js/paginas/acceso.js` |
| CU-01 Consultar ubicación (RF-02, RF-03, RF-04) | `RutaConsultaController` | `UbicacionService` | `CalculadoraEta`, `Geo` | `pasajero.html` → Mapa en vivo |
| CU-02 Consultar horarios (RF-05, RF-06) | `RutaConsultaController`, `PasajeroController` | `HorarioService` | `EvaluadorProgramacion` | `pasajero.html` → Horarios |
| CU-03 Validar acceso (RF-07, RF-08, RF-09) | `ConductorController` | `AccesoService` + puerto `SistemaAcademicoGateway` | — | `conductor.html` → Validar acceso |
| CU-04 Transmitir ubicación (RF-10, RF-11) | `ConductorController` | `RecorridoService`, `NotificacionService` | — | `conductor.html` |
| CU-05 Gestionar rutas y horarios (RF-12, RF-13, RF-14) | `AdminController` | `RutaService` + puerto `EnrutadorVial`, `AsignacionService` + puerto `CifradorClaves`, `ReporteService` | `ValidadorProgramacion`, `Geo` | `admin.html` |
| Supervisión del servicio (Tabla 4) | `AdminController` | `MonitoreoService` | — | `admin.html` → Monitoreo en vivo |

Flujos alternativos implementados: CU-01 2a, 5a, 5b, 7a, 9a · CU-02 5a, 7a · CU-03 2a, 3a, 5a · CU-04 4a, 5a, 6a · CU-05 8a, 9a.

## Arquitectura

Arquitectura limpia (Robert C. Martin) con patrón Modelo-Vista-Controlador. Las dependencias apuntan siempre hacia adentro: `presentacion` → `aplicacion` → `dominio`. La `infraestructura` implementa los puertos que define la aplicación.

```
src/main/java/edu/unillanos/transporte/
├── dominio/                    ← núcleo: no depende de ninguna otra capa
│   ├── modelo/                 Entidades del negocio (Ruta, Parada, Salida, Recorrido, Abordaje…)
│   ├── reglas/                 Reglas puras: ETA, geometría, programación y solapamientos (con pruebas unitarias)
│   └── excepcion/              Errores de negocio
├── aplicacion/                 ← casos de uso
│   ├── casosdeuso/             Un servicio por caso de uso (UbicacionService = CU-01, HorarioService = CU-02…)
│   ├── dto/                    Modelos de entrada y salida de los casos de uso
│   └── puerto/                 Interfaces hacia el exterior
│       ├── persistencia/       Repositorios (Spring Data genera la implementación)
│       ├── SistemaAcademicoGateway   Sistema Académico Institucional (actor secundario de CU-03)
│       └── EnrutadorVial             Proveedor de rutas viales (trazados por las calles)
├── infraestructura/            ← detalles técnicos intercambiables
│   ├── academico/              Simulación del Sistema Académico (implementa SistemaAcademicoGateway)
│   ├── mapas/                  OsrmEnrutadorVial (implementa EnrutadorVial con OpenStreetMap/OSRM)
│   ├── seguridad/              Spring Security: autenticación y perfiles
│   └── configuracion/          Reloj, datos iniciales y catálogo de rutas
└── presentacion/
    └── controlador/            Controladores REST (la «C» de MVC) y manejo de errores

src/main/resources/
├── datos/rutas-iniciales.json  Rutas con trazados reales sobre las vías de Villavicencio
└── static/                     ← la «V» de MVC
    ├── index.html, pasajero.html, conductor.html, admin.html
    ├── img/  logo y emblema de la Universidad de los Llanos (fondo transparente)
    ├── css/  tema.css (tokens de diseño) · componentes.css · mapa.css · paginas/*.css
    └── js/   nucleo/ (api, ui, mapa, iconos) · paginas/ (un archivo por pantalla)
```

**MVC:** el *Modelo* son las entidades de `dominio/modelo` y los DTOs de `aplicacion/dto`; la *Vista* son las páginas de `static/`; el *Controlador* son las clases de `presentacion/controlador`, que reciben la petición, invocan el caso de uso y devuelven el modelo.

**Decisión pragmática:** las entidades del dominio llevan anotaciones JPA para no duplicar cada clase en un modelo de persistencia aparte. Los repositorios se declaran como puertos en la capa de aplicación y Spring Data genera su implementación.

## Mapas y trazados

- Las rutas iniciales siguen las calles reales: las paradas se ubicaron con **Nominatim** (OpenStreetMap) y los recorridos se calcularon con **OSRM**. Covisan no figura en OpenStreetMap, así que su ubicación es aproximada (Comuna 10, junto a San Antonio).
- En el editor de rutas, el botón **Trazar por las vías** calcula el recorrido por las calles a partir de las paradas, usando el puerto `EnrutadorVial` (requiere internet; la URL se configura con la variable `OSRM_URL`).
- Mapa base: **Stadia Maps** (no pide clave en `localhost`). Si sus mosaicos fallan (p. ej. al publicar la app en otro dominio sin clave), la app cambia sola a OpenStreetMap estándar.
- Si la base de datos ya existía con los trazados aproximados de la primera versión, al arrancar se reemplazan automáticamente por los trazados sobre las vías.

## Simplificaciones del prototipo

- **Notificaciones push:** se guardan en una bandeja que la app consulta cada 10 s y muestra como alerta; en producción se usaría un servicio push (p. ej. Firebase Cloud Messaging).
- **GPS y lector de carnet:** la terminal del conductor incluye un simulador de GPS que recorre el trazado y un campo donde se ingresa la lectura del carnet; también puede usar el GPS real del dispositivo.
- **Sistema Académico Institucional:** simulado con una tabla propia (`sa_carnets`).
- **Credenciales institucionales:** usuarios locales con contraseña cifrada (BCrypt); en producción se integraría con el directorio institucional.
- **Seguridad de transporte:** CSRF está deshabilitado y el servidor corre en HTTP; en producción se exige TLS (RNF-04).
- No se valida que el turno corresponda a la hora actual al iniciar el recorrido, para poder hacer la demostración a cualquier hora.
